from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time

root = Path('F:/mb-followup-actions-ui-20261019')
out = Path('C:/Users/Consu/AppData/Local/Temp/metodobase-followup-ui34-runtime-v1-20261019')
out.mkdir(exist_ok=False)
os.chdir(root)
sys.path.insert(0, str(root))
sys.dont_write_bytecode = True
from tests.isolation import prepare_environment, block_external_sockets
prepare_environment(discard_inherited=True)
block_external_sockets()

def save(name, value):
    with (out / name).open('x', encoding='utf8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)

def snap():
    paths = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard', '-z']).decode().split('\0')
    source = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in sorted(set(paths))
              if p and not p.startswith('docs/') and (root / p).is_file()}
    packages = {d.metadata['Name']: {'version': d.version, 'metadata_sha256': hashlib.sha256((d.read_text('METADATA') or '').encode()).hexdigest()}
                for d in importlib.metadata.distributions()}
    binaries = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in (Path(sys.executable), Path(sys._base_executable), Path('C:/Program Files/nodejs/node.exe'))}
    return {'source': source, 'packages': packages, 'binaries': binaries}

before = snap()
save('before.json', before)
pip1 = subprocess.run([sys.executable, '-m', 'pip', 'check'], capture_output=True, text=True)
save('pip-before.json', {'exit': pip1.returncode, 'output': pip1.stdout})
import pytest
started = time.monotonic()
code = pytest.main(['tests/test_followup34_ui.py', '-q', '--tb=short', '--junitxml=' + str(out / 'ui.xml'), '-o', 'cache_dir=' + str(out / 'pytest-cache')])
after = snap()
save('after.json', after)
pip2 = subprocess.run([sys.executable, '-m', 'pip', 'check'], capture_output=True, text=True)
save('pip-after.json', {'exit': pip2.returncode, 'output': pip2.stdout})
save('receipt.json', {'exit': code, 'quiet': before == after, 'source_count': len(before['source']), 'packages': len(before['packages']), 'duration_seconds': time.monotonic()-started, 'pip_before': pip1.returncode, 'pip_after': pip2.returncode, 'scope': 'Own SSR and actual isolated SQLite HTTP DTO bridge into JavaScript parsers; no PostgreSQL, Chrome, provider, live service or VM'})
raise SystemExit(code)
