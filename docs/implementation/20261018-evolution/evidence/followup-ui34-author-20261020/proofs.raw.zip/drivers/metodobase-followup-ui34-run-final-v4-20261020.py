from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time

root=Path('F:/mb-followup-actions-ui-20261019');out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-followup-ui34-runtime-final-v4-20261020')
out.mkdir(exist_ok=False);os.chdir(root);sys.path.insert(0,str(root));sys.dont_write_bytecode=True
from tests.isolation import prepare_environment,block_external_sockets
prepare_environment(discard_inherited=True);block_external_sockets()
def save(name,value):
    with (out/name).open('x',encoding='utf8') as f:json.dump(value,f,indent=2,sort_keys=True)
def snap():
    paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')
    source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if p and not p.startswith('docs/') and (root/p).is_file()}
    packages={d.metadata['Name']:{'version':d.version,'metadata_sha256':hashlib.sha256((d.read_text('METADATA')or'').encode()).hexdigest()} for d in importlib.metadata.distributions()}
    binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(sys.executable),Path(sys._base_executable),Path('C:/Program Files/nodejs/node.exe'))}
    return {'source':source,'packages':packages,'binaries':binaries}
before=snap();save('before.json',before)
prior=json.loads(Path('C:/Users/Consu/AppData/Local/Temp/metodobase-followup-ui34-runtime-final-v3-20261020/after.json').read_text())
changed={p:{'previous':prior['source'].get(p),'current':before['source'].get(p)} for p in sorted(set(prior['source'])|set(before['source'])) if prior['source'].get(p)!=before['source'].get(p)}
assert set(changed)=={'web/static/js/seguimiento-tareas.js','web/static/js/seguimiento-pagina.js','tests/e2e/followup_tasks_state.cjs'}
save('last-validation-delta.json',{'changed_paths':changed,'purpose':'Distinguish closed-wire rejection before send from unconfirmed dispatch; preserve form and add three explicit ACK/validation canaries','all_other_paths_equal_prior':True,'packages_same_prior':prior['packages']==before['packages'],'binaries_same_prior':prior['binaries']==before['binaries']})
pip1=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-before.json',{'exit':pip1.returncode,'output':pip1.stdout})
started=time.monotonic();node_results=[]
for stem in ['followup_tasks_api','followup_tasks_state','followup_tasks_dom','dashboard_followup34']:
    r=subprocess.run(['C:/Program Files/nodejs/node.exe','tests/e2e/'+stem+'.cjs'],capture_output=True,text=True,timeout=60)
    (out/(stem+'.stdout')).write_bytes(r.stdout.encode());(out/(stem+'.stderr')).write_bytes(r.stderr.encode())
    node_results.append({'file':'tests/e2e/'+stem+'.cjs','exit':r.returncode,'report':json.loads(r.stdout)})
save('node-results.json',node_results)
import pytest
code=pytest.main(['tests/test_followup34_ui.py','tests/test_followup34_client_ssr_privacy.py','-q','--tb=short','--junitxml='+str(out/'ui.xml'),'-o','cache_dir='+str(out/'pytest-cache')])
after=snap();save('after.json',after)
pip2=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-after.json',{'exit':pip2.returncode,'output':pip2.stdout})
save('receipt.json',{'pytest_exit':code,'node_exit_codes':[r['exit'] for r in node_results],'quiet':before==after,'source_count':len(before['source']),'package_count':len(before['packages']),'pip_before':pip1.returncode,'pip_after':pip2.returncode,'duration_seconds':time.monotonic()-started,'scope':'Final own72 VM/DOM cases plus15 SSR/private-header/isolated SQLite HTTP DTO bridge cases. No Chrome/layout/axe/PG/provider acceptance; unchanged prior auth/MFA/Google/dashboard regressions remain explicitly prior executions.'})
raise SystemExit(code or any(r['exit'] for r in node_results))
