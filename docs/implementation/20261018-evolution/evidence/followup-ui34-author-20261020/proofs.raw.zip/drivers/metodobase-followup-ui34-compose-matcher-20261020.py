from pathlib import Path
import hashlib
import json
import subprocess
root=Path('F:/mb-followup-actions-ui-20261019')
head='d3f2fb44f2cce248d0347bab044c49aa4bb08bc3'
expected={'web/followup_paths.py':'964711361969677a8587a0d4b316965a82f335cee006551af868ca1978e8d401','tests/test_followup34_client_ssr_privacy.py':'37453217f1d6f5ba36999cb3316a78a08386fa1333b07ba6c6ebc3dd9144cad9'}
receipt={}
for name,digest in expected.items():
    blob=subprocess.check_output(['git','show',head+':'+name],cwd=root)
    assert hashlib.sha256(blob).hexdigest()==digest
    path=root/name
    receipt[name]={'before_sha256':hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None,'git_blob_sha256':digest,'producer_head':head}
    path.write_bytes(blob)
with Path('C:/Users/Consu/AppData/Local/Temp/metodobase-followup-ui34-matcher-composition-20261020.json').open('x',encoding='utf8') as f:json.dump(receipt,f,indent=2)
