from pathlib import Path
import hashlib
import json
import subprocess

root=Path('F:/mb-followup-actions-ui-20261019')
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-followup-ui34-final-alias-20261020')
out.mkdir(exist_ok=False)
head='2f74c634028e2fa487e71423737194c4d8868167'
expected={'web/followup_paths.py':'2db2e41a41ff89b596be4dc8ed7301bd97366133c8608cf7fded8894a0071d39','tests/test_followup34_client_ssr_privacy.py':'2cf14eeeb9e113b92ac269059db7c8683fef1a7478c9579f14aeb773216824c0'}
receipt={}
for name,digest in expected.items():
    path=root/name
    previous=path.read_bytes()
    (out/path.name).write_bytes(previous)
    blob=subprocess.check_output(['git','show',head+':'+name],cwd=root)
    assert hashlib.sha256(blob).hexdigest()==digest
    receipt[name]={'before_sha256':hashlib.sha256(previous).hexdigest(),'producer_head':head,'git_blob_sha256':digest,'before_status':'Local WIP; privacy-relaxing test adaptation was not executed or accepted'}
    path.write_bytes(blob)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
