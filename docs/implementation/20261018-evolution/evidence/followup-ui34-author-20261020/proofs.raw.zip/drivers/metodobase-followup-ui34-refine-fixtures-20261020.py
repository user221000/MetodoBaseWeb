from pathlib import Path
root=Path('F:/mb-followup-actions-ui-20261019')
p=root/'tests/e2e/followup_tasks_state.cjs'
old='result.version=value.kind===\'created\'?1:value.body.expected_version+1;if(value.kind===\'completed\')'
new='result.version=value.kind===\'created\'?1:value.body.expected_version+1;if([\'created\',\'updated\'].includes(value.kind)){result.next_step=value.body.next_step;result.responsible=value.body.assignee_id===null?null:{id:value.body.assignee_id,display_name:\'Synthetic professional\',eligible:true};}if(value.kind===\'completed\')'
raw=p.read_bytes();before=raw.decode('utf8');assert before.count(old)==1;p.write_text(before.replace(old,new),encoding='utf8',newline='')
p=root/'web/static/js/seguimiento-pagina.js'
old="else card.append(button('Preparar tarea de esta causa',()=>controller.prepare('created',index),stale));"
new="else {const control=button('Preparar tarea de esta causa',()=>controller.prepare('created',index),stale);control.id='tasks-create-'+cause.cause;card.append(control);}"
before=p.read_text(encoding='utf8');assert before.count(old)==1;p.write_text(before.replace(old,new),encoding='utf8',newline='')
