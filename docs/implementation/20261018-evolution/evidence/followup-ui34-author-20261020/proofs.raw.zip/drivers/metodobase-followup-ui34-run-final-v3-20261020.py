from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time

root=Path('F:/mb-followup-actions-ui-20261019')
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-followup-ui34-runtime-final-v3-20261020')
out.mkdir(exist_ok=False);os.chdir(root);sys.path.insert(0,str(root));sys.dont_write_bytecode=True
from tests.isolation import prepare_environment,block_external_sockets
prepare_environment(discard_inherited=True);block_external_sockets()
def save(name,value):
    with (out/name).open('x',encoding='utf8') as f:json.dump(value,f,indent=2,sort_keys=True)
def snap():
    paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')
    source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if p and not p.startswith('docs/') and (root/p).is_file()}
    packages={d.metadata['Name']:{'version':d.version,'metadata_sha256':hashlib.sha256((d.read_text('METADATA')or'').encode()).hexdigest()} for d in importlib.metadata.distributions()}
    binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(sys.executable),Path(sys._base_executable),Path('C:/Program Files/nodejs/node.exe'))}
    return {'source':source,'packages':packages,'binaries':binaries}
before=snap();save('before.json',before)
prior=json.loads(Path('C:/Users/Consu/AppData/Local/Temp/metodobase-followup-ui34-runtime-final-v2-20261020/after.json').read_text())
changed={p:{'previous':prior['source'].get(p),'current':before['source'].get(p)} for p in sorted(set(prior['source'])|set(before['source'])) if prior['source'].get(p)!=before['source'].get(p)}
assert set(changed)=={'web/followup_paths.py','tests/test_followup34_client_ssr_privacy.py','tests/test_followup34_ui.py'},list(changed)
save('prior-node-source-preservation.json',{'all_22_node_suite_sources_and_all_js_cjs_css_html_unchanged':True,'changed_paths':changed,'prior_scope':'22 VM/DOM synthetic suites, not browser/layout; no execution repeated','same_packages':prior['packages']==before['packages'],'same_binaries':prior['binaries']==before['binaries']})
pip1=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-before.json',{'exit':pip1.returncode,'output':pip1.stdout})
ruff=subprocess.run(['C:/Users/Consu/AppData/Local/Temp/metodobase-qa-20261018/Scripts/python.exe','-m','ruff','check','tests/test_followup34_ui.py','tests/test_followup34_client_ssr_privacy.py','web/followup_paths.py'],capture_output=True,text=True)
save('ruff.json',{'exit':ruff.returncode,'stdout':ruff.stdout,'stderr':ruff.stderr})
assert ruff.returncode==0
import pytest
started=time.monotonic()
code=pytest.main(['tests/test_followup34_ui.py','tests/test_followup34_client_ssr_privacy.py','-q','--tb=short','--junitxml='+str(out/'ui.xml'),'-o','cache_dir='+str(out/'pytest-cache')])
after=snap();save('after.json',after)
pip2=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-after.json',{'exit':pip2.returncode,'output':pip2.stdout})
save('receipt.json',{'pytest_exit':code,'quiet':before==after,'source_count':len(before['source']),'package_count':len(before['packages']),'pip_before':pip1.returncode,'pip_after':pip2.returncode,'ruff_exit':ruff.returncode,'duration_seconds':time.monotonic()-started,'scope':'Root final SSR alias matcher + mounted UI; public SSR privacy and isolated SQLite HTTP DTO→real JavaScript parser bridge. Prior22 Node suites source-preserved; no Chrome/PG/provider/layout acceptance'})
raise SystemExit(code)
