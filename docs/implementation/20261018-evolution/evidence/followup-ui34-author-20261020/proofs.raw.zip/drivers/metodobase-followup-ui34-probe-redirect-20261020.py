from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
root=Path('F:/mb-followup-actions-ui-20261019');os.chdir(root);sys.path.insert(0,str(root));sys.dont_write_bytecode=True
from tests.isolation import prepare_environment,block_external_sockets
prepare_environment(discard_inherited=True);block_external_sockets()
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-followup-ui34-redirect-probe-20261020');out.mkdir(exist_ok=False)
source=(root/'tests/test_followup34_client_ssr_privacy.py').read_text(encoding='utf8')
old='        assert response.status_code == 404\n        assert response.headers["Referrer-Policy"] == "strict-origin-when-cross-origin"'
new='        OBSERVED.append({"path": path, "status": response.status_code, "location": response.headers.get("Location"), "referrer": response.headers.get("Referrer-Policy"), "cache": response.headers.get("Cache-Control"), "csp": response.headers.get("Content-Security-Policy")})'
assert source.count(old)==1
probe='OBSERVED=[]\n'+source.replace('def test_client_task_shell_route_shape_is_private_on_every_method','def test_diagnostic_client_redirect_shape').replace(old,new)
probe+='\n\ndef test_write_diagnostic_observations():\n    import json\n    from pathlib import Path\n    Path('+repr(str(out/'observed.json'))+').write_text(json.dumps(OBSERVED,indent=2),encoding="utf8")\n'
(out/'test_probe.py').write_text(probe,encoding='utf8',newline='')
(out/'derivation.json').write_text(json.dumps({'producer_sha256':hashlib.sha256(source.encode()).hexdigest(),'diagnostic_sha256':hashlib.sha256(probe.encode()).hexdigest(),'business_acceptance':False,'changes':'Only rename test, replace two negative assertions with inert header observations and add final observer writer. All original positive methods/header assertions retained. Original maintained test unchanged.'},indent=2),encoding='utf8')
import pytest
raise SystemExit(pytest.main([str(out/'test_probe.py'),'-q','--tb=short','--junitxml='+str(out/'diagnostic.xml'),'-o','cache_dir='+str(out/'cache')]))
