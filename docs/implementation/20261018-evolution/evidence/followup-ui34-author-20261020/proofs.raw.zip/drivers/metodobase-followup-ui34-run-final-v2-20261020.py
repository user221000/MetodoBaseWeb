from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time

root=Path('F:/mb-followup-actions-ui-20261019')
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-followup-ui34-runtime-final-v2-20261020')
out.mkdir(exist_ok=False)
os.chdir(root);sys.path.insert(0,str(root));sys.dont_write_bytecode=True
from tests.isolation import prepare_environment,block_external_sockets
prepare_environment(discard_inherited=True);block_external_sockets()
def save(name,value):
    with (out/name).open('x',encoding='utf8') as f:json.dump(value,f,indent=2,sort_keys=True)
def snap():
    paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')
    source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if p and not p.startswith('docs/') and (root/p).is_file()}
    packages={d.metadata['Name']:{'version':d.version,'metadata_sha256':hashlib.sha256((d.read_text('METADATA')or'').encode()).hexdigest()} for d in importlib.metadata.distributions()}
    binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(sys.executable),Path(sys._base_executable),Path('C:/Program Files/nodejs/node.exe'))}
    return {'source':source,'packages':packages,'binaries':binaries}
before=snap();save('before.json',before)
p=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-before.json',{'exit':p.returncode,'output':p.stdout})
started=time.monotonic();node_results=[]
files=['followup_tasks_api','followup_tasks_state','followup_tasks_dom','dashboard_followup34','dashboard_followup','dashboard_followup_focus','google_link_api','google_link_state','google_link_dom','google_link_login_review','auth_refresh','auth_refresh_storage','auth_refresh_race_review','auth_refresh_security_review','session_revision_events','session_expiry_security','session_expiry_fences','mfa_api','mfa_consumers','mfa31_login','mfa_state','mfa_prompt']
for stem in files:
    path='tests/e2e/'+stem+'.cjs';r=subprocess.run(['C:/Program Files/nodejs/node.exe',path],capture_output=True,text=True,timeout=60)
    (out/(stem+'.stdout')).write_bytes(r.stdout.encode('utf8'));(out/(stem+'.stderr')).write_bytes(r.stderr.encode('utf8'))
    try:report=json.loads(r.stdout)
    except ValueError:report={'unparsed':True}
    node_results.append({'file':path,'exit':r.returncode,'report':report})
save('node-results.json',node_results)
import pytest
code=pytest.main(['tests/test_followup34_ui.py','tests/test_followup34_client_ssr_privacy.py','-q','--tb=short','--junitxml='+str(out/'ui.xml'),'-o','cache_dir='+str(out/'pytest-cache')])
after=snap();save('after.json',after)
p2=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-after.json',{'exit':p2.returncode,'output':p2.stdout})
save('receipt.json',{'pytest_exit':code,'node_exit_codes':[r['exit'] for r in node_results],'quiet':before==after,'source_count':len(before['source']),'package_count':len(before['packages']),'pip_before':p.returncode,'pip_after':p2.returncode,'duration_seconds':time.monotonic()-started,'scope':'Final composed private matcher + actual maintained UI; synthetic VM/DOM, public SSR and SQLite TestClient HTTP DTO bridge only; no Chrome/PG/provider/layout acceptance'})
raise SystemExit(code or any(r['exit'] for r in node_results))
