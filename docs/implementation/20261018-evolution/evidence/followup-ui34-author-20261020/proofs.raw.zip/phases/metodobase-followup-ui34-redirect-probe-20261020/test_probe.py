OBSERVED=[]
"""The dedicated client task shell and all its errors are private on both factories."""
from tests import followup34_http as fixtures

followup_db = fixtures.followup_db
followup_http = fixtures.followup_http


def test_diagnostic_client_redirect_shape(followup_http):
    raw = followup_http["raw"]
    for client_id in ("A1B2C3D4", "invalid-identifier"):
        for suffix in ("", "/"):
            for method in ("GET", "HEAD", "POST", "PATCH", "DELETE", "OPTIONS"):
                response = raw.request(method, "/clientes/" + client_id + "/seguimiento" + suffix,
                                       follow_redirects=False)
                # The shell is mounted by the UI composition. The privacy
                # boundary must also hold before/after dispatch, including404.
                assert response.status_code in {200, 307, 404, 405}
                assert response.headers["Cache-Control"] == "no-store"
                assert response.headers["Referrer-Policy"] == "no-referrer"
                assert "accounts.google.com" not in response.headers["Content-Security-Policy"]
                assert response.headers["X-Content-Type-Options"] == "nosniff"
    for path in ("/clientes/A1B2C3D4/seguimientox", "/clientes/A1B2C3D4/seguimiento/extra",
                 "/clientes/A1B2C3D4/seguimiento//", "/other/A1B2C3D4/seguimiento"):
        response = raw.get(path, follow_redirects=False)
        OBSERVED.append({"path": path, "status": response.status_code, "location": response.headers.get("Location"), "referrer": response.headers.get("Referrer-Policy"), "cache": response.headers.get("Cache-Control"), "csp": response.headers.get("Content-Security-Policy")})


def test_write_diagnostic_observations():
    import json
    from pathlib import Path
    Path('C:\\Users\\Consu\\AppData\\Local\\Temp\\metodobase-followup-ui34-redirect-probe-20261020\\observed.json').write_text(json.dumps(OBSERVED,indent=2),encoding="utf8")
