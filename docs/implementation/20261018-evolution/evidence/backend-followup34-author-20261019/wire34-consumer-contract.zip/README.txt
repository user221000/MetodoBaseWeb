Contract only, technically signed by ROOT. No API34/PostgreSQL/UI acceptance.
Exact approved JSON retains its original pending-status bytes; signature is the separate receipt.
SSR owned by frontend: /seguimiento and optional slash. Its server privacy policy is prepared by backend.
API namespace: /api/seguimiento. Managers use contexto/responsables/clientes/{client_id}/candidatos/tareas/metricas.
Nutri uses contexto plus assigned tareas/detail/historial/completar only; no stats/global metrics/directory.
Existing /api/estadisticas/seguimiento adds server-produced cause_candidates and per_cause_tasks for managers.
All operational mutations need a new lowercase UUID Idempotency-Key per intention; explicit same-input replay only.
No additional MFA step-up/grant; the existing authenticated session/MFA login remains authoritative.
Do not implement in_progress, outbound contact, automatic assignment, closure or reopening.
ACK replay is an operation receipt with task:null/read_required:true, never a current-task snapshot.
Responsible/history display_name:null + eligible:false means a historical reference, no contact lookup.
Exact statuses/body/cursors/capabilities/budgets and examples are in wire34-v1.json.
Root will assign frontend composition after backend API freeze; no WIP code overlay is authorized by this artifact.
