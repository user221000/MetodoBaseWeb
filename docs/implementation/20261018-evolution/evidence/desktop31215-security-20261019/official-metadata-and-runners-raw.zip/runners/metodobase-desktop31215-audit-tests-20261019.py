from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

root=Path('F:/MetodoBaseWeb-execution-20261018')
tool=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-python31215-windows-provenance-20261019')
target=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-desktop31215-package-20261019')
python=target/'Scripts/python.exe'
out=tool/'desktop-audit-tests'
out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
package_probe='import importlib.metadata,json;print(json.dumps(sorted((d.metadata["Name"],d.version) for d in importlib.metadata.distributions())))'
def target_packages():
 return json.loads(subprocess.check_output([str(python),'-I','-c',package_probe]))
def tool_packages():
 return sorted((d.metadata['Name'],d.version) for d in importlib.metadata.distributions())
names=[p.relative_to(root).as_posix() for folder in ['api','config','core','src','ui_desktop','utils','web','scripts','tests']
       for p in (root/folder).rglob('*') if p.is_file() and p.suffix in {'.py','.js','.cjs','.html','.css','.lock','.json','.txt'}
       and 'node_modules' not in p.parts and '__pycache__' not in p.parts]
names.extend(p.name for p in root.glob('*.py'))
names=sorted(set(names))
def sources():return {name:sha((root/name).read_bytes()) for name in names}
before=sources();p_before=target_packages();tool_before=tool_packages()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='dd9877350aad3f483299c990a1e97aab63c83f5d' and len(p_before)==83
req=out/'actual-desktop83.txt'
req.write_text('\n'.join(f'{name}=={version}' for name,version in p_before)+'\n',encoding='utf-8')
start=time.monotonic()
command=[sys.executable,'-m','pip_audit','--disable-pip','--no-deps','--strict','--vulnerability-service','osv',
         '-r',str(req),'-f','json','-o',str(out/'audit.json')]
with (out/'audit.log').open('xb') as log:
 audit=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=180)
audit_seconds=round(time.monotonic()-start,3)
environment={k:v for k,v in os.environ.items() if not k.upper().startswith(('UV_','PIP_','PYTHON','METODOBASE','DATABASE','STRIPE','MERCADO','RESEND','SENTRY'))}
environment.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',PYTHON_DOTENV_DISABLED='1',QT_QPA_PLATFORM='offscreen')
cases=[('supported',['tests/test_login_desktop.py','tests/services']),
       ('packaging',['tests/test_desktop_packaging.py','tests/test_desktop_packaging_review.py',
                     'tests/test_desktop_provenance.py','tests/test_desktop_entrypoints.py','tests/test_desktop_packaging_ops10.py'])]
results=[]
for label,files in cases:
 report=out/(label+'.xml')
 command=[str(python),'-X','utf8','tests/run_isolated.py',*files,'-q','--tb=short','--junitxml='+str(report)]
 start=time.monotonic()
 with (out/(label+'.log')).open('xb') as stream:
  result=subprocess.run(command,cwd=root,env=environment,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
 xml=ET.parse(report)
 bad=sum(len(xml.findall('.//'+tag)) for tag in ['failure','error','skipped'])
 results.append({'label':label,'exit':result.returncode,'tests':len(xml.findall('.//testcase')),
                 'bad_or_skipped':bad,'seconds':round(time.monotonic()-start,3)})
after=sources();p_after=target_packages();tool_after=tool_packages()
audit_json=json.loads((out/'audit.json').read_text(encoding='utf-8'))
deps=audit_json['dependencies']
vulns=[{'name':d['name'],'version':d['version'],'ids':[v['id'] for v in d.get('vulns',[])]} for d in deps if d.get('vulns')]
summary={'created_utc':datetime.now(timezone.utc).isoformat(),'source_commit':head,
 'python':'3.12.15','target_packages':len(p_before),'tool_packages':len(tool_before),
 'sources_count':len(before),'sources_stable':before==after,'target_packages_stable':p_before==p_after,
 'tool_packages_stable':tool_before==tool_after,'source_aggregate_sha256':sha(json.dumps(before,sort_keys=True).encode()),
 'audit_exit':audit.returncode,'audit_seconds':audit_seconds,'audited_dependencies':len(deps),
 'vulnerable_dependencies':vulns,'results':results,
 'scope':'Fresh Windows desktop interpreter and hash-locked target; actual OSV PyPI inventory audit and maintained desktop tests, not installer/build/native library CVE coverage or broad SaaS suite.'}
(out/'source-photos-private.json').write_text(json.dumps({'before':before,'after':after},indent=2)+'\n',encoding='utf-8')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
assert before==after and p_before==p_after and tool_before==tool_after
assert audit.returncode==0 and not vulns
assert all(r['exit']==r['bad_or_skipped']==0 and r['tests']>0 for r in results)
