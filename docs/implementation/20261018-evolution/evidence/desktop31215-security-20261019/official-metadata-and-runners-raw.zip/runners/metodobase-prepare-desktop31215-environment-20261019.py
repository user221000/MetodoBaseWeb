from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

source=Path('F:/MetodoBaseWeb-execution-20261018')
tool=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-python31215-windows-provenance-20261019')
runtime=tool/'runtime/python/python.exe'
assert json.loads((tool/'prepared.json').read_text(encoding='utf-8'))['runtime']['version']=='3.12.15'
target=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-desktop31215-package-20261019')
assert not target.exists()
evidence=tool/'desktop-environment'
evidence.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
locks=[source/'requirements-test-desktop-windows.lock',source/'requirements_build.lock',
       Path('F:/MetodoBaseWeb-image-pip-20261019/requirements-container-bootstrap.lock')]
assert sha(locks[-1].read_bytes().replace(b'\r\n',b'\n'))=='01cb7092ff6e66c2d52618b2076234ca877f833c067c6c3b51fd8607cebc15aa'
before={str(p):sha(p.read_bytes()) for p in locks}
uv=shutil.which('uv')
assert uv
environment={k:v for k,v in os.environ.items() if not k.upper().startswith(('UV_','PIP_','PYTHON','METODOBASE','DATABASE','STRIPE','MERCADO','RESEND','SENTRY'))}
environment.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',PYTHON_DOTENV_DISABLED='1')
start=time.monotonic()
create=subprocess.run([str(runtime),'-I','-m','venv','--without-pip',str(target)],env=environment,capture_output=True,timeout=90)
(evidence/'venv-create.log').write_bytes(create.stdout+create.stderr)
assert create.returncode==0
python=target/'Scripts/python.exe'
command=[uv,'--no-config','--no-python-downloads','pip','install','--python',str(python),
         '--index-url','https://pypi.org/simple','--only-binary',':all:','--require-hashes']
for lock in locks:command.extend(['-r',str(lock)])
with (evidence/'install.log').open('xb') as stream:
    install=subprocess.run(command,cwd=source,env=environment,stdout=stream,stderr=subprocess.STDOUT,timeout=600)
assert install.returncode==0
probe='import importlib.metadata,json,platform,ssl,pyexpat; ds=list(importlib.metadata.distributions()); print(json.dumps({"python":platform.python_version(),"openssl":ssl.OPENSSL_VERSION,"expat":pyexpat.EXPAT_VERSION,"packages":sorted((d.metadata["Name"],d.version) for d in ds)}))'
inventory=subprocess.run([str(python),'-I','-c',probe],capture_output=True,env=environment,timeout=30)
(evidence/'inventory.json').write_bytes(inventory.stdout)
assert inventory.returncode==0
data=json.loads(inventory.stdout)
assert data['python']=='3.12.15' and ['pip','26.2.1'] in data['packages']
check=subprocess.run([str(python),'-I','-m','pip','check'],capture_output=True,env=environment,timeout=30)
(evidence/'pip-check.log').write_bytes(check.stdout+check.stderr)
assert check.returncode==0
assert before=={str(p):sha(p.read_bytes()) for p in locks}
receipt={'created_utc':datetime.now(timezone.utc).isoformat(),'seconds':round(time.monotonic()-start,3),
 'python':str(python),'version':data['python'],'packages':len(data['packages']),'pip':'26.2.1',
 'pip_check_exit':0,'locks_unchanged':True,'lock_sources':before,'uv_executable':uv,
 'uv_sha256':sha(Path(uv).read_bytes()),'scope':'Fresh own desktop test/build environment; binary/hash locks, no changes to existing environments, no product tests/build/SCA yet.'}
(evidence/'prepared.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
