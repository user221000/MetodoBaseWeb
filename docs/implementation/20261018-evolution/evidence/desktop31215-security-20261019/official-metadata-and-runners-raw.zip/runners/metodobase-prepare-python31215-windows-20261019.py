from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import time
import urllib.request

root=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-python31215-windows-provenance-20261019')
assert root.is_dir() and not (root/'runtime').exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
release=json.loads((root/'release-20261013.raw.json').read_bytes())
assert release['id']==412262826 and release['immutable'] is True
assets={a['name']:a for a in release['assets']}
name='cpython-3.12.15+20261013-x86_64-pc-windows-msvc-install_only.tar.gz'
asset=assets[name]
assert asset['id']==638902133 and asset['size']==46390009
assert asset['digest']=='sha256:bbc902d4d187ac4914915bf538196a064b49109a33a104965b5164ced5b80a1e'
def download(asset,target):
 assert not target.exists()
 request=urllib.request.Request(asset['browser_download_url'],headers={'User-Agent':'MetodoBase-local-verification'})
 with urllib.request.urlopen(request,timeout=90) as response:
  with target.open('xb') as stream:
   while block:=response.read(1024*1024):stream.write(block)
 assert target.stat().st_size==asset['size']
 assert 'sha256:'+sha(target.read_bytes())==asset['digest']
checks=root/'SHA256SUMS'
download(assets['SHA256SUMS'],checks)
entries={line.split(maxsplit=1)[1].lstrip('*'):line.split()[0] for line in checks.read_text(encoding='utf-8').splitlines() if line.strip()}
assert entries[name]==asset['digest'].removeprefix('sha256:')
archive=root/name
start=time.monotonic()
download(asset,archive)
target=root/'runtime'
target.mkdir()
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers()
 assert len(members)<15000 and sum(m.size for m in members)<450*1024*1024
 seen=set()
 for member in members:
  path=PurePosixPath(member.name)
  assert not path.is_absolute() and '..' not in path.parts and path.parts[0]=='python'
  assert '\\' not in member.name and ':' not in member.name
  assert member.isdir() or member.isfile(), member.name
  folded=member.name.rstrip('/').casefold()
  assert folded not in seen, member.name
  seen.add(folded)
 for member in members:
  dest=target.joinpath(*PurePosixPath(member.name).parts)
  assert dest.resolve().is_relative_to(target.resolve())
  if member.isdir():dest.mkdir(parents=True,exist_ok=True)
  else:
   dest.parent.mkdir(parents=True,exist_ok=True)
   with tar.extractfile(member) as source, dest.open('xb') as stream:
    while block:=source.read(1024*1024):stream.write(block)
python=target/'python/python.exe'
run=subprocess.run([str(python),'-I','-c','import json,platform,sys,ssl,pyexpat;print(json.dumps({"version":platform.python_version(),"architecture":platform.machine(),"prefix":sys.prefix,"openssl":ssl.OPENSSL_VERSION,"expat":pyexpat.EXPAT_VERSION}))'],capture_output=True,timeout=30)
(root/'runtime-inspect.log').write_bytes(run.stdout+run.stderr)
assert run.returncode==0
runtime=json.loads(run.stdout)
assert runtime['version']=='3.12.15' and runtime['architecture'].upper()=='AMD64'
receipt={'created_utc':datetime.now(timezone.utc).isoformat(),'release_id':release['id'],
 'immutable':True,'source':asset['browser_download_url'],'asset_id':asset['id'],
 'archive_bytes':asset['size'],'archive_sha256':sha(archive.read_bytes()),
 'checksums_sha256':sha(checks.read_bytes()),'checksum_entry_matches_API_digest':True,
 'unstripped_variant':True,'runtime':runtime,'python_exe_sha256':sha(python.read_bytes()),
 'archive_members':len(members),'runtime_files':sum(p.is_file() for p in target.rglob('*')),
 'seconds':round(time.monotonic()-start,3),
 'scope':'Hash-verified extraction and interpreter inspection only; no installer, registry/PATH update, existing interpreter overwrite, desktop build or tests. API digest/checksums are same-provider sources; no artifact signature verification claim.'}
(root/'prepared.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
