import hashlib
import json
from pathlib import Path
import urllib.request

out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-python31215-windows-provenance-20261019')
out.mkdir(exist_ok=False)
url='https://api.github.com/repos/astral-sh/python-build-standalone/releases/tags/20261013'
request=urllib.request.Request(url,headers={'User-Agent':'MetodoBase-local-verification','Accept':'application/vnd.github+json'})
with urllib.request.urlopen(request,timeout=60) as response:
    raw=response.read()
(out/'release-20261013.raw.json').write_bytes(raw)
release=json.loads(raw)
assert release['tag_name']=='20261013' and not release['draft'] and not release['prerelease']
matches=[a for a in release['assets'] if a['name'].startswith('cpython-3.12.15+') and 'x86_64-pc-windows-msvc' in a['name'] and 'install_only' in a['name']]
selection={'source':url,'raw_sha256':hashlib.sha256(raw).hexdigest(),'release_id':release['id'],
 'immutable':release.get('immutable'),'published_at':release['published_at'],
 'assets':[{k:a[k] for k in ['id','name','size','digest','browser_download_url']} for a in matches]}
(out/'selection.json').write_text(json.dumps(selection,indent=2)+'\n',encoding='utf-8')
print(json.dumps(selection))
