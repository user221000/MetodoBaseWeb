"""Recompute exact named Git and package-block witnesses for the six-file scan delta."""
from pathlib import Path
from bisect import bisect_right
from collections import Counter, defaultdict
from functools import cache
import ast
import hashlib
import io
import json
import re
import subprocess
import sys
import zipfile

R=Path('F:/MetodoBaseWeb-execution-20261018')
T=Path('C:/Users/Consu/AppData/Local/Temp')
O=T/'metodobase-root-r05-223-proposal-20261020'
HEAD='f0608fb086b08bbd59ce595e9a906c58308d3328';SOURCE='ca09d2f803bcd1e2b977db7b708fa6559c9b5617'
SCAN=T/'metodobase-main-r05-v5-fullscan-private-20261020/full-scan.json'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda o:(json.dumps(o,indent=2)+'\n').encode()
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','-uno').strip() and not O.exists()
acl=(R/'docs/implementation/20261018-evolution/evidence/root-mfa31-reviewed-serial-20261019/archive-acl.ps1').read_text().replace("$names = @('serial-originals.zip')","$names = @('review-originals.zip')",1)
for mode in ['create','verify']:
 done=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command','& {\n'+acl+'\n} -Mode '+mode+" -PrivateRoot '"+str(O)+"'"],capture_output=True,check=True)
 (O/('ACL-'+mode+'.stdout')).write_bytes(done.stdout)
(O/'archive-acl.ps1').write_bytes(acl.encode())
raw_report=SCAN.read_bytes();assert sha(raw_report)=='09b12c693cd6107b9acd42b879ff6e66e308c4edd67edf85fd58d90978258e11'
report=json.loads(raw_report);assert report['remaining_finding_count']==223 and report['source_stable'] and not report['changed_files']
@cache
def blob(commit,name):return git('--no-replace-objects','show',commit+':'+name)
def framed(original,expected):
 if sha(original)==expected:return original,'Git exact'
 assert b'\r' not in original and sha(original.replace(b'\n',b'\r\n'))==expected
 return original.replace(b'\n',b'\r\n'),'Explicit Git LF to captured CRLF'
physical={};frames=[];records={};documents={}
for name in dict.fromkeys(row['file'] for row in report['findings']):
 raw=(R/name).read_bytes();original=blob(SOURCE,name);reviewed,framing=framed(original,sha(raw));assert reviewed==raw
 physical[name]=raw;documents[name]=json.loads(raw)
 target=O/'physical'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 frames.append({'file':name,'git_commit':SOURCE,'git_sha256':sha(original),'source_sha256':sha(raw),'framing':framing})
 records[name]={'path':name,'source_digest':sha(raw),'scanner_digest':sha(raw),'lines':[]}
assert len(physical)==6
# Reuse the previously reviewed structural JSON token reader, as code, never a data producer.
old_tree=ast.parse((T/'metodobase-root-r05-753-review-20261020.py').read_bytes())
node=next(n for n in old_tree.body if isinstance(n,ast.FunctionDef) and n.name=='leaves')
exec(compile(ast.Module(body=[node],type_ignores=[]),'reviewed-json-leaf-reader','exec'))

@cache
def block_witness(commit,name):
 raw=blob(commit,'requirements_web.lock');assert b'\r' not in raw
 # Independent exact physical header offsets, including extras; no package installation.
 starts=[];offset=0
 for line in raw.splitlines(keepends=True):
  hit=re.fullmatch(rb'([A-Za-z0-9][A-Za-z0-9_.-]*)(?:\[[^\]]+\])?==([^\s;\\]+)\s*\\?\r?\n?',line)
  if hit:starts.append((offset,re.sub(rb'[-_.]+',b'-',hit[1]).lower().decode()))
  offset+=len(line)
 assert len(starts)==57 and len({n for _,n in starts})==57
 selected=[(index,start) for index,(start,package) in enumerate(starts) if package==name];assert len(selected)==1
 index,start=selected[0];end=starts[index+1][0] if index+1<len(starts) else len(raw)
 block=raw[start:end];assert b'--hash=sha256:' in block
 return block,{'git_commit':commit,'git_path':'requirements_web.lock','git_blob_sha256':sha(raw),'package':name,'start_byte':start,'end_byte_exclusive':end,'block_sha256':sha(block),'framing':'Git exact LF bytes, exact package header to next active header'}

witnesses=[];pins=defaultdict(lambda:defaultdict(set));kinds=Counter();source_frames=Counter()
for finding in report['findings']:
 name=finding['file'];number=finding['line'];raw=physical[name]
 assert type(number) is int and sha(raw)==finding['file_sha256']
 choices=[(pointer,value) for pointer,(value,start,end) in leaves(name).items() if start==end==number and type(value) is str and re.fullmatch('[0-9a-f]{64}',value)]
 assert len(choices)==1
 pointer,checksum=choices[0];doc=documents[name]
 row={'file':name,'line':number,'rule':finding['rule'],'file_sha256':sha(raw),'physical_line_sha256':sha(raw.split(b'\n')[number-1]),'json_pointer':pointer,'checksum_sha256':checksum}
 if name=='tests/ci_web37/container-inputs.json':
  assert pointer.startswith('/preserved_web_blocks/')
  package=pointer.split('/')[-1];block,witness=block_witness(doc['current_source_head'],package);assert sha(block)==checksum
  row.update(kind='recomputed_named_lock_block_SHA256',logical_source='requirements_web.lock:'+package,witness=witness)
 else:
  if pointer=='/source_auth_sha256':commit='cd3d696711a5355df562ef35d883486d7d320d1c';logical='web/auth.py'
  else:
   if 'source_RAW_sha256' in doc:field='source_RAW_sha256';commit=doc['source_head']
   elif 'source' in doc:field='source';commit=doc['head']
   else:field='sources';commit=doc['candidate']
   assert pointer.startswith('/'+field+'/')
   logical=pointer[len(field)+2:].replace('~1','/').replace('~0','~');assert logical in doc[field]
  original=blob(commit,logical);framed_raw,framing=framed(original,checksum)
  row.update(kind='recomputed_named_source_SHA256',logical_source=logical,witness={'git_commit':commit,'git_path':logical,'git_blob_sha256':sha(original),'framing':framing,'raw_sha256':sha(framed_raw)})
  source_frames[framing]+=1
 assert pointer+'/invalid' not in leaves(name)
 kinds[row['kind']]+=1;witnesses.append(row);pins[name][number].add(finding['rule'])
for name,numbers in pins.items():
 records[name]['lines']=[{'number':number,'digest':sha(physical[name].split(b'\n')[number-1]),'rules':sorted(rules)} for number,rules in sorted(numbers.items())]
assert kinds=={'recomputed_named_source_SHA256':219,'recomputed_named_lock_block_SHA256':4}
assert Counter((r['file'],r['line'],r['rule'],r['file_sha256']) for r in witnesses)==Counter((r['file'],r['line'],r['rule'],r['file_sha256']) for r in report['findings'])
proposal={'schema':1,'version':'8.30.1','scan_source':SOURCE,'scan_report_sha256':sha(raw_report),'config_digest':sha((R/'.gitleaks.toml').read_bytes()),'prior_registry_sha256':sha((R/'scripts/data/reviewed_scan_locations_v5.zip').read_bytes()),'files':list(records.values()),'physical_file_frames':frames,'witnesses':witnesses}
(O/'proposal.json').write_bytes(enc(proposal))
with zipfile.ZipFile(O/'proposal.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('proposal.json',enc(proposal));z.writestr('producer.executed.RAW.py',Path(__file__).read_bytes())
with zipfile.ZipFile(O/'proposal.zip') as z:assert z.read('proposal.json')==enc(proposal) and z.read('producer.executed.RAW.py')==Path(__file__).read_bytes()
sys.path.insert(0,str(R));from scripts.reviewed_scan_locations import ReviewedLocations
inventory={name:sha(raw) for name,raw in physical.items()}
mapped={name:{'source_digest':r['source_digest'],'scanner_digest':r['scanner_digest'],'lines':{(p['number'],rule):p['digest'] for p in r['lines'] for rule in p['rules']}} for name,r in records.items()}
registry=ReviewedLocations(O/'physical',inventory,mapped)
for row in witnesses:assert registry.classify({'StartLine':row['line'],'EndLine':row['line'],'RuleID':row['rule'],'Secret':object(),'Match':None,'Line':{'untrusted':True}},row['file']) is not None
assert all((R/name).read_bytes()==raw for name,raw in physical.items()) and git('rev-parse','HEAD').decode().strip()==HEAD
result={'review_source':HEAD,'scan_source':SOURCE,'points':223,'files':6,'kinds':dict(kinds),'source_framing':dict(source_frames),'named_Git_preimages':blob.cache_info().currsize,'physical_files_quiet':True,'JSON_pointer_negatives':223,'actual_classifier_positive':223,'independent_review_pending':True,'active_registry_or_full_scan_accepted':False,'proposal_zip_sha256':sha((O/'proposal.zip').read_bytes())}
(O/'result.json').write_bytes(enc(result));print(json.dumps(result))
