import json,sys
from pathlib import Path
path,mode,n,s=sys.argv[1:];n=int(n);s=int(s)
r={'checks':[str(i) for i in range(n)],'pageErrors':[],'screens':[str(i) for i in range(s)]}
if mode=='duplicate-checks':r['checks']=['repeated']*n
if mode=='nonstr-check':r['checks'][0]=False
if mode=='duplicate-screens':r['screens']=['repeated']*s
Path(path).parent.mkdir(parents=True,exist_ok=True)
Path(path).write_text('{' if mode=='malformed-report' else json.dumps(r))
