"""Compose two finite reviewed sets in temporary storage; no product writes."""
from pathlib import Path
import hashlib
import io
import json
import zipfile

R=Path('F:/mb-r05-review-classifier-20261019')
O=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r05-reviewed-v2-data-20261019')
assert not O.exists();O.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
old_path=R/'scripts/data/reviewed_scan_locations_v1.zip'
new_path=R/'docs/implementation/20261018-evolution/evidence/root-r05-new-locations-candidate-20261019/candidate-reviewed-locations.zip'
old_raw=old_path.read_bytes();new_raw=new_path.read_bytes()
assert sha(old_raw)=='813f66c2f414065200aff734bffe96ebce6673bd0f20b46f68821686b55c604e'
source=json.loads((new_path.parent/'source.json').read_bytes())
assert sha(new_raw)==source['candidate_dataset_digest']
def read(payload):
    with zipfile.ZipFile(io.BytesIO(payload)) as z:
        assert z.namelist()==['reviewed-locations.json']
        return json.loads(z.read('reviewed-locations.json'))
old=read(old_raw);new=read(new_raw)
assert {k:v for k,v in old.items() if k!='files'}=={k:v for k,v in new.items() if k!='files'}
old_by={r['path']:r for r in old['files']};new_by={r['path']:r for r in new['files']}
assert len(old_by)==534 and len(new_by)==155 and not (old_by.keys()&new_by.keys())
merged={**old, 'files':sorted([*old['files'],*new['files']],key=lambda row:row['path'])}
pins=lambda data:sum(len(line['rules']) for record in data['files'] for line in record['lines'])
assert (pins(old),pins(new),pins(merged))==(31394,14516,45910)
body=json.dumps(merged,ensure_ascii=False,separators=(',',':')).encode()
assert len(body)<16*1024*1024
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w') as z:
    info=zipfile.ZipInfo('reviewed-locations.json',date_time=(1980,1,1,0,0,0))
    info.compress_type=zipfile.ZIP_DEFLATED
    info.external_attr=0o100644<<16
    z.writestr(info,body)
payload=buffer.getvalue()
assert read(payload)==merged
(O/'reviewed_scan_locations_v2.zip').write_bytes(payload)
result={'old_data_digest':sha(old_raw),'approved_candidate_data_digest':sha(new_raw),'combined_digest':sha(payload),'old_files':534,'new_files':155,'combined_files':689,'old_pins':31394,'new_pins':14516,'combined_pins':45910,'input_sets_disjoint':True,'old_records_exact':True,'new_records_exact':True,'uncompressed_bytes':len(body),'bytes':len(payload),'product_changed':False,'global_acceptance':False}
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
