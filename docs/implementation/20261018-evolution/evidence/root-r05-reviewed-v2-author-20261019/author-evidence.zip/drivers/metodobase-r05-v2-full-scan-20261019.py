"""Run the actual scanner on the identified v2 candidate, retaining RED honestly."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time

R=Path('F:/mb-r05-review-classifier-20261019')
T=Path('C:/Users/Consu/AppData/Local/Temp')
O=T/'metodobase-r05-reviewed-v2-author-20261019'
TOOL=T/'metodobase-gitleaks-8.30.1/gitleaks.exe'
HEAD='4f4ed767804f05f8763d32bce67a8e604acc3518'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==HEAD
assert sha(TOOL.read_bytes())=='17157e2ee8b76fc8b1d8bee607a250e34b8a8023c8bc81822d4b5ee4d78fcb7c'
report=O/'current-tree-scan.json';assert not report.exists()
def env_photo():return {'packages':sorted((d.metadata['Name'],d.version) for d in importlib.metadata.distributions()),'python':sha(Path(sys.executable).read_bytes()),'base_python':sha(Path(sys._base_executable).read_bytes()),'scanner':sha(TOOL.read_bytes())}
before=env_photo();(O/'full-scan-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
args=[sys.executable,'-B','-X','utf8','scripts/scan_secrets.py','--gitleaks',str(TOOL),'--report',str(report)]
start=time.monotonic()
with (O/'full-scan.stdout').open('xb') as out,(O/'full-scan.stderr').open('xb') as err:
    done=subprocess.run(args,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8'},stdout=out,stderr=err)
after=env_photo();(O/'full-scan-after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
summary={'head':HEAD,'argv':args,'exit_code':done.returncode,'elapsed_seconds':time.monotonic()-start,'packages_and_binaries_quiet':before==after,'report_created':report.is_file(),'global_acceptance':False}
if report.is_file():
    data=json.loads(report.read_bytes())
    summary.update({k:data[k] for k in ['source_stable','raw_finding_count','classified_finding_count','remaining_finding_count','effective_exit_code']})
    summary['files']=len(data['files']);summary['report_digest']=sha(report.read_bytes())
(O/'full-scan-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary),flush=True)
assert before==after
assert done.returncode in {0,1} and report.is_file()
assert summary['source_stable']
