from pathlib import Path, PurePosixPath
import ast
import hashlib
import io
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile

R=Path('F:/mb-r05-review-classifier-20261019')
T=Path('C:/Users/Consu/AppData/Local/Temp')
O=T/'metodobase-r05-reviewed-v2-author-20261019'
C=T/'metodobase-r05-reviewed-v2-seal-20261019'
PRIVATE=T/'metodobase-r05-reviewed-v2-private-20261019'
P=R/'docs/implementation/20261018-evolution/evidence/root-r05-reviewed-v2-author-20261019'
HEAD='4f4ed767804f05f8763d32bce67a8e604acc3518'
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda v:(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def git(*args):return subprocess.run(['git',*args],cwd=R,capture_output=True,check=True)
assert git('rev-parse','HEAD').stdout.decode().strip()==HEAD
assert not git('status','--porcelain','-uno').stdout.strip()
assert not C.exists() and not PRIVATE.exists() and not P.exists();C.mkdir()
focal=json.loads((O/'focal-summary.json').read_bytes());scan_result=json.loads((O/'full-scan-summary.json').read_bytes())
assert focal['source_quiet'] and all(focal[k]==0 for k in ['test_exit','ruff_exit','pip_before','pip_after'])
cases=ET.parse(O/'focal.xml').findall('.//testcase')
assert len(cases)==110 and all(all(n.find(tag)is None for tag in ['failure','error','skipped']) for n in cases)
assert scan_result['head']==HEAD and scan_result['source_stable'] and scan_result['packages_and_binaries_quiet']
assert (scan_result['raw_finding_count'],scan_result['classified_finding_count'],scan_result['remaining_finding_count'])==(44433,42830,1603)
assert scan_result['exit_code']==scan_result['effective_exit_code']==1
assert sha((O/'current-tree-scan.json').read_bytes())=='363e5f9edb26728edb902ebe3ed46282fe7999a5fb593f09a1871145ce20db9f'
binding=T/'metodobase-qa-r05v2-binding-20261019/receipt.STRUCTURAL.json'
assert sha(binding.read_bytes())=='7cab96d473531b12fcc2da1213a4848bcfa4b06bb03c6e7cdcc0b638bbbdd157'
originals={p.name:p.read_bytes() for p in O.iterdir() if p.is_file()}
originals['independent/qa-binding-receipt.STRUCTURAL.json']=binding.read_bytes()
for name in ['metodobase-r05-v2-data-prepare-20261019.py','metodobase-r05-v2-product-run-20261019.py','metodobase-r05-v2-full-scan-20261019.py','metodobase-r05-v2-seal-20261019.py']:
    originals['drivers/'+name]=(T/name).read_bytes()
originals['union/data-result.json']=(T/'metodobase-r05-reviewed-v2-data-20261019/result.json').read_bytes()
acl_source=Path('F:/MetodoBaseWeb-execution-20261018/docs/implementation/20261018-evolution/evidence/root-mfa31-reviewed-serial-20261019/archive-acl.ps1')
acl=acl_source.read_text()
old="$names = @('serial-originals.zip')";new="$names = @('r05-v2-originals.zip')"
assert acl.count(old)==1;acl=acl.replace(old,new,1)
(C/'archive-acl.ps1').write_bytes(acl.encode())
def protect(mode):
    done=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(C/'archive-acl.ps1'),'-Mode',mode,'-PrivateRoot',str(PRIVATE)],capture_output=True)
    (C/('acl-'+mode+'.stdout')).write_bytes(done.stdout);(C/('acl-'+mode+'.stderr')).write_bytes(done.stderr)
    assert done.returncode==0
    return json.loads(done.stdout.decode('utf-8-sig'))
protect('create');verified=protect('verify');assert verified['verified_before_payload']
archive=PRIVATE/'r05-v2-originals.zip';assert archive.stat().st_size==0
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name,blob in originals.items():z.writestr(name,blob)
with zipfile.ZipFile(archive) as z:assert set(z.namelist())==set(originals) and all(z.read(n)==b for n,b in originals.items())
closed=protect('final')
assert all((O/n).read_bytes()==b for n,b in originals.items() if '/'not in n)
definition=next(n for n in ast.parse((T/'metodobase-checkpoint119-prepare.py').read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='scan')
exec(compile(ast.Module(body=[definition],type_ignores=[]),'scanner119','exec'))
for name,blob in originals.items():scan(blob,name)
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
    for name,blob in originals.items():z.writestr(name,blob)
freeze=json.loads((O/'product-freeze.json').read_bytes())
summary={'product_head':HEAD,'focused_passed':110,'ruff_exit':0,'pip_before':0,'pip_after':0,'packages':92,'source_files_quiet':844,'combined_files':689,'combined_pins':45910,'algorithm_changed':False,'three_literals_only':True,'independent_new_data_review':'f008fe99604978cc92f47e97e0113e0332fda256','independent_binding_receipt_digest':sha(binding.read_bytes()),'full_scan':scan_result,'global_R05_acceptance':False}
source={'product_head':HEAD,'products':freeze['products'],'mutation':json.loads((O/'mutation.json').read_bytes()),'source_before_after_exact':True,'original_members':[{'path':n,'bytes':len(b),'digest':sha(b)} for n,b in originals.items()],'private_archive':{'basename':archive.name,'digest':sha(archive.read_bytes()),'members':len(originals)},'private_ACL_before_payload':verified,'private_ACL_final':closed,'original_execution_directory_ACL_at_creation_attested':False,'public_RAW_members_exact':True,'global_R05_acceptance':False}
review='''# Registro finito R05 revisión2

Producto4f4ed767804f05f8763d32bce67a8e604acc3518. Sólo añade ZIPv2 y cambia
tres literales del módulo: ruta,digest ymetadato de revisión. Inversa RAW/AST
exacta; algoritmo sin cambios. ZIPv1 conservado. Unión disjunta exacta de534+155
archivos y31.394+14.516pins:689archivos/45.910pins. Formato JSON esquema1.

SECf008 verificó las14.557ocurrencias nuevas y113controles; su recibo opcional
verificó la uniónc5eb. QA revisó por separado el binding de los tres literales y
la igualdad de ambos conjuntos, sin reatribuir revisión semántica o escaneo.
110pruebas mantenidas PASS,Ruff/pip0,844fuentes/92paquetes yambosPython quietos.

Escaneo real de12.793archivos enesta fuente:44.433hallazgos brutos,42.830
clasificados y1.603bloqueantes nuevos. Fuente estable ysalida1 bruta/efectiva.
Esto confirma la clasificación real de las ubicaciones revisadas anteriores;
no es PASS global. Los1.603requieren triage yrevisión propios. No se usan
Match/Secret/Line como autoridad. Informe saneado completo yoriginales exactos
retenidos. Los archivos de evidencia añadidos después no se reatribuyen aese
escaneo; la release final requerirá su propio gate sobre fuente estable.

Sin PostgreSQL,Chrome,Linux,desktop ni proveedor real enesta fase. La copia
privada fue protegida antes del payload yverificada tras readback; no hay
atestación retroactiva de ACL del directorio original de ejecución.
'''
public={'.gitattributes':b'* -text\n','author-evidence.zip':buffer.getvalue(),'archive-acl.ps1':(C/'archive-acl.ps1').read_bytes(),'summary.json':enc(summary),'source.json':enc(source),'review.md':review.encode()}
for name,blob in public.items():scan(blob,name)
P.mkdir();(P/'.gitattributes').write_bytes(public.pop('.gitattributes'))
for name,blob in public.items():(P/name).write_bytes(blob)
manifest={p.name:{'bytes':p.stat().st_size,'digest':sha(p.read_bytes())} for p in P.iterdir() if p.is_file()}
(P/'manifest.json').write_bytes(enc(manifest))
prefix=P.relative_to(R).as_posix();git('-c','core.autocrlf=false','add','-f','--',prefix)
git('diff','--cached','--check')
for p in P.iterdir():assert git('show',':'+p.relative_to(R).as_posix()).stdout==p.read_bytes()
git('commit','-m','Seal reviewed registry v2 and retain current blocking full scan')
result={'head':git('rev-parse','HEAD').stdout.decode().strip(),'product_head':HEAD,'files':len(manifest)+1,'source_digest':sha((P/'source.json').read_bytes()),'manifest_digest':sha((P/'manifest.json').read_bytes()),'global_R05_acceptance':False}
(C/'result.json').write_bytes(enc(result));print(json.dumps(result))
