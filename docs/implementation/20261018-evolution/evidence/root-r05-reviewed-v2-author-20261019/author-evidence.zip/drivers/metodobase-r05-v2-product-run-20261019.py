"""Install the independently bound union with only registry identity changes."""
from pathlib import Path
import ast
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys

R=Path('F:/mb-r05-review-classifier-20261019')
T=Path('C:/Users/Consu/AppData/Local/Temp')
O=T/'metodobase-r05-reviewed-v2-author-20261019'
assert not O.exists();O.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda v:(json.dumps(v,indent=2)+'\n').encode()
def git(*a):return subprocess.run(['git',*a],cwd=R,capture_output=True,check=True)
BASE='e0da4c551f67ad3bff286041e77ab8b7c9be81f2'
assert git('rev-parse','HEAD').stdout.decode().strip()==BASE
assert not git('status','--porcelain','-uno').stdout.strip()
module=R/'scripts/reviewed_scan_locations.py'
original=module.read_bytes();(O/'module-before.py').write_bytes(original)
union=(T/'metodobase-r05-reviewed-v2-data-20261019/reviewed_scan_locations_v2.zip').read_bytes()
assert sha(union)=='c5ebf029fad80a13b36fb27e5ffd676a1a8234208f25328c4c2c2246ca680d91'
replacements=[
 (b'scripts/data/reviewed_scan_locations_v1.zip',b'scripts/data/reviewed_scan_locations_v2.zip'),
 (b'813f66c2f414065200aff734bffe96ebce6673bd0f20b46f68821686b55c604e',b'c5ebf029fad80a13b36fb27e5ffd676a1a8234208f25328c4c2c2246ca680d91'),
 (b'finite independently reviewed non-credential evidence; registry v1',b'finite independently reviewed non-credential evidence; registry v2'),
]
changed=original
for before,after in replacements:
    assert changed.count(before)==1;changed=changed.replace(before,after,1)
inverse=changed
for before,after in reversed(replacements):inverse=inverse.replace(after,before,1)
assert inverse==original
old_tree=ast.parse(original);new_tree=ast.parse(inverse)
assert ast.dump(old_tree,include_attributes=False)==ast.dump(new_tree,include_attributes=False)
target=R/'scripts/data/reviewed_scan_locations_v2.zip';assert not target.exists()
target.write_bytes(union);module.write_bytes(changed)
(O/'mutation.json').write_bytes(enc({'base':BASE,'full_inverse_exact':True,'three_literals_only':True,'algorithm_AST_after_inverse_exact':True,'old_module_digest':sha(original),'new_module_digest':sha(changed),'union_digest':sha(union),'v1_zip_preserved':sha((R/'scripts/data/reviewed_scan_locations_v1.zip').read_bytes())=='813f66c2f414065200aff734bffe96ebce6673bd0f20b46f68821686b55c604e'}))
paths=[p for p in git('ls-files','-z').stdout.decode().split('\0') if p and not p.startswith('docs/') and Path(p).suffix.lower() in {'.py','.js','.html','.css','.txt','.toml','.ini','.json','.yaml','.yml','.lock','.zip'}]
paths.append('scripts/data/reviewed_scan_locations_v2.zip')
def photo():
    return {'source':{p:sha((R/p).read_bytes()) for p in paths if (R/p).is_file()},'packages':sorted((d.metadata['Name'],d.version) for d in importlib.metadata.distributions()),'python_sha256':sha(Path(sys.executable).read_bytes()),'base_python_sha256':sha(Path(sys._base_executable).read_bytes()),'python':sys.version}
before=photo();(O/'before.json').write_bytes(enc(before))
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8'}
def run(name,args):
    with (O/(name+'.stdout')).open('xb') as out,(O/(name+'.stderr')).open('xb') as err:
        result=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=err)
    return result.returncode
pip_before=run('pip-before',[sys.executable,'-m','pip','check'])
test=run('focal',[sys.executable,'-B','-m','pytest','tests/test_secret_scan_reviewed_locations.py','tests/test_secret_scan_fragment_pins.py','tests/test_secret_scan_safety.py','-q','--no-cov','--junitxml='+str(O/'focal.xml')])
ruff=run('ruff',[str(T/'metodobase-qa-20261018/Scripts/python.exe'),'-m','ruff','check','scripts/reviewed_scan_locations.py','scripts/scan_secrets.py','tests/test_secret_scan_reviewed_locations.py'])
pip_after=run('pip-after',[sys.executable,'-m','pip','check'])
after=photo();(O/'after.json').write_bytes(enc(after))
summary={'source_quiet':before==after,'source_files':len(before['source']),'packages':len(before['packages']),'test_exit':test,'ruff_exit':ruff,'pip_before':pip_before,'pip_after':pip_after,'old_files':534,'new_files':155,'combined_files':689,'old_pins':31394,'new_pins':14516,'combined_pins':45910,'algorithm_changed':False,'full_scan_executed':False,'global_acceptance':False}
(O/'focal-summary.json').write_bytes(enc(summary))
assert before==after and (pip_before,test,ruff,pip_after)==(0,0,0,0)
git('-c','core.autocrlf=false','add','--','scripts/reviewed_scan_locations.py','scripts/data/reviewed_scan_locations_v2.zip')
git('diff','--cached','--check')
for p in ['scripts/reviewed_scan_locations.py','scripts/data/reviewed_scan_locations_v2.zip']:assert git('show',':'+p).stdout==(R/p).read_bytes()
git('commit','-m','Bind reviewed scan registry v2 to independently verified finite union')
head=git('rev-parse','HEAD').stdout.decode().strip()
(O/'product-freeze.json').write_bytes(enc({'head':head,'products':{p:sha((R/p).read_bytes()) for p in ['scripts/reviewed_scan_locations.py','scripts/data/reviewed_scan_locations_v2.zip']},**summary}))
print(json.dumps({'head':head,**summary}))
