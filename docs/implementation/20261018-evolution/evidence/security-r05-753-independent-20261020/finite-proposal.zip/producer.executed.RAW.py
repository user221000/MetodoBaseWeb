import hashlib,json,os,pathlib,subprocess,zipfile
from collections import Counter
root=pathlib.Path('F:/mb-security-r05-753-peer-20261020');private=pathlib.Path(os.environ['TEMP'])/'metodobase-security-r05-753-private-20261020'
source='8d6b18521c719ff789ebd32c493457b6810b2b48';sha=lambda b:hashlib.sha256(b).hexdigest()
report_path=pathlib.Path(os.environ['TEMP'])/'metodobase-main-r05-v4-fullscan-private-20261020/full-scan.json';report_raw=report_path.read_bytes();assert sha(report_raw)=='d551cc8a4bd3eb9c664bcab4d31e0f3faab5e4800aa33d4f0b64cb59b0df8faf';report=json.loads(report_raw)
indexed=json.loads((private/'indexed-private.json').read_bytes());api=json.loads((private/'api-git-witnesses.json').read_bytes());snapshot=private/'snapshot'
cache={};witnesses=[];records={};framing_counts=Counter();node=pathlib.Path('C:/Program Files/nodejs/node.exe');node_hash=sha(node.read_bytes());node_checks=[]
def git_blob(commit,name):
    key=commit,name
    if key not in cache:
        data=subprocess.check_output(['git','--no-replace-objects','show',commit+':'+name],cwd=root)
        oid=subprocess.check_output(['git','--no-replace-objects','rev-parse',commit+':'+name],cwd=root,text=True).strip();cache[key]=(data,oid)
    return cache[key]
def raw_witness(data,kind):
    if kind=='Git exact':return data
    assert kind=='Git LF to CRLF' and b'\r' not in data
    framed=data.replace(b'\n',b'\r\n');assert framed.replace(b'\r\n',b'\n')==data
    return framed
for row in indexed['findings']:
    name=row['file'];assert name and ':' not in name and '\\' not in name and not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts
    physical=(snapshot/name).read_bytes();assert sha(physical)==row['file_sha256']==report['files'][name]
    line=physical.split(b'\n')[row['line']-1];assert sha(line)==row['physical_line_sha256']
    base={'file':name,'line':row['line'],'rule':row['rule'],'file_sha256':row['file_sha256'],'physical_line_sha256':sha(line)}
    record=records.setdefault(name,{'path':name,'source_digest':row['file_sha256'],'scanner_digest':row['file_sha256'],'lines':[]})
    record['lines'].append({'number':row['line'],'digest':sha(line),'rules':[row['rule']]})
    if row['leaves']:
        leaf=row['leaves'][0];logical=leaf['path'][-1];assert leaf['path'][:-1] in [['after_source'],['before_source'],['protected_exact_base'],['source'],['source_RAW_sha256'],['source_sha256'],['sources']]
        actual=json.loads(physical)
        for key in leaf['path']:actual=actual[key]
        assert actual==leaf['value'];commit=source;data,oid=git_blob(commit,logical)
        if sha(data)==actual:kind='Git exact'
        elif b'\r' not in data and sha(data.replace(b'\n',b'\r\n'))==actual:kind='Git LF to CRLF'
        else:
            prior=api[actual];assert logical=='web/static/js/api.js';commit=prior['commit'];data,oid=git_blob(commit,logical)
            kind='Git exact' if prior['framing']=='Git' else 'Git LF to CRLF'
        raw=raw_witness(data,kind);assert sha(raw)==actual
        # A checksum of exact named Git source bytes establishes semantic
        # non-credential provenance. Hex shape only indexed candidates earlier.
        witnesses.append({**base,'kind':'recomputed_named_source_SHA256','json_pointer':leaf['pointer'],'logical_source':logical,'checksum_sha256':actual,'witness':{'git_commit':commit,'git_blob':oid,'git_blob_sha256':sha(data),'raw_sha256':sha(raw),'bytes':len(raw),'framing':kind}});framing_counts[kind]+=1
    else:
        expected=b" assert.equal(vm.runInContext('Api.notifications36 === globalThis.api.notifications36',e.auth.context),true);"
        assert line.rstrip(b'\r')==expected
        git,oid=git_blob(source,name);assert physical.replace(b'\r\n',b'\n')==git
        p=subprocess.run([str(node),'--check',str(snapshot/name)],capture_output=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),timeout=15)
        assert p.returncode==0;(private/(str(len(node_checks))+'-node-check.stdout.RAW')).write_bytes(p.stdout);(private/(str(len(node_checks))+'-node-check.stderr.RAW')).write_bytes(p.stderr)
        node_checks.append({'file':name,'exit':p.returncode});witnesses.append({**base,'kind':'exact_VM_namespace_identity_assertion','witness':{'git_commit':source,'git_blob':oid,'git_blob_sha256':sha(git),'framing':'Git exact' if physical==git else 'Git LF to CRLF','semantic':'VM Api namespace equality with global alias, boolean assertion; no credential material','node_syntax_check_exit':0}})
assert sha(node.read_bytes())==node_hash
files=sorted(records.values(),key=lambda r:r['path'])
for record in files:
    record['lines'].sort(key=lambda p:p['number']);assert len({p['number'] for p in record['lines']})==len(record['lines'])
assert len(files)==20 and len(witnesses)==753 and sum(len(p['rules']) for r in files for p in r['lines'])==753
with zipfile.ZipFile(root/'scripts/data/reviewed_scan_locations_v4.zip') as z:old=json.loads(z.read('reviewed-locations.json'))
assert not {r['path'] for r in files}&{r['path'] for r in old['files']}
assert sha((root/'.gitleaks.toml').read_bytes())==old['config_digest']==report['files']['.gitleaks.toml']
proposal={'scope':'Independent finite proposal only; not loaded by scanner or global acceptance','scan_source':source,'scan_report_sha256':sha(report_raw),'scanner_version':report['version'],'config_digest':old['config_digest'],'prior_registry_sha256':sha((root/'scripts/data/reviewed_scan_locations_v4.zip').read_bytes()),'prior_file_count':len(old['files']),'prior_pin_count':sum(len(p['rules']) for r in old['files'] for p in r['lines']),'files':files,'witnesses':witnesses,'physical_file_frames':indexed['frames'],'witness_summary':{'named_source_checksums':750,'checksum_frames':dict(framing_counts),'literal_namespace_assertions':3,'node_sha256':node_hash,'node_syntax_checks':node_checks},'limitations':'Exact20 files/753 physical locations and rules only. No shape-based classification, Match/Secret authority, general EOL rule, classifier/loader/data/Main edit, new scan or globalPASS. Desktop-named historical source bytes are hashed as metadata only; no Desktop runtime/work.'}
raw=json.dumps(proposal,indent=2).encode()+b'\n';(private/'proposal.json').write_bytes(raw)
out=root/'docs/implementation/20261018-evolution/evidence/security-r05-753-independent-20261020';out.mkdir()
archive=out/'finite-proposal.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('proposal.json',raw);z.writestr('producer.executed.RAW.py',pathlib.Path(__file__).read_bytes())
with zipfile.ZipFile(archive) as z:assert z.read('proposal.json')==raw and z.read('producer.executed.RAW.py')==pathlib.Path(__file__).read_bytes()
print(json.dumps({'locations':753,'files':20,'checksum_witnesses':750,'checksum_frames':dict(framing_counts),'literal_assertions':3,'proposal_json_sha256':sha(raw),'proposal_zip_sha256':sha(archive.read_bytes()),'proposed_total_files':len(old['files'])+20,'proposed_total_pins':proposal['prior_pin_count']+753}))
