"""Apply the preserved late-cursor criteria to the bounded UNION reader."""
from pathlib import Path

before=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-history-late-cursor-before-20261019.py')
source=before.read_text(encoding='utf-8')
source=source.replace('metodobase-history-late-cursor-before-20261019', 'metodobase-history-late-cursor-after-20261019')
old="assert work>51, 'Existing late-cursor query unexpectedly bounded; inspect before proposing query changes'"
new="assert work<=51, 'The all-dated late page still visits more than51 candidates'"
assert source.count(old)==1
source=source.replace(old,new)
source=source.replace("'confirmed_late_cursor_work_not_bounded_by_page'", "'late_cursor_51_candidates_preserves_page'")
source=source.replace('An extra index alone still leaves late cursor work above the51-candidate budget.', 'The bounded UNION query plus index visits at most51 candidates for this all-dated corpus. Each mixed dated/NULL branch is separately capped at51; general maximum102 requires its own mixed corpus gate.')
exec(compile(source,str(before)+'::bounded-reader-replay','exec'),globals())
