"""Preserve the existing late-cursor query's physical work with the proposed index."""
import asyncio
import hashlib
from pathlib import Path

original=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-history-index-probe-20261019.py')
source=original.read_text(encoding='utf-8')
prefix=source[:source.index('\ntry:\n')]
prefix=prefix.replace("OUT=TEMP/'metodobase-history-index-probe-20261019'", "OUT=TEMP/'metodobase-history-late-cursor-before-20261019'")
prefix=prefix.replace("commit='66d9dec0e15dd873038bd248d3883daeeb27d4ca'", "commit='50085ad3ea9f0f43962e0d052f98e7e43a760676'")
# Resolve the cherry-picked core's full SHA without changing its source.
import subprocess
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd='F:/mb-hidx-20261019',text=True).strip()
assert head.startswith('50085ad')
prefix=prefix.replace("commit='50085ad3ea9f0f43962e0d052f98e7e43a760676'", 'commit='+repr(head))
exec(compile(prefix,str(original)+'::frozen-fixture-prefix','exec'),globals())
from fastapi import Response
from sqlalchemy import event
from sqlalchemy.orm import Session
from web.auth import identity_from_user
from web.database.models import PlanGenerado,Usuario
from web.routes.usuario import historial_planes
from web.services.personal_history_cursor import encode_position
from web.settings import get_settings

application=None
try:
    with h.owned_database(private) as (url,admin,cleanup):
        run_migration(url,'db_bootstrap.py','--revision','20261019_client_account_links')
        application=application_engine(url,admin)
        h.seed(admin,application)
        with admin.begin() as db:
            db.execute(text(ddl))
            db.execute(text('ANALYZE planes_generados'))
            db.execute(text('ANALYZE clientes'))
        captured=[]
        def observe(connection,cursor,statement,parameters,context,executemany):
            if 'FROM planes_generados' in statement and 'LIMIT' in statement:
                captured.append((statement,parameters))
        with tenant_scope('load-person-4'),Session(application) as db:
            identity=identity_from_user(db.get(Usuario,'load-person-4'),db)
            anchor=db.query(PlanGenerado).order_by(PlanGenerado.fecha_generacion.desc().nulls_last(),PlanGenerado.id.desc()).offset(900).first()
            cursor=encode_position(anchor.fecha_generacion,anchor.id,secret=get_settings().SECRET_KEY,subject='load-person-4',profile='load-self-4')
            event.listen(application,'before_cursor_execute',observe)
            try:
                response=asyncio.run(historial_planes(Response(),limit=50,cursor=cursor,usuario=identity,db=db))
            finally:
                event.remove(application,'before_cursor_execute',observe)
            assert len(response['planes'])==50 and response['planes'][0]['id']==902 and response['next_cursor']
            assert len(captured)==1
            statement,parameters=captured[0]
            plan=db.connection().exec_driver_sql('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+statement,parameters).scalar_one()
            nodes=list(walk(plan[0]['Plan']))
            plan_nodes=[n for n in nodes if n.get('Relation Name')=='planes_generados']
            work=sum((n.get('Actual Rows',0)+n.get('Rows Removed by Filter',0)+n.get('Rows Removed by Index Recheck',0))*n.get('Actual Loops',1) for n in plan_nodes)
            assert work>51, 'Existing late-cursor query unexpectedly bounded; inspect before proposing query changes'
            db.rollback()
        (OUT/'query-and-plan.json').write_text(json.dumps({'sql':statement,'parameters':parameters,'plan':plan},default=str,indent=2)+'\n',encoding='utf-8')
        summary={'source_commit':head,'outcome':'confirmed_late_cursor_work_not_bounded_by_page','anchor_offset':900,'first_returned_id':902,'returned':50,'candidate_limit':51,'proposed_index_present':True,'actual_plan_row_work':work,'plan_nodes':[{'type':n['Node Type'],'relation':n.get('Relation Name'),'index':n.get('Index Name'),'rows':n.get('Actual Rows'),'removed_filter':n.get('Rows Removed by Filter',0),'loops':n.get('Actual Loops')} for n in nodes],'source_route_sha256':sha((ROOT/'web/routes/usuario.py').read_bytes()),'fixture_driver_sha256':sha(original.read_bytes()),'scope':'Actual existing route function with persisted synthetic identity, restricted PostgreSQL app and tenant; original query captured and explained. No HTTP/auth-overrides claim, latency benchmark, SLO or production migration. An extra index alone still leaves late cursor work above the51-candidate budget.'}
        application.dispose();application=None
    assert cleanup['owned_uuid_database_removed']
    summary['owned_database_removed_and_absence_checked']=True
    summary['sources_stable']=before==photo();assert summary['sources_stable']
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:summary[k] for k in ['outcome','actual_plan_row_work','returned','owned_database_removed_and_absence_checked','sources_stable']}))
except Exception as error:
    if application is not None:application.dispose()
    (OUT/'failure-private.log').write_text(traceback.format_exc(),encoding='utf-8')
    print(json.dumps({'outcome':'incomplete','error_class':type(error).__name__}))
    raise SystemExit(1)
