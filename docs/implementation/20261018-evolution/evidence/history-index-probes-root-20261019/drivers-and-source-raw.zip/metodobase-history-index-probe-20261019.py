"""Functional query-plan experiment in an owned UUID DB; no HTTP latency benchmark."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

ROOT=Path('F:/mb-hidx-20261019')
MAIN=Path('F:/MetodoBaseWeb-execution-20261018')
TEMP=Path('C:/Users/Consu/AppData/Local/Temp')
OUT=TEMP/'metodobase-history-index-probe-20261019'
OUT.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
commit='66d9dec0e15dd873038bd248d3883daeeb27d4ca'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==commit
driver=MAIN/'docs/implementation/20261018-evolution/evidence/history-pg200-independent-20261019/run_history200.py'
assert sha(driver.read_bytes())=='4592fb1782e6d19ee1ff61f65d59eb63583313e3d109875ae29a13c5082dca10'
spec=importlib.util.spec_from_file_location('frozen_history200',driver)
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
h.ROOT=ROOT
sys.path=[p for p in sys.path if p!=str(MAIN)]
sys.path.insert(0,str(ROOT))
sys.dont_write_bytecode=True
os.environ['METODOBASE_HISTORY200_OUTPUT']=str(OUT)
h.isolated_environment()
os.environ['METODOBASE_HISTORY200_OUTPUT']=str(OUT)
from sqlalchemy import text
from tests.integration_schema_migrations import run_migration
from tests.integration_provider_subjects import application_engine
from web.database.tenant_context import tenant_scope
from web.database.tenant_policy import tenant_security_signature
from web.database.alembic.schema_contract_v1 import schema_signature

names=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')[:-1]
names=[n for n in names if not n.startswith('docs/')]
photo=lambda:{n:sha((ROOT/n).read_bytes()) for n in names}
before=photo()
capture=MAIN/'docs/implementation/20261018-evolution/evidence/history-pg200-independent-20261019/run-66d9dec-20261019T1112/actual-history-query.json'
query=json.loads(capture.read_text(encoding='utf-8'))
ddl='CREATE INDEX ix_planes_gym_cliente_history ON planes_generados (gym_id, id_cliente, fecha_generacion DESC NULLS LAST, id DESC) WHERE deleted_at IS NULL'
private=TEMP/'metodobase-qa-pg55483-private-ok6hrpyq/env.json'
application=None
summary={'source_commit':commit,'scope':'Functional plan/ordering experiment only; original28 migrations followed by an explicit extra index in one owned UUID DB. No migrated revision30, HTTP, p95/SLO, app startup after DDL or production rollout claim. Concurrent desktop and functional tests make execution timings descriptive only.','ddl':ddl,'frozen_harness_sha256':sha(driver.read_bytes()),'captured_query_sha256':sha(capture.read_bytes())}

def explain_and_rows(application):
    with tenant_scope('load-person-4'),application.connect() as db:
        role=tuple(db.execute(text('SELECT rolsuper,rolbypassrls,rolcreatedb,rolcreaterole FROM pg_roles WHERE rolname=current_user')).one())
        assert role==(False,False,False,False)
        assert db.execute(text("SELECT current_setting('app.current_tenant',true)")).scalar_one()=='load-person-4'
        plan=db.exec_driver_sql('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+query['sql'],query['parameters']).scalar_one()
        first=[tuple(row) for row in db.exec_driver_sql(query['sql'],query['parameters'])]
        # The unbounded raw SQL below is only a 1000-row test oracle, never an HTTP option.
        all_rows=[tuple(row) for row in db.exec_driver_sql(query['sql'],{**query['parameters'],'param_1':1100})]
        db.rollback()
    assert len(first)==51 and len(all_rows)==1000 and first==all_rows[:51]
    return plan,first,all_rows

def walk(node):
    yield node
    for child in node.get('Plans',[]):yield from walk(child)

try:
    with h.owned_database(private) as (url,admin,cleanup):
        run_migration(url,'db_bootstrap.py','--revision','20261019_account_recovery')
        application=application_engine(url,admin)
        _,seed=h.seed(admin,application)
        with admin.begin() as db:
            # Identical NULL/tie corpus before and after the new index.
            db.execute(text("UPDATE planes_generados SET fecha_generacion=NULL WHERE id IN (SELECT id FROM planes_generados ORDER BY id DESC LIMIT10)".replace('LIMIT10','LIMIT 10')))
            db.execute(text("UPDATE planes_generados SET fecha_generacion=TIMESTAMP '2026-10-20 00:00:00' WHERE id IN (SELECT id FROM planes_generados ORDER BY id LIMIT 5)"))
            db.execute(text('ANALYZE planes_generados'))
            db.execute(text('ANALYZE clientes'))
        with admin.connect() as db:
            signature_before=schema_signature(db);security_before=tenant_security_signature(db)
        plan_before,first_before,all_before=explain_and_rows(application)
        (OUT/'before-plan.json').write_text(json.dumps(plan_before,indent=2)+'\n',encoding='utf-8')
        with admin.begin() as db:db.execute(text(ddl))
        plan_after,first_after,all_after=explain_and_rows(application)
        (OUT/'after-plan.json').write_text(json.dumps(plan_after,indent=2)+'\n',encoding='utf-8')
        assert first_after==first_before and all_after==all_before
        assert [row[0] for row in all_after[:5]]==[5,4,3,2,1]
        assert all(row[1] is None for row in all_after[-10:])
        nodes_after=list(walk(plan_after[0]['Plan']))
        target=[n for n in nodes_after if n.get('Relation Name')=='planes_generados']
        assert len(target)==1 and target[0].get('Index Name')=='ix_planes_gym_cliente_history'
        assert target[0]['Actual Rows']==51 and target[0]['Actual Loops']==1
        assert not any(n['Node Type']=='Sort' for n in nodes_after)
        with admin.connect() as db:
            signature_after=schema_signature(db);security_after=tenant_security_signature(db)
            catalog=db.execute(text("SELECT pg_get_indexdef(c.oid),i.indisvalid,i.indisready,i.indoption::text FROM pg_index i JOIN pg_class c ON c.oid=i.indexrelid WHERE c.relname='ix_planes_gym_cliente_history'")).one()
        assert security_before==security_after
        prior=signature_after['tables']['planes_generados']['indexes']
        added=[item for item in prior if item['name']=='ix_planes_gym_cliente_history']
        assert len(added)==1
        signature_after['tables']['planes_generados']['indexes']=[item for item in prior if item['name']!='ix_planes_gym_cliente_history']
        assert signature_before==signature_after
        summary.update(seed=seed,ordered_rows_preserved=1000,null_rows_preserved=10,tied_first_ids=[5,4,3,2,1],before_plan_nodes=[{'type':n['Node Type'],'relation':n.get('Relation Name'),'index':n.get('Index Name'),'rows':n.get('Actual Rows'),'loops':n.get('Actual Loops')} for n in walk(plan_before[0]['Plan'])],after_plan_nodes=[{'type':n['Node Type'],'relation':n.get('Relation Name'),'index':n.get('Index Name'),'rows':n.get('Actual Rows'),'loops':n.get('Actual Loops')} for n in nodes_after],catalog={'definition':catalog[0],'valid':catalog[1],'ready':catalog[2],'indoption':catalog[3]},all_prior_structures_and_20_rls_families_unchanged=True,role_restricted=True,tenant_verified=True)
        application.dispose();application=None
    assert cleanup['owned_uuid_database_removed']
    summary['owned_database_removed_and_absence_checked']=True
    summary['source_count']=len(before);summary['sources_stable']=before==photo()
    assert summary['sources_stable']
    summary['source_aggregate_sha256']=sha(json.dumps(before,sort_keys=True,separators=(',',':')).encode())
    summary['outcome']='functional_index_probe_passed'
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:summary[k] for k in ['outcome','source_count','sources_stable','ordered_rows_preserved','owned_database_removed_and_absence_checked']}))
except Exception as error:
    if application is not None:application.dispose()
    (OUT/'failure-private.log').write_text(traceback.format_exc(),encoding='utf-8')
    (OUT/'incomplete.json').write_text(json.dumps({'outcome':'incomplete','error_class':type(error).__name__,'scope':summary['scope']},indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'outcome':'incomplete','error_class':type(error).__name__}))
    raise SystemExit(1)
