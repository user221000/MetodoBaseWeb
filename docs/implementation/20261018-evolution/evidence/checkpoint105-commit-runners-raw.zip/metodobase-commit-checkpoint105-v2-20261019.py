import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path('F:/MetodoBaseWeb-execution-20261018')
run = root / 'docs/implementation/20261018-evolution'
ev = run / 'evidence'
temp = Path('C:/Users/Consu/AppData/Local/Temp')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip().startswith('6b0dc01')
docs = ['CAMBIOS.md','CARGA_LOCAL.md','ENTREGA.md','ESTADO.md','RIESGOS.md','TRAZABILIDAD.json','TRAZABILIDAD.md','VALIDACION.md']
folders = ['qa-integrated28-history-landing-postfix-20261019','r12-contract-security-review-20261019','r12-root-mechanism-review-20261019','linux-recovery28-image-abd559a','desktop31215-security-20261019','owned-export-fixture-cleanup-20261019']
receipt = ev / 'checkpoint105-raw-preservation.json'
assert not receipt.exists()
bundle = ev / 'checkpoint105-commit-runners-raw.zip'
assert not bundle.exists()
with zipfile.ZipFile(bundle,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for path in [temp/'metodobase-commit-checkpoint105-20261019.py',Path(__file__)]:
        z.writestr(path.name,path.read_bytes())
paths = [ev/'checkpoint105-local-source.json',ev/'checkpoint105-driver.py',bundle]
for folder in folders:
    paths.extend(p for p in (ev/folder).rglob('*') if p.is_file())
relative = sorted(p.relative_to(root).as_posix() for p in paths)
assert len(relative) == len(set(relative))
for start in range(0,len(relative),30):
    subprocess.run(['git','-c','core.autocrlf=false','add','-f','--',*relative[start:start+30]],cwd=root,check=True,capture_output=True)

def verify(names):
    data = subprocess.check_output(['git','cat-file','--batch'],cwd=root,input=''.join(':'+n+'\n' for n in names).encode())
    offset = 0
    hashes = {}
    for name in names:
        end = data.index(b'\n',offset)
        header = data[offset:end].split()
        assert header[1] == b'blob', name
        size = int(header[2])
        blob = data[end+1:end+1+size]
        offset = end+1+size+1
        raw = (root/name).read_bytes()
        assert blob == raw, name
        hashes[name] = sha(raw)
    assert offset == len(data)
    return hashes

hashes = verify(relative)
staged = subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1]
allowed = set(relative+[(run/n).relative_to(root).as_posix() for n in docs])
assert set(staged) == allowed, (set(staged)-allowed,allowed-set(staged))
subprocess.run(['git','diff','--cached','--check','--',*((run/n).relative_to(root).as_posix() for n in docs)],cwd=root,check=True)
# The staged set was just checked against exact ownership. Avoid a >32K Windows argv.
check = subprocess.run(['git','diff','--cached','--check'],cwd=root,capture_output=True)
observations = check.stdout+check.stderr
receipt.write_text(json.dumps({'checkpoint':105,'raw_files':len(relative),'raw_git_index_byte_identical':True,'git_add_override':'core.autocrlf=false only for exact new evidence paths','all_compared_pairs_sha256':sha(json.dumps(hashes,sort_keys=True,separators=(',',':')).encode()),'raw_whitespace_check_exit':check.returncode,'raw_whitespace_observation_lines':len(observations.splitlines()),'raw_whitespace_observations_sha256':sha(observations),'prep_erratum':'First commit helper hit Windows WinError206 at whitespace-check argv after staging and byte verification, before commit. Original helper retained; v2 uses the already ownership-checked staged set without a long path argv. No product/test/result changed.','policy':'Evidence bytes including original line endings and whitespace retained. Source/docs whitespace check passed separately. No historical evidence or original criterion changed.'},indent=2)+'\n',encoding='utf-8')
subprocess.run(['git','-c','core.autocrlf=false','add','--',receipt.relative_to(root).as_posix()],cwd=root,check=True,capture_output=True)
verify([receipt.relative_to(root).as_posix()])
(temp/'metodobase-checkpoint105-raw-whitespace-observations.log').write_bytes(observations)
(temp/'metodobase-checkpoint105-raw-pairs-private.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
subprocess.run(['git','commit','-m','docs: checkpoint105 accepts integrated regression and preserves runtime audits'],cwd=root,check=True,capture_output=True)
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
print(json.dumps({'head':head,'raw_files':len(relative),'docs':len(docs),'raw_index_identical':True,'raw_whitespace_check_exit':check.returncode,'raw_whitespace_lines':len(observations.splitlines())}))
