import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path('F:/MetodoBaseWeb-execution-20261018')
run = root / 'docs/implementation/20261018-evolution'
ev = run / 'evidence'
temp = Path('C:/Users/Consu/AppData/Local/Temp')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
docs = ['CAMBIOS.md', 'CARGA_LOCAL.md', 'ENTREGA.md', 'ESTADO.md', 'RIESGOS.md', 'TRAZABILIDAD.json', 'TRAZABILIDAD.md', 'VALIDACION.md']
# Correct a prose typo without changing any result or criterion.
p = run / 'VALIDACION.md'
p.write_text(p.read_text(encoding='utf-8').replace('sólo paradiseño/autoría29', 'sólo para diseño y autoría29'), encoding='utf-8')
subprocess.run(['git', 'diff', '--check', '--', *(str((run / n).relative_to(root)) for n in docs)], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *(str((run / n).relative_to(root)) for n in docs)], cwd=root, check=True, capture_output=True)
folders = ['qa-integrated28-history-landing-postfix-20261019', 'r12-contract-security-review-20261019', 'r12-root-mechanism-review-20261019', 'linux-recovery28-image-abd559a', 'desktop31215-security-20261019', 'owned-export-fixture-cleanup-20261019']
receipt = ev / 'checkpoint105-raw-preservation.json'
assert not receipt.exists()
shutil.copyfile(temp / 'metodobase-checkpoint105-local-20261019.py', ev / 'checkpoint105-driver.py')
paths = [ev / 'checkpoint105-local-source.json', ev / 'checkpoint105-driver.py']
for name in folders:
    paths.extend(p for p in (ev / name).rglob('*') if p.is_file())
relative = sorted(p.relative_to(root).as_posix() for p in paths)
assert len(set(relative)) == len(relative)
for start in range(0, len(relative), 30):
    subprocess.run(['git', '-c', 'core.autocrlf=false', 'add', '-f', '--', *relative[start:start+30]], cwd=root, check=True, capture_output=True)

def verify_index(names):
    data = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=root, input=''.join(':' + n + '\n' for n in names).encode())
    offset = 0
    hashes = {}
    for name in names:
        end = data.index(b'\n', offset)
        header = data[offset:end].split()
        assert header[1] == b'blob', (name, header)
        size = int(header[2])
        blob = data[end+1:end+1+size]
        offset = end+1+size+1
        raw = (root / name).read_bytes()
        assert blob == raw, name
        hashes[name] = sha(raw)
    assert offset == len(data)
    return hashes

hashes = verify_index(relative)
check = subprocess.run(['git', 'diff', '--cached', '--check', '--', *relative], cwd=root, capture_output=True)
observations = check.stdout + check.stderr
receipt.write_text(json.dumps({'checkpoint':105, 'raw_files':len(relative), 'raw_git_index_byte_identical':True, 'git_add_override':'core.autocrlf=false only for exact new evidence paths', 'all_compared_pairs_sha256':sha(json.dumps(hashes, sort_keys=True, separators=(',', ':')).encode()), 'raw_whitespace_check_exit':check.returncode, 'raw_whitespace_observation_lines':len(observations.splitlines()), 'raw_whitespace_observations_sha256':sha(observations), 'policy':'Evidence bytes are retained including original line endings and whitespace. Source/docs whitespace check passed separately. No historical file, original criterion, runtime or unrelated untracked evidence was changed.'}, indent=2) + '\n', encoding='utf-8')
subprocess.run(['git', '-c', 'core.autocrlf=false', 'add', '--', str(receipt.relative_to(root))], cwd=root, check=True, capture_output=True)
verify_index([receipt.relative_to(root).as_posix()])
(temp / 'metodobase-checkpoint105-raw-whitespace-observations.log').write_bytes(observations)
(temp / 'metodobase-checkpoint105-raw-pairs-private.json').write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8')
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z'], cwd=root).decode().split('\0')[:-1]
allowed = set(relative + [receipt.relative_to(root).as_posix()] + [(run / n).relative_to(root).as_posix() for n in docs])
assert set(staged) == allowed, (set(staged)-allowed, allowed-set(staged))
subprocess.run(['git', 'commit', '-m', 'docs: checkpoint105 accepts integrated regression and preserves runtime audits'], cwd=root, check=True, capture_output=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
print(json.dumps({'head':head,'raw_files':len(relative),'docs':len(docs),'raw_index_identical':True,'raw_whitespace_check_exit':check.returncode,'raw_whitespace_lines':len(observations.splitlines())}))
