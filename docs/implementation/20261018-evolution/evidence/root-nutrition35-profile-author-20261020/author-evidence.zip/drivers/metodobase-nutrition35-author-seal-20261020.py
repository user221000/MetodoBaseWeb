"""Seal private originals and bounded public projections of nutrition35 phases."""
from pathlib import Path, PurePosixPath
import ast
import hashlib
import importlib
import io
import json
import re
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
import zipfile

R=Path('F:/mb-google33-conflict-window-20261019')
MAIN=Path('F:/MetodoBaseWeb-execution-20261018')
T=Path('C:/Users/Consu/AppData/Local/Temp')
P=R/'docs/implementation/20261018-evolution/evidence/root-nutrition35-profile-author-20261020'
C=T/'metodobase-nutrition35-author-seal-20261020'
PRIVATE=T/'metodobase-nutrition35-author-private-20261020'
HEAD='55a3f4f9b1c1d03937bae78a5cee4f1d1b6379af'
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda v:(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def git(*a):return subprocess.run(['git',*a],cwd=R,capture_output=True,check=True)
assert git('rev-parse','HEAD').stdout.decode().strip()==HEAD
assert not git('status','--porcelain','-uno').stdout.strip()
assert not C.exists() and not P.exists() and not PRIVATE.exists();C.mkdir()
phase_names=['metodobase-nutrition35-domain-20261019',
    *['metodobase-nutrition35-boundary-'+n+'-20261020' for n in ['before','after','final','profile-schema','http','personal-framing','integration-final']],
    'metodobase-nutrition35-personal-framing-20261020','metodobase-nutrition35-style-20261020','metodobase-nutrition35-profile-freeze-20261020']
originals={}
for name in phase_names:
    folder=T/name;assert folder.is_dir()
    for path in folder.rglob('*'):
        if path.is_file():originals['phases/'+name+'/'+path.relative_to(folder).as_posix()]=path.read_bytes()
for name in ['metodobase-nutrition35-domain-run-20261019.py','metodobase-nutrition35-boundary-phase-20261020.py',
    'metodobase-nutrition35-boundary-phase-v2-20261020.py','metodobase-nutrition35-phase-tools-20261020.py',
    'metodobase-nutrition35-personal-framing-20261020.py','metodobase-nutrition35-source-scope-erratum-20261020.json',
    'metodobase-nutrition35-style-20261020.py','metodobase-nutrition35-profile-freeze-20261020.py','metodobase-nutrition35-author-seal-20261020.py']:
    originals['drivers/'+name]=(T/name).read_bytes()
freeze=json.loads((T/'metodobase-nutrition35-profile-freeze-20261020/receipt.json').read_bytes())
for name,digest in freeze['source_paths'].items():
    content=git('show',HEAD+':'+name).stdout
    assert sha(content)==digest and (R/name).read_bytes()==content
    originals['product/'+name]=content
for folder,expected in [('before',(10,10)),('final',(79,0)),('profile-schema',(137,0)),('http',(71,1)),('personal-framing',(22,0)),('integration-final',(162,0))]:
    result=json.loads((T/('metodobase-nutrition35-boundary-'+folder+'-20261020')/'result.json').read_bytes())
    assert (result['cases'],result['failures'])==expected
    assert result['errors']==result['skips']==0 and all(result[k] for k in ['source_quiet','packages_quiet','python_quiet'])
acl_path=MAIN/'docs/implementation/20261018-evolution/evidence/root-mfa31-reviewed-serial-20261019/archive-acl.ps1'
acl=acl_path.read_text()
assert acl.count("$names = @('serial-originals.zip')")==1
acl=acl.replace("$names = @('serial-originals.zip')","$names = @('nutrition35-originals.zip')",1)
(C/'archive-acl.ps1').write_bytes(acl.encode())
def protect(mode):
    # Run the exact own ACL script inline; do not change execution policy.
    command='& {\n'+acl+'\n} -Mode '+mode+" -PrivateRoot '"+str(PRIVATE)+"'"
    result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',command],capture_output=True,check=False)
    (C/('acl-'+mode+'.stdout')).write_bytes(result.stdout);(C/('acl-'+mode+'.stderr')).write_bytes(result.stderr)
    assert result.returncode==0
    return json.loads(result.stdout.decode('utf-8-sig'))
protect('create');initial_acl=protect('verify');assert initial_acl['verified_before_payload']
archive=PRIVATE/'nutrition35-originals.zip';assert archive.stat().st_size==0
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in originals.items():z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(originals) and all(z.read(n)==raw for n,raw in originals.items())
final_acl=protect('final')
sys.path.insert(0,str(MAIN))
publisher=importlib.import_module('tests.ci_google33.publish')
definition=next(n for n in ast.parse((T/'metodobase-checkpoint119-prepare.py').read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='scan')
exec(compile(ast.Module(body=[definition],type_ignores=[]),'scanner119','exec'))
public_members={}
withheld=[]
for name,raw in originals.items():
    if name.endswith('.xml'):
        public_members[name+'.STRUCTURAL.xml']=publisher.xml_projection(raw)
    else:
        try:scan(raw,name);publisher.scan(raw)
        except (ValueError,AssertionError,RuntimeError):
            withheld.append({'path':name,'bytes':len(raw),'digest':sha(raw),'reason':'Publication guard refused original; retained only in protected private archive.'})
        else:public_members[name]=raw
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in public_members.items():z.writestr(name,raw)
summary={'product_head':HEAD,'final_SQLite_cases':162,'failures':0,'errors':0,'skips':0,
    'constructor_before_after':[{'cases':10,'failures':10},{'cases':10,'failures':0}],
    'other_phases_overlap_not_added':True,'pure_independent_review':'fad3d024dfcbf362e9bc564730bb387e9287cd5c',
    'pure_review_covers_only_d5_not_profile_integration':True,'gym_factories':['web.main_web','api.app'],
    'personal_factory':'web.main_web','personal_framing_assertions_preserved':True,'source_scope_initial_erratum_retained':True,
    'new_source_Ruff_exit':0,'changed_existing_F821_exit':0,'pip_check_after_exit':0,
    'PG_UI_desktop_integrated_or_clinical_acceptance':False,'MAIN_integrated':False,'public_RAW_withheld_members':len(withheld)}
source={'product_head':HEAD,'products':freeze['source_paths'],'original_members':[{'path':n,'bytes':len(raw),'digest':sha(raw)} for n,raw in originals.items()],
    'public_original_members_exact':True,'XML_publication':'Explicit structural projections; original XML/diagnostics remain private and hash-bound.',
    'withheld':withheld,'private_archive':{'basename':archive.name,'digest':sha(archive.read_bytes()),'members':len(originals)},
    'archive_ACL_before_payload':initial_acl,'archive_ACL_final':final_acl,'original_phase_directory_ACL_at_creation_attested':False,
    'publisher_source':{'MAIN_commit':'e006516fe99ec0da65c4a0f563b8c5736e541b50','path':'tests/ci_google33/publish.py','digest':sha((MAIN/'tests/ci_google33/publish.py').read_bytes())},
    'initial_profile_schema_photo_scope':'Tracked sources only; untracked35 modules were missing. Final162 uses complete cached+untracked source paths.'}
review='''# Declaraciones nutricionales35: candidato local

Fuente55a3f4f9 integra declaración cerrada persistida,DTO compartido,exportación
propia,guardas antes de cuota/worker ycomparación bajo bloqueo antes de publicar.
LegacyNULL sigue desconocido; omisión/null parcial no borra declaración. Una
alergia declarada osolicitud de revisión bloquea automatización sin bypass de
rol oplan. No existe aprobación clínica real ni taxonomía de alérgenos inferida.

162casos finalesSQLite PASS,sin errores/skips. Ambosfactories para gimnasios;
perfil individual sóloSaaS. Diez guardas de constructor fallan antes ypasan
después; otrosreplays se solapan yno se suman. Una prueba personal delautor
asumía incorrectamente paridad conapi.app(404):se conservaRAW yse corrige sólo
el framing aSaaS con inversa exacta yassertsAST idénticos. La primera fase137
no fotografió nuevos archivos sin rastrear; final162 sílos incluye.

DDL35 agregauna columna nullable acotada,verifica targets yrechaza rollback con
declaraciones noNULL. Contratos anteriores inmutables; target34PG copiado exacto
delautor,noejecutado porROOT. Se ensayan drift,interrupción,repetición,bounds y
rollback conservador enSQLite. Cambio durantePDF real deja ceroPlan/READY,
reserva liberada yun objetoPENDING para reconciliación existente:hay eseefecto
durable explícito. Errores no repiten valores; respuestas privadas.

La revisión independiente fad3d sólo cubre dominio/constructoresd5(79+24casos),
noesta integración. PostgreSQL35,UI,desktop ypeerintegrado continúan pendientes.
NoMAIN/despliegue/Chrome/imagen/proveedor/SLO ni validación profesional. RAW
protegido antes delpayload; no se atestan retroactivamente ACL de carpetas de
ejecución. XML público es proyección explícita vinculada aloriginal privado.
'''
public={'.gitattributes':b'* -text\n','author-evidence.zip':buffer.getvalue(),'source.json':enc(source),'summary.json':enc(summary),'review.md':review.encode()}
for name,raw in public.items():scan(raw,name);publisher.scan(raw)
P.mkdir()
for name,raw in public.items():(P/name).write_bytes(raw)
manifest={p.name:{'bytes':p.stat().st_size,'digest':sha(p.read_bytes())} for p in P.iterdir()}
(P/'manifest.json').write_bytes(enc(manifest))
for p in P.iterdir():scan(p.read_bytes(),p.name);publisher.scan(p.read_bytes())
git('-c','core.autocrlf=false','add','-f','--',P.relative_to(R).as_posix());git('diff','--cached','--check')
assert all(git('show',':'+p.relative_to(R).as_posix()).stdout==p.read_bytes() for p in P.iterdir())
git('commit','-m','Seal nutrition35 SQLite profile and publication evidence with explicit limits')
result={'head':git('rev-parse','HEAD').stdout.decode().strip(),'product':HEAD,'source_digest':sha((P/'source.json').read_bytes()),'manifest_digest':sha((P/'manifest.json').read_bytes()),'files':len(manifest)+1,'private_members':len(originals),'public_withheld':len(withheld)}
(C/'result.json').write_bytes(enc(result));print(json.dumps(result))
