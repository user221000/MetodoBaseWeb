from pathlib import Path
import json
import subprocess

R=Path('F:/mb-google33-conflict-window-20261019')
O=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-nutrition35-style-20261020')
assert not O.exists();O.mkdir()
P='C:/Users/Consu/AppData/Local/Temp/metodobase-qa-20261018/Scripts/python.exe'
paths=['web/services/nutrition_profiles.py','web/nutrition_http.py','tests/capture_nutrition35_targets.py','tests/test_nutrition35_profile_contract.py','tests/test_nutrition35_migrations.py','tests/test_nutrition35_http.py','web/database/alembic/versions/20261020_nutrition_profile.py']
for name in paths:
    target=O/'before'/name;target.parent.mkdir(exist_ok=True,parents=True);target.write_bytes((R/name).read_bytes())
for label,options in [('imports',['--select','I','--fix']),('full',['--output-format','json'])]:
    done=subprocess.run([P,'-m','ruff','check',*options,*paths],cwd=R,capture_output=True,check=False)
    (O/(label+'.stdout')).write_bytes(done.stdout);(O/(label+'.stderr')).write_bytes(done.stderr)
    if label=='imports':assert done.returncode==0
    else:
        notes=json.loads(done.stdout)
        print(json.dumps({'exit':done.returncode,'diagnostics':[{'code':n['code'],'message':n['message'],'filename':Path(n['filename']).name} for n in notes]}))
