"""Run one immutable source phase with packages and tool identities checked."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

R=Path('F:/mb-google33-conflict-window-20261019')
O=Path('C:/Users/Consu/AppData/Local/Temp')/('metodobase-nutrition35-boundary-'+sys.argv[1]+'-20261020')
assert not O.exists();O.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=[p for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R).decode().split('\0') if p and not p.startswith('docs/') and Path(p).suffix in {'.py','.html','.js','.css','.txt','.toml','.json','.lock','.yml','.yaml','.ini'}]
paths+=['tests/test_nutrition35_generation_boundary.py']
def photo():
    packages=json.loads(subprocess.check_output([sys.executable,'-m','pip','list','--format=json','--disable-pip-version-check']))
    return {'sources':{p:sha((R/p).read_bytes()) for p in paths if (R/p).is_file()},'packages':packages,'python_sha256':sha(Path(sys.executable).read_bytes()),'python':sys.version}
encode=lambda v:(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
before=photo();(O/'before.json').write_bytes(encode(before))
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8'}
tests=['tests/test_nutrition35_generation_boundary.py',*sys.argv[2:]]
args=[sys.executable,'-B','-X','utf8','tests/run_isolated.py',*tests,'-q','--junitxml='+str(O/'pytest.xml')]
start=time.monotonic()
with (O/'pytest.stdout').open('xb') as out,(O/'pytest.stderr').open('xb') as err:
    done=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=err)
after=photo();(O/'after.json').write_bytes(encode(after))
cases=ET.parse(O/'pytest.xml').findall('.//testcase')
result={'exit':done.returncode,'cases':len(cases),'failures':sum(c.find('failure') is not None for c in cases),'errors':sum(c.find('error') is not None for c in cases),'skips':sum(c.find('skipped') is not None for c in cases),'elapsed_seconds':time.monotonic()-start,'argv':args,'source_quiet':before['sources']==after['sources'],'packages_quiet':before['packages']==after['packages'],'python_quiet':before['python_sha256']==after['python_sha256'],'API_UI_schema35_acceptance':False}
(O/'result.json').write_bytes(encode(result));print(json.dumps(result))
assert all(result[k] for k in ['source_quiet','packages_quiet','python_quiet'])
