"""Freeze the SQLite-reviewed profile candidate without claiming PG/UI/desktop."""
from pathlib import Path
import hashlib
import json
import subprocess

R=Path('F:/mb-google33-conflict-window-20261019')
O=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-nutrition35-profile-freeze-20261020')
assert not O.exists();O.mkdir()
def git(*a):return subprocess.run(['git',*a],cwd=R,capture_output=True,check=True)
assert git('rev-parse','HEAD').stdout.decode().strip()=='d5ef9602687730037b3e448506e14d14a3df5323'
paths=git('diff','--name-only','HEAD').stdout.decode().splitlines()
paths+=git('ls-files','--others','--exclude-standard').stdout.decode().splitlines()
assert len(paths)==len(set(paths))==25
assert not git('diff','--cached','--name-only').stdout.strip()
before={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths}
git('-c','core.autocrlf=false','add','--',*paths)
git('diff','--cached','--check')
assert set(git('diff','--cached','--name-only').stdout.decode().splitlines())==set(paths)
git('commit','-m','Add structured nutrition profiles and fence quota and plan publication')
assert not git('status','--porcelain','-uno').stdout.strip()
assert all(git('show','HEAD:'+p).stdout==(R/p).read_bytes() for p in paths)
receipt={'head':git('rev-parse','HEAD').stdout.decode().strip(),'source_paths':before,'Git_RAW_exact':True,'SQLite_final_cases':162,'failures':0,'errors':0,'skips':0,'PG35_UI_desktop_independent_integrated_acceptance':False,'MAIN_integrated':False,'target34PG_copy_exact':'a33dfac87bf379975bbcbfcbb733bc7bd978b7ce122c596d2a8d8710efd14880','wire_path':'docs/implementation/20261018-evolution/NUTRICION35_WIRE.json','new_files_Ruff':0,'changed_existing_source_F821':0,'pip_check_after':0}
(O/'receipt.json').write_bytes((json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'head':receipt['head'],'files':len(paths),'SQLite_cases':162,'wire_sha256':before[receipt['wire_path']]}))
