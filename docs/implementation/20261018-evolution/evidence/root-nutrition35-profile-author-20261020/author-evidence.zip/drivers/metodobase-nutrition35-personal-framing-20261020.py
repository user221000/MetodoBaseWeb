"""Correct an author's unsupported API-personal assumption, preserving asserts."""
from pathlib import Path
import ast
import hashlib
import json

R=Path('F:/mb-google33-conflict-window-20261019')
O=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-nutrition35-personal-framing-20261020')
assert not O.exists();O.mkdir()
p=R/'tests/test_nutrition35_http.py';before=p.read_bytes()
(O/'test-before.py').write_bytes(before)
old=b'def test_independent_personal_profile_preserves_declaration_without_consuming_quota(followup_http):\n    c = followup_http'
new=b'def test_independent_personal_profile_preserves_declaration_without_consuming_quota(personal35_http):\n    c = personal35_http'
fixture=b'''@pytest.fixture(params=["web.main_web"])
def personal35_http(followup_db, request, monkeypatch):
    # API intentionally exposes only reviewed personal history GET. The SaaS
    # factory owns profile/generation; do not silently widen API's surface.
    yield from followup_http.__wrapped__(followup_db, request, monkeypatch)


'''
assert before.count(old)==1
after=before.replace(old,new).replace(b'def _put(case, **changes):',fixture+b'def _put(case, **changes):',1)
assert after.replace(new,old).replace(fixture,b'')==before
def assertions(raw):
    tree=ast.parse(raw)
    return {node.name:[ast.dump(n,include_attributes=False) for n in ast.walk(node) if isinstance(n,ast.Assert)] for node in tree.body if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')}
assert assertions(before)==assertions(after)
p.write_bytes(after)
receipt={'reason':'api.app explicitly mounts only personal history GET. New author test incorrectly assumed profile/generation parity. Original source factory and the existing personal HTTP regressions establish SaaS-only mutation contract. No product endpoint added or assertion removed.','original_phase':{'cases':71,'passed':70,'failed':1,'errors':0,'skips':0},'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'full_inverse_exact':True,'all_assertions_AST_exact':True,'personal_factory':'web.main_web','gym_factories':['api.app','web.main_web']}
(O/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt))
