"""Preserve original phase and extend subsequent source snapshots explicitly."""
from pathlib import Path
import hashlib
import json

T=Path('C:/Users/Consu/AppData/Local/Temp')
old=T/'metodobase-nutrition35-boundary-phase-20261020.py'
new=T/'metodobase-nutrition35-boundary-phase-v2-20261020.py'
raw=old.read_bytes()
before=b"['git','ls-files','-z']"
after=b"['git','ls-files','--cached','--others','--exclude-standard','-z']"
assert raw.count(before)==1 and not new.exists()
new.write_bytes(raw.replace(before,after))
source=Path('F:/mb-followup34-20261019/web/database/alembic/schema_targets/20261019_followup_tasks_postgresql.json')
target=Path('F:/mb-google33-conflict-window-20261019/web/database/alembic/schema_targets')/source.name
content=source.read_bytes()
assert hashlib.sha256(content).hexdigest()=='a33dfac87bf379975bbcbfcbb733bc7bd978b7ce122c596d2a8d8710efd14880'
assert not target.exists()
target.write_bytes(content)
receipt={'initial_phase':'profile-schema','test_result':{'cases':137,'failures':0,'errors':0,'skips':0},'source_snapshot_caveat':'Original driver covered tracked sources and explicit boundary test, not new untracked35 modules/tests/targets. No complete35-source quiet claim for that phase. New phases enumerate cached and untracked source paths.','predecessor34_PG_target_sha256':hashlib.sha256(content).hexdigest(),'predecessor_source_WT':'F:/mb-followup34-20261019','target_copy_exact':target.read_bytes()==content,'root_PG_executed':False,'original_driver_unchanged':old.read_bytes()==raw}
(T/'metodobase-nutrition35-source-scope-erratum-20261020.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt))
