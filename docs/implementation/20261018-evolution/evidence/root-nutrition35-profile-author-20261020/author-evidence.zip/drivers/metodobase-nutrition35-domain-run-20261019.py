"""Validate the domain precursor; no claim of connected schema35/API/UI."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

R=Path('F:/mb-google33-conflict-window-20261019')
T=Path('C:/Users/Consu/AppData/Local/Temp')
O=T/'metodobase-nutrition35-domain-20261019'
assert not O.exists();O.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=[p for p in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0') if p and not p.startswith('docs/') and Path(p).suffix in {'.py','.html','.js','.css','.txt','.toml','.json','.lock','.yml','.yaml','.ini'}]
paths+=['core/nutrition_restrictions.py','tests/test_nutrition35_restrictions.py']
def photo():
    installed=subprocess.check_output([sys.executable,'-m','pip','list','--format=json','--disable-pip-version-check'])
    return {'sources':{p:sha((R/p).read_bytes()) for p in paths if (R/p).is_file()},'packages':json.loads(installed),'python_sha256':sha(Path(sys.executable).read_bytes()),'python':sys.version}
before=photo();(O/'before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8'}
args=[sys.executable,'-B','-X','utf8','tests/run_isolated.py','tests/test_nutrition35_restrictions.py','tests/test_nutrition_safety.py','-q','--junitxml='+str(O/'domain-and-existing-safety.xml')]
start=time.monotonic()
with (O/'pytest.stdout').open('xb') as out,(O/'pytest.stderr').open('xb') as err:
    done=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=err)
pip=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,cwd=R,env=env)
(O/'pip.stdout').write_bytes(pip.stdout);(O/'pip.stderr').write_bytes(pip.stderr)
after=photo();(O/'after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
result={'exit_code':done.returncode,'pip_check_exit':pip.returncode,'source_files':len(before['sources']),'source_quiet':before['sources']==after['sources'],'packages_quiet':before['packages']==after['packages'],'python_quiet':before['python_sha256']==after['python_sha256'],'elapsed_seconds':time.monotonic()-start,'argv':args,'integrated_API_UI_schema35_acceptance':False}
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
assert done.returncode==pip.returncode==0 and all(result[k] for k in ['source_quiet','packages_quiet','python_quiet'])
