"""Retain pre-edit browser token/PII/raw-fetch inventory and source preimages."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('F:/mb-followup-actions-ui-20261019')
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r31-browser-inventory-20261020');out.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()=='f7c11d103c0a10c9896a1193106e7b889369e91c'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
patterns={'storage':r'mb_token|mb_refresh_token|localStorage|sessionStorage|indexedDB|caches\.', 'transport_boot':r'fetch\(|getToken|saveTokens|clearTokens|Authorization|location\.(href|replace|assign)|api\.js', 'identity_metadata':r'mb_email|mb_nombre|mb_tipo|access_token|refresh_token'}
for name,pattern in patterns.items():
    result=subprocess.run(['rg','-n','--glob','*.js','--glob','*.html',pattern,'web/static','web/templates'],cwd=root,capture_output=True)
    assert result.returncode==0
    (out/(name+'.stdout.raw')).write_bytes(result.stdout);(out/(name+'.stderr.raw')).write_bytes(result.stderr)
sources={p.relative_to(root).as_posix():p.read_bytes() for base in (root/'web/static/js',root/'web/templates') for p in base.rglob('*') if p.is_file() and p.suffix in {'.js','.html'}}
with zipfile.ZipFile(out/'frontend-preimages.raw.zip','w',zipfile.ZIP_DEFLATED) as arc:
    for name,blob in sorted(sources.items()):arc.writestr(name,blob)
receipt={'base':'f7c11d103c0a10c9896a1193106e7b889369e91c','preserved_ui35':'816805915ccebf4208bd8eeaeaf1d397ad967c19','frontend_preimages':{name:hashlib.sha256(blob).hexdigest() for name,blob in sorted(sources.items())},'scope':'Read-only pre-edit inventory; no auth/ORM/DDL/server/desktop mutation. Recovery/invitation one-time proof fragments are distinct from session access/refresh.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps({'preimages':len(sources),'base':receipt['base']}))
