"""Import only ROOT-authorized independent export companion and three wrappers."""
from pathlib import Path
import hashlib,json,subprocess
root=Path('F:/mb-followup-actions-ui-20261019');commit='7011d9f42c14afd104ed3af5302f64ca49998ae0'
names=['browser_export_compat31','current33_export_context','current33_export_controls','current33_member_link_export'];rows=[]
for name in names:
    target=root/('tests/e2e/'+name+'.cjs');assert not target.exists();raw=subprocess.check_output(['git','-c','core.autocrlf=false','show',commit+':tests/e2e/'+name+'.cjs'],cwd=root);target.write_bytes(raw);rows.append({'path':target.relative_to(root).as_posix(),'sha256':hashlib.sha256(raw).hexdigest()})
print(json.dumps({'from':commit,'paths':rows}))
