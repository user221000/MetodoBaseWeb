"""Source-quiet offline VM/DOM and actual inert SSR gates, no cookie backend claim."""
from pathlib import Path
import hashlib,importlib.metadata,json,os,subprocess,sys,time
root=Path('F:/mb-followup-actions-ui-20261019');temp=Path('C:/Users/Consu/AppData/Local/Temp')
out=temp/'metodobase-r31-browser-runtime-web-v1-20261020';out.mkdir(exist_ok=False)
os.chdir(root);sys.path.insert(0,str(root));sys.dont_write_bytecode=True
from tests.isolation import prepare_environment,block_external_sockets
prepare_environment(discard_inherited=True);block_external_sockets()
os.environ['NODE_OPTIONS']='--require='+str(temp/'metodobase-r31-browser-offline-20261020.cjs')
def save(name,value):
    with (out/name).open('x',encoding='utf8') as stream:json.dump(value,stream,indent=2,sort_keys=True)
def snapshot():
    paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')
    source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if p and not p.startswith('docs/') and (root/p).is_file()}
    packages={d.metadata['Name']:{'version':d.version,'metadata_sha256':hashlib.sha256((d.read_text('METADATA')or'').encode()).hexdigest()} for d in importlib.metadata.distributions()}
    binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(sys.executable),Path(sys._base_executable),Path('C:/Program Files/nodejs/node.exe'))}
    wire=root/'docs/implementation/20261018-evolution/SESION_NAVEGADOR_R31_WIRE.json'
    return {'source':source,'packages':packages,'binaries':binaries,'wire_sha256':hashlib.sha256(wire.read_bytes()).hexdigest()}
before=snapshot();save('before.json',before)
p1=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-before.json',{'exit':p1.returncode,'stdout':p1.stdout,'stderr':p1.stderr})
started=time.monotonic();results=[]
files=['browser_session31','session_shell31','daily_plan_controls','daily_plan_data','daily_plan_snapshot','dashboard_followup','dashboard_followup_focus','dashboard_followup34','followup_tasks_state','followup_tasks_dom','google_link_state','google_link_dom','google_link_login_review','nutrition35_state','nutrition35_dom','nutrition35_personal_generation','member_link_consumers31','member_link_controls','member_link_export','member_link_fragment','mfa_state','mfa_prompt','personal_diary_controller','personal_export_controls','personal_operation','personal_operation_ambiguity_review','progreso_controlador','progreso_datos','progreso_operacion','progreso_respuestas','progreso_vista','progreso_wire','progress_export','progress_retirement','progress_retirement_dom']
for stem in files+['auth_refresh_storage','mfa_api']:
    env=os.environ.copy()
    for key in list(env):
        if key.endswith('_OUTPUT'):del env[key]
    result=subprocess.run(['C:/Program Files/nodejs/node.exe','tests/e2e/'+stem+'.cjs'],env=env,capture_output=True,timeout=60)
    (out/(stem+'.stdout.raw')).write_bytes(result.stdout);(out/(stem+'.stderr.raw')).write_bytes(result.stderr)
    try:report=json.loads(result.stdout.decode('utf8'))
    except ValueError:report={'unparsed':True}
    results.append({'file':'tests/e2e/'+stem+'.cjs','exit':result.returncode,'report':report,'category':'current' if stem in files else 'legacy_storage_fixture_diagnostic_not_acceptance'})
save('node-results.json',results)
syntax=[]
for path in sorted((root/'web/static/js').glob('*.js')):
    result=subprocess.run(['C:/Program Files/nodejs/node.exe','--check',str(path)],capture_output=True,timeout=30)
    syntax.append({'path':path.relative_to(root).as_posix(),'exit':result.returncode})
    if result.returncode:(out/(path.name+'.parse.stderr.raw')).write_bytes(result.stderr)
save('syntax.json',syntax)
ruff=subprocess.run(['C:/Users/Consu/AppData/Local/Temp/metodobase-qa-20261018/Scripts/python.exe','-m','ruff','check','tests/test_browser_session31_ui.py'],capture_output=True,text=True);save('ruff.json',{'exit':ruff.returncode,'stdout':ruff.stdout,'stderr':ruff.stderr})
import pytest
code=pytest.main(['tests/test_browser_session31_ui.py','-q','--tb=short','--junitxml='+str(out/'ssr.xml'),'-o','cache_dir='+str(out/'cache')])
after=snapshot();save('after.json',after)
p2=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-after.json',{'exit':p2.returncode,'stdout':p2.stdout,'stderr':p2.stderr})
current_failures=[entry['file'] for entry in results if entry['category']=='current' and entry['exit']!=0]
save('receipt.json',{'pytest_exit':code,'current_node_commands':len(files),'current_node_failures':current_failures,'legacy_fixture_diagnostics':2,'quiet':before==after,'source_count':len(before['source']),'packages':len(before['packages']),'pip_before':p1.returncode,'pip_after':p2.returncode,'ruff_exit':ruff.returncode,'syntax_files':len(syntax),'syntax_failures':[row for row in syntax if row['exit']],'duration_seconds':time.monotonic()-started,'scope':'Author webR31 offline VM/minimalDOM and actual inert SSR; no backend cookie HTTP, native browser/layout/axe, PG or deployment claim. Legacy Storage fixture diagnostics do not establish current acceptance.'})
raise SystemExit(code or ruff.returncode or bool(current_failures) or any(row['exit'] for row in syntax) or int(before!=after) or p1.returncode or p2.returncode)
