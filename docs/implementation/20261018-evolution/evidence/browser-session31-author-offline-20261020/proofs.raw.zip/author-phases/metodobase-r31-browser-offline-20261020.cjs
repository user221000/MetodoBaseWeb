'use strict';
// Offline author gate. VM fixtures provide their own transports; no real socket,
// browser, child worker, provider or server process may be started by this batch.
const denied=()=>{throw Error('Offline author gate: external I/O disabled');};
require('node:net').Socket.prototype.connect=denied;
require('node:net').Server.prototype.listen=denied;
require('node:tls').connect=denied;
for(const name of ['request','get']){require('node:http')[name]=denied;require('node:https')[name]=denied;}
for(const name of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork'])require('node:child_process')[name]=denied;
globalThis.fetch=async()=>{throw Error('Offline author gate: host fetch disabled');};
const Module=require('node:module'),load=Module._load;
Module._load=function(name,...args){if(/playwright|puppeteer/.test(name))denied();return load.call(this,name,...args);};
