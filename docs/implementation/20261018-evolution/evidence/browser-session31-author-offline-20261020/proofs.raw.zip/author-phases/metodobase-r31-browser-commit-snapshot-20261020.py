"""Freeze only owned frontend sources/current tests and explicit review scope."""
from pathlib import Path
import hashlib,json,os,subprocess
root=Path('F:/mb-followup-actions-ui-20261019');temp=Path(os.environ['TEMP']);os.chdir(root)
git=lambda *args:subprocess.check_output(['git','-c','core.autocrlf=false',*args])
base='f7c11d103c0a10c9896a1193106e7b889369e91c';assert git('rev-parse','HEAD').decode().strip()==base
names=sorted(set(git('diff','--name-only',base).decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines()))
assert all(name.startswith(('web/static/','web/templates/','tests/')) or name=='docs/implementation/20261018-evolution/SESION_NAVEGADOR_R31_WIRE.json' for name in names)
receipt=json.loads((temp/'metodobase-r31-browser-snapshot-gate-20261020/receipt.json').read_text());latest=json.loads((temp/'metodobase-r31-browser-snapshot-gate-20261020/after.json').read_text());assert receipt['quiet']
sha=lambda value:hashlib.sha256(value).hexdigest();raw={name:(root/name).read_bytes() for name in names}
assert all(name not in latest or latest[name]==sha(blob) for name,blob in raw.items())
doc='docs/implementation/20261018-evolution/SESION_NAVEGADOR_R31_SNAPSHOT.json'
data={'base':base,'preserved_ui35':'816805915ccebf4208bd8eeaeaf1d397ad967c19','wire_sha256':sha(raw['docs/implementation/20261018-evolution/SESION_NAVEGADOR_R31_WIRE.json']),'sources':{name:sha(blob) for name,blob in raw.items()},'current_author_gate':receipt,'scope':'Early frontend-only review snapshot. CI composition, general per-case supersession map and final preservation/public proof seal remain pending. No backend HTTP/native browser/layout/PG/provider/global acceptance. Historical suites are retained byte-exact; current companions do not retroactively mark them PASS.'}
(root/doc).write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8');raw[doc]=(root/doc).read_bytes();names.append(doc)
git('diff','--check');git('add','--',*names)
assert set(git('diff','--cached','--name-only').decode().splitlines())==set(names)
for name,blob in raw.items():assert git('show',':'+name)==blob,name
git('commit','-m','feat(web): freeze R31 browser session frontend for review')
head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain').strip()
for name,blob in raw.items():assert git('show',head+':'+name)==blob,name
result={'commit':head,'paths':len(names),'sourcequiet':True,'tests':receipt,'exact_worktree_index_commit':True,'scope':data['scope']};(temp/'metodobase-r31-browser-snapshot-commit-20261020.json').write_text(json.dumps(result,indent=2,sort_keys=True),encoding='utf8');print(json.dumps({'commit':head,'paths':len(names),'commands':len(receipt['commands']),'cases':sum(row['total'] for row in receipt['commands'])}))
