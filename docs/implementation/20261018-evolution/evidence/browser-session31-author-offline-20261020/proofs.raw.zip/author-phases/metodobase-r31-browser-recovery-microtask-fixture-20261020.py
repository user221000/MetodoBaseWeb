from pathlib import Path
import json
p=Path('F:/mb-followup-actions-ui-20261019/tests/e2e/browser_session31.cjs');s=p.read_text(encoding='utf8')
old='const sandbox={TextEncoder,URL,URLSearchParams,AbortController,Promise,';new='const sandbox={TextEncoder,URL,URLSearchParams,AbortController,queueMicrotask,Promise,'
assert s.count(old)==1
p.write_text(s.replace(old,new),encoding='utf8',newline='')
Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r31-browser-recovery-microtask-fixture-20261020.json').write_text(json.dumps({'fixture_only':True,'business_assertions_changed':False,'missing_platform_global':'queueMicrotask','effect':'Separate API realm could not schedule shell DOM cleanup; event dispatch captured ReferenceError. Public recovery already cleared RAM. Browser/minimal-shell fixture already supplies this standard global.','product_changed':False},indent=2),encoding='utf8')
