"""Source/package-quiet current mapped VM/DOM and inert SSR gates."""
from pathlib import Path
import hashlib,importlib.metadata,json,os,subprocess,sys,time
root=Path('F:/mb-followup-actions-ui-20261019');temp=Path(os.environ['TEMP']);out=temp/'metodobase-r31-browser-offline-final-gate-20261020';out.mkdir(exist_ok=False);os.chdir(root);sys.path.insert(0,str(root));sys.dont_write_bytecode=True
from tests.isolation import prepare_environment,block_external_sockets
prepare_environment(discard_inherited=True);block_external_sockets()
os.environ['NODE_OPTIONS']='--require='+str(root/'tests/e2e/browser_offline31.cjs').replace('\\','/')
def save(name,value):(out/name).write_text(json.dumps(value,indent=2,sort_keys=True),encoding='utf8')
def snapshot():
    paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0');source={p:hashlib.sha256((root/p).read_bytes()).hexdigest()for p in sorted(set(paths))if p and not p.startswith('docs/')and(root/p).is_file()}
    packages={d.metadata['Name']:{'version':d.version,'metadata_sha256':hashlib.sha256((d.read_text('METADATA')or'').encode()).hexdigest()}for d in importlib.metadata.distributions()}
    binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in(Path(sys.executable),Path(sys._base_executable),Path('C:/Program Files/nodejs/node.exe'))}
    docs={p:hashlib.sha256((root/'docs/implementation/20261018-evolution'/p).read_bytes()).hexdigest()for p in['SESION_NAVEGADOR_R31_WIRE.json','SESION_NAVEGADOR_R31_CI_MAP.json']}
    return{'source':source,'packages':packages,'binaries':binaries,'documents':docs}
before=snapshot();save('before.json',before);started=time.monotonic()
pip1=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True);(out/'pip-before.stdout.raw').write_bytes(pip1.stdout);(out/'pip-before.stderr.raw').write_bytes(pip1.stderr)
node=subprocess.run([sys.executable,'-B','tests/e2e/run_browser31_ci.py','--output',str(out/'mapped'),'--node','C:/Program Files/nodejs/node.exe'],capture_output=True,timeout=120);(out/'node.stdout.raw').write_bytes(node.stdout);(out/'node.stderr.raw').write_bytes(node.stderr)
syntax=[]
for p in sorted((root/'web/static/js').glob('*.js')):
    result=subprocess.run(['C:/Program Files/nodejs/node.exe','--check',str(p)],capture_output=True,timeout=30);syntax.append({'path':p.relative_to(root).as_posix(),'exit':result.returncode});(out/(p.name+'.parse.stderr.raw')).write_bytes(result.stderr)
ruff=subprocess.run(['C:/Users/Consu/AppData/Local/Temp/metodobase-qa-20261018/Scripts/python.exe','-m','ruff','check','tests/test_browser_session31_ui.py','tests/e2e/run_browser31_ci.py'],capture_output=True);(out/'ruff.stdout.raw').write_bytes(ruff.stdout);(out/'ruff.stderr.raw').write_bytes(ruff.stderr)
import pytest
code=pytest.main(['tests/test_browser_session31_ui.py','-q','--tb=short','--junitxml='+str(out/'ssr.xml'),'-o','cache_dir='+str(out/'cache')])
after=snapshot();save('after.json',after)
pip2=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True);(out/'pip-after.stdout.raw').write_bytes(pip2.stdout);(out/'pip-after.stderr.raw').write_bytes(pip2.stderr)
report=json.loads((out/'mapped/current-browser31.json').read_text());save('syntax.json',syntax)
receipt={'quiet':before==after,'source_count':len(before['source']),'packages':len(before['packages']),'pip_before':pip1.returncode,'pip_after':pip2.returncode,'node_exit':node.returncode,'node_commands':len(report['commands']),'node_passed':report['passed'],'node_total':report['total'],'map_obligations':report['case_obligations_verified'],'pytest_exit':code,'ruff_exit':ruff.returncode,'syntax_files':len(syntax),'syntax_failures':[row for row in syntax if row['exit']],'duration_seconds':time.monotonic()-started,'scope':'Current owned offline VM/minimalDOM + actual inert SSR; ROOT export companion composed locally. No actual backend cookie HTTP, native Chrome/layout/axe, PG, provider, deployment or global CI acceptance.'};save('receipt.json',receipt);print(json.dumps(receipt));raise SystemExit(node.returncode or code or ruff.returncode or pip1.returncode or pip2.returncode or any(row['exit']for row in syntax) or int(before!=after))
