from pathlib import Path
import json
root=Path('F:/mb-followup-actions-ui-20261019');p=root/'tests/e2e/browser_session31.cjs'
text=p.read_text(encoding='utf8');old='const logout=b.api.auth.logout();';new='const logout=a.api.auth.logout();'
assert text.count(old)==1
p.write_text(text.replace(old,new),encoding='utf8',newline='')
Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r31-browser-logout-framing-20261020.json').write_text(json.dumps({'product_changed':False,'changed':'Late-cookie/logout scenario uses the currently valid tab A, not invalidated tab B','preserved_red':'metodobase-r31-browser-core-after-retain-20261020.stdout','decision':'ROOT explicitly confirmed that invalidated B cannot revoke the newer account. Separate canary will assert no I/O and session_changed/server_confirmed:false for B.'},indent=2),encoding='utf8')
