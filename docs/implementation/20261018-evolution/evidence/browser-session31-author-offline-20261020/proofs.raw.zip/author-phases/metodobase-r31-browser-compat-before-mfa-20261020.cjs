/* Companion execution: unchanged legacy files, explicit browser harness/wire framing. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const allowed=new Set(['followup_tasks_api','nutrition35_api','google_link_api']);
const name=process.argv[2];assert.ok(allowed.has(name),'Choose an inventoried compatibility companion');
const file=path.join(__dirname,name+'.cjs'),before=fs.readFileSync(file,'utf8');let text=before;
const changes=[];
function skipString(s,i){const quote=s[i++];while(i<s.length){if(s[i]==='\\'){i+=2;continue;}if(s[i++]===quote)return i;}throw Error('Unterminated fixed fixture string');}
function balanced(s,start){const pairs={'(':')','{':'}','[':']'},stack=[pairs[s[start]]];assert.ok(stack[0]);let i=start+1;
  while(i<s.length){const c=s[i];if(c==='"'||c==="'"||c==='`'){i=skipString(s,i);continue;}if(c==='/'&&s[i+1]==='/'){i=s.indexOf('\n',i);if(i<0)throw Error('Unclosed fixture comment');continue;}if(c==='/'&&s[i+1]==='*'){i=s.indexOf('*/',i+2)+2;assert.ok(i>1);continue;}
    if(c==='/'&&/[=(:,![{;?]/.test(s.slice(0,i).trimEnd().at(-1)||'=')){i++;let cls=false;while(i<s.length){if(s[i]==='\\'){i+=2;continue;}if(s[i]==='[')cls=true;if(s[i]===']')cls=false;if(s[i++]==='/'&&!cls)break;}while(/[a-z]/i.test(s[i]||'')&&i<s.length)i++;continue;}
    if(pairs[c])stack.push(pairs[c]);else if(c===stack.at(-1)){stack.pop();if(!stack.length)return i+1;}i++;
  }throw Error('Unbalanced fixed fixture');
}
const start=text.indexOf('function fixture(');assert.ok(start>=0);const parameters=text.indexOf('(',start),paramsEnd=balanced(text,parameters),bodyStart=text.indexOf('{',paramsEnd),end=balanced(text,bodyStart);
const access=name==='google_link_api'?'old.token':"'synthetic-access'";
text=text.slice(0,start)+"async function fixture(transport){return require('./browser_harness31.cjs').closed(transport,"+access+");}"+text.slice(end);
changes.push({kind:'fixture',effect:'Await current cookie bootstrap; exclude bootstrap from business call log; expose RAM observer under legacy values getter; no credential Storage writes.'});
// Only test callbacks are made async. Synchronous assertion callbacks stay intact.
const insertions=[];
for(const match of text.matchAll(/\btest\(/g)){
  let i=match.index+5,depth=0;
  for(;i<text.length;i++){const c=text[i];if(c==='"'||c==="'"||c==='`'){i=skipString(text,i)-1;continue;}if('([{'.includes(c))depth++;if(')]}'.includes(c)){if(!depth)break;depth--;}if(c===','&&!depth){const rest=text.slice(i+1),m=/^\s*\(\)\s*=>/.exec(rest);if(m)insertions.push(i+1+rest.indexOf('('));break;}}
}
for(const position of insertions.reverse())text=text.slice(0,position)+'async '+text.slice(position);
const calls=[];
for(const match of text.matchAll(/\bfixture\(/g)){if(text.slice(Math.max(0,match.index-9),match.index)==='function ')continue;const end=balanced(text,text.indexOf('(',match.index));calls.push([match.index,end]);}
for(const [a,b]of calls.reverse())text=text.slice(0,a)+'(await '+text.slice(a,b)+')'+text.slice(b);
changes.push({kind:'async_framing',fixture_calls:calls.length,test_callbacks:insertions.length,effect:'Business assertions unchanged; handles are captured only after the mandatory async bootstrap.'});
// Re-express the old synchronous credential injection as an external completed
// browser boundary. A receiving tab must clear RAM and never adopt the new actor.
text=text.replace(/f\.api\.saveTokens\([^;]+\);/g,(matched,offset)=>{const since=text.slice(text.lastIndexOf("test(",offset),offset);const wait=/\bpending\s*=/.test(since)?'await f.dispatched();':'';changes.push({kind:'external_boundary',legacy_call:matched,wait_for_observed_request:!!wait});return wait+'f.invalidate();';});
text=text.replace(/assert\.equal\(f\.values\.get\('mb_token'\),other\.token\)/g,matched=>{changes.push({kind:'superseded_transport_assertion',before:matched,after:"assert.equal(f.api.getToken(),'')",reason:'Another tab invalidates this tab; it never adopts another account token.'});return "assert.equal(f.api.getToken(),'')";});
function assertions(source){return [...source.matchAll(/\bassert\.[A-Za-z]+\(/g)].map(match=>source.slice(match.index,balanced(source,source.indexOf('(',match.index))));}
const oldAssertions=assertions(before),newAssertions=assertions(text);
assert.equal(oldAssertions.length,newAssertions.length,'No business assertion may be deleted');
const differences=oldAssertions.flatMap((old,i)=>old===newAssertions[i]?[]:[{before:old,after:newAssertions[i]}]);
assert.equal(differences.length,changes.filter(row=>row.kind==='superseded_transport_assertion').length,'Only the inventoried transport expectation may change');
const digest=value=>crypto.createHash('sha256').update(value).digest('hex');
const metadata={companion:'browser_compat31',legacy_source:name+'.cjs',legacy_source_sha256:digest(before),compiled_browser_sha256:digest(text),assertion_calls_preserved:oldAssertions.length,changed_transport_assertions:differences,changes,scope:'Actual current api.js with WebLock/cookie/Storage doubles and legacy business assertions. RAM observer is not persisted Storage. No HTTP/native-browser acceptance.'};
const originalLog=console.log;
console.log=(...args)=>{if(args.length===1){let value=args[0];if(typeof value==='string')try{value=JSON.parse(value);}catch{}if(value&&typeof value==='object'&&Number.isInteger(value.total)){process.stdout.write(JSON.stringify({...value,browser_compatibility:metadata},null,2)+'\n');return;}}originalLog(...args);};
const candidate=new Module(file,module);candidate.filename=file;candidate.paths=module.paths;candidate._compile(text,file);
