"""Capability absence and same-DOM causal probe on immutable baseline sources."""
from pathlib import Path
import hashlib,json,os,subprocess,zipfile
root=Path('F:/mb-followup-actions-ui-20261019');temp=Path('C:/Users/Consu/AppData/Local/Temp')
out=temp/'metodobase-r31-browser-baselines-20261020';out.mkdir(exist_ok=False)
with zipfile.ZipFile(temp/'metodobase-r31-browser-inventory-20261020/frontend-preimages.raw.zip') as arc:old=arc.read('web/static/js/api.js')
assert subprocess.run(['git','cat-file','-e','f7c11d103c0a10c9896a1193106e7b889369e91c:web/static/js/session-shell.js'],cwd=root,capture_output=True).returncode!=0
(out/'api-before.raw.js').write_bytes(old);(out/'shell-before-absent.js').write_bytes(b'')
sha=lambda blob:hashlib.sha256(blob).hexdigest()
receipts=[]
for stem,variable,path in [('browser_session31','BROWSER31_SOURCE',out/'api-before.raw.js'),('session_shell31','SHELL31_SOURCE',out/'shell-before-absent.js')]:
    test=root/('tests/e2e/'+stem+'.cjs');before={str(p):sha(p.read_bytes()) for p in (test,path,Path('C:/Program Files/nodejs/node.exe'))}
    env=os.environ.copy();env[variable]=str(path)
    result=subprocess.run(['C:/Program Files/nodejs/node.exe',str(test)],cwd=root,env=env,capture_output=True,timeout=30)
    (out/(stem+'.stdout.raw')).write_bytes(result.stdout);(out/(stem+'.stderr.raw')).write_bytes(result.stderr);(out/(stem+'.test.raw.cjs')).write_bytes(test.read_bytes())
    after={str(p):sha(p.read_bytes()) for p in (test,path,Path('C:/Program Files/nodejs/node.exe'))}
    receipts.append({'test':stem,'exit':result.returncode,'quiet':before==after,'before':before,'after':after})
assert all(row['quiet'] and row['exit']==1 for row in receipts)
(out/'receipt.json').write_text(json.dumps({'base':'f7c11d103c0a10c9896a1193106e7b889369e91c','phases':receipts,'scope':'API capability absence and same synthetic DOM baseline with absent shell; not full old browser execution. Original earlier stopped/unhandled baseline is retained independently.'},indent=2),encoding='utf8')
print(json.dumps({'phases':len(receipts),'expected_red':True,'quiet':True}))
