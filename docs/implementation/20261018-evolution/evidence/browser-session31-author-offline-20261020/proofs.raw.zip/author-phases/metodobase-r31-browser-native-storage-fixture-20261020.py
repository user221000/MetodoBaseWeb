from pathlib import Path
import json
root=Path('F:/mb-followup-actions-ui-20261019');path=root/'tests/e2e/browser_session31.cjs';text=path.read_text(encoding='utf8')
old="if(denied||denyWrite)throw Object.assign(Error('denied'),{name:denied?'SecurityError':'QuotaExceededError'});"
new="if(denied)throw Object.assign(Error('denied'),{name:'SecurityError'});if(denyWrite)throw new DOMException('denied','QuotaExceededError');"
assert text.count(old)==1
path.write_text(text.replace(old,new),encoding='utf8',newline='')
Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r31-browser-native-storage-fixture-20261020.json').write_text(json.dumps({'fixture_only':True,'business_assertions_changed':False,'change':'Use native DOMException with its numeric legacy code for write denial, rather than an Error renamed QuotaExceededError','preimage':'metodobase-r31-browser-test-before-native-storage-error-20261020.cjs'},indent=2),encoding='utf8')
