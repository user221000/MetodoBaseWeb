"""Early immutable review snapshot gates; no backend/native-browser acceptance."""
from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('F:/mb-followup-actions-ui-20261019');temp=Path(os.environ['TEMP']);out=temp/'metodobase-r31-browser-snapshot-gate-20261020';out.mkdir(exist_ok=False);os.chdir(root)
os.environ['NODE_OPTIONS']='--require='+str(temp/'metodobase-r31-browser-offline-20261020.cjs')
def save(name,value):(out/name).write_text(json.dumps(value,indent=2,sort_keys=True),encoding='utf8')
def snapshot():
    names=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')
    return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sorted(set(names)) if name and (root/name).is_file() and not name.startswith('docs/')}
before=snapshot();save('before.json',before);results=[]
commands=[['tests/e2e/'+name+'.cjs'] for name in ['browser_session31','session_shell31','recovery_epoch31','browser_transport_regressions31']]
commands += [['tests/e2e/browser_compat31.cjs',name] for name in ['followup_tasks_api','nutrition35_api','google_link_api','mfa_api','mfa_state','mfa_consumers','mfa_prompt','personal_diary_api','personal_history','dashboard_followup','member_link_api','member_link_context','personal_logout_ack']]
for index,args in enumerate(commands):
    result=subprocess.run(['C:/Program Files/nodejs/node.exe',*args],capture_output=True,timeout=30)
    stem=f'{index:02d}-'+Path(args[0]).stem+('-'+args[1] if len(args)>1 else '')
    (out/(stem+'.stdout.raw')).write_bytes(result.stdout);(out/(stem+'.stderr.raw')).write_bytes(result.stderr)
    report=json.loads(result.stdout);assert report['passed']==report['total'] and result.returncode==0,(args,report.get('passed'),report.get('total'))
    results.append({'args':args,'exit':result.returncode,'passed':report['passed'],'total':report['total']})
after=snapshot();save('after.json',after);assert before==after;save('receipt.json',{'quiet':True,'source_count':len(before),'commands':results,'scope':'Early author review snapshot only. Current actual frontend VM/minimalDOM; simulated WebLocks/cookie/Storage; no actual backend cookie HTTP, native browser, layout, PG, deployment or global acceptance.'});print(json.dumps({'quiet':True,'commands':len(results),'cases':sum(row['total'] for row in results)}))
