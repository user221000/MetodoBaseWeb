"""Replace inventoried raw storage/token call sites and preserve exact edits."""
from pathlib import Path
import json,re,hashlib
root=Path('F:/mb-followup-actions-ui-20261019')
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r31-browser-consumers-20261020');out.mkdir(exist_ok=False)
changes=[]
def edit(name,fn):
    path=root/name;before=path.read_bytes();old=before.decode('utf8');new=fn(old)
    if new!=old:
        target=out/'preimages'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(before)
        path.write_text(new,encoding='utf8',newline='');changes.append({'path':name,'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(path.read_bytes()).hexdigest()})
def replace(text,old,new,count=1):
    assert text.count(old)==count,(old[:90],text.count(old),count)
    return text.replace(old,new)
for name,indent in [('web/templates/clientes.html','    '),('web/templates/dashboard.html','      ')]:
    def catalog(text,indent=indent):
        old=indent+"const res = await fetch('/api/alimentos/catalogo', {\n"+indent+"  headers: {'Authorization': 'Bearer ' + (localStorage.getItem('mb_token') || '')}\n"+indent+"});\n"+indent+"if (res.ok) {\n"+indent+"  const data = await res.json();\n"+indent+"  _catalogoAlimentos = data.categorias || {};\n"+indent+"}"
        new=indent+"await Api.session.ready;const context=Api.session.capture();\n"+indent+"const data=await Api.clientes.catalogo();Api.session.check(context);\n"+indent+"_catalogoAlimentos=data.categorias||{};"
        return replace(text,old,new)
    edit(name,catalog)
edit('web/templates/generar-plan.html',lambda text:replace(replace(text,"const gymName = localStorage.getItem('mb_nombre') || 'Tu Nutriólogo';","const gymName = Api.session.identity()?.nombre || 'Tu Nutriólogo';"),"""    const res = await fetch('/api/alimentos/catalogo', {
      headers: {'Authorization': 'Bearer ' + (localStorage.getItem('mb_token') || '')}
    });
    if (res.ok) {
      const data = await res.json();
      await verifyGenerationAccount(epoch);
      _s2CatalogoAlimentos = data.categorias || {};
    }""","""    const data=await Api.clientes.catalogo();
    await verifyGenerationAccount(epoch);
    _s2CatalogoAlimentos=data.categorias||{};"""))
def base(text):
    text=replace(text,"<script nonce=\"{{ request.state.csp_nonce }}\" src=\"/static/js/api.js?v={{ static_version }}\"></script>","<script nonce=\"{{ request.state.csp_nonce }}\" src=\"/static/js/api.js?v={{ static_version }}\"></script>\n<script nonce=\"{{ request.state.csp_nonce }}\" src=\"/static/js/session-shell.js?v={{ static_version }}\"></script>")
    start=text.index("    const nombre = localStorage.getItem('mb_nombre')")
    end=text.index('    // Avatar is now an icon, no initials needed',start)
    text=text[:start]+"""    function renderIdentity(me){
      const name=document.getElementById('sb-nombre'),role=document.getElementById('sb-tipo');
      if(name)name.textContent=me?.nombre||'Mi cuenta';
      if(role)role.textContent=me?(me.team_gym_id?'Equipo · Acceso profesional':me.tipo==='gym'?'Gimnasio':'Usuario'):'';
    }
    SessionIdentity.ready.then(()=>renderIdentity(Api.session.identity()));
    window.addEventListener('metodobase-session-changed',()=>renderIdentity(null));
"""+text[end:]
    start=text.index('  // Sidebar client count');end=text.index('\n</script>',start)
    text=text[:start]+"""  // Read-only count after the authoritative cookie/identity bootstrap.
  (async function(){
    const badge=document.getElementById('sb-total-clientes');if(!badge)return;
    window.addEventListener('metodobase-session-changed',()=>{badge.textContent='';});
    try{await SessionIdentity.ready;if(!Api.getToken())return;const context=Api.session.capture();const data=await Api.session.clientCount();Api.session.check(context);if(data&&data.total!=null)badge.textContent=data.total;}catch{/* Unavailable is not a zero. */}
  })();
"""+text[end:]
    return text
edit('web/templates/base.html',base)
def personal(text):
    text=replace(text,"<script nonce=\"{{ request.state.csp_nonce }}\" src=\"/static/js/api.js?v={{ static_version }}\"></script>","<script nonce=\"{{ request.state.csp_nonce }}\" src=\"/static/js/api.js?v={{ static_version }}\"></script>\n<script nonce=\"{{ request.state.csp_nonce }}\" src=\"/static/js/session-shell.js?v={{ static_version }}\"></script>")
    start=text.index('  // Populate user name');end=text.index('  // Active sidebar link',start)
    text=text[:start]+"""  function renderIdentity(me){
    var name=document.getElementById('sb-nombre'),avatar=document.getElementById('sb-avatar');
    if(name)name.textContent=me?.nombre||'Mi cuenta';
    if(avatar)avatar.textContent=me?.nombre?me.nombre.trim().split(' ').map(part=>part[0]).join('').substring(0,2).toUpperCase():'';
  }
  SessionIdentity.ready.then(()=>renderIdentity(Api.session.identity()));
  window.addEventListener('metodobase-session-changed',()=>renderIdentity(null));

"""+text[end:]
    text=replace(text,'      Api.usuario.validarContexto(result.context);','      if(result.context)Api.session.check(result.context);',2)
    return text
edit('web/templates/base_usuario.html',personal)
edit('web/templates/dashboard.html',lambda text:replace(text,"    const nombre = localStorage.getItem('mb_nombre') || '';\n    if (saludoEl) saludoEl.textContent = nombre ? `${saludo}, ${nombre}` : saludo;","    SessionIdentity.ready.then(()=>{const nombre=Api.session.identity()?.nombre||'';if(saludoEl&&saludoEl.isConnected)saludoEl.textContent=nombre?`${saludo}, ${nombre}`:saludo;});"))
for path in sorted([*(root/'web/static/js').glob('*.js'),*(root/'web/templates').glob('*.html')]):
    def epoch_and_version(text):
        text=re.sub(r"\['mb_token',\s*'mb_refresh_token'\]", "['mb_token','mb_refresh_token','mb_session_epoch']",text)
        text=text.replace("event.key==='mb_token' || event.key==='mb_refresh_token' || event.key===null","event.key==='mb_token' || event.key==='mb_refresh_token' || event.key==='mb_session_epoch' || event.key===null")
        text=text.replace('src="/static/js/api.js"','src="/static/js/api.js?v={{ static_version }}"')
        text=text.replace('src="/static/js/api.js?v={{ static_version }}"','src="/static/js/api.js?v={{ static_version }}-r31browser1"')
        return text
    edit(path.relative_to(root).as_posix(),epoch_and_version)
(out/'receipt.json').write_text(json.dumps({'edits':changes,'business_tests_modified':False,'scope':'Only frontend consumers/asset references; no backend/desktop/DDL'},indent=2),encoding='utf8')
print(json.dumps({'edits':len(changes),'unique_paths':len({row['path'] for row in changes})}))
