from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

root = Path(r'F:\mb-progress-retirement-ui-20261019')
tmp = Path(r'C:\Users\Consu\AppData\Local\Temp')
previous = tmp / 'metodobase-gitleaks-historical-fingerprint-triage-20261019'
out = tmp / 'metodobase-gitleaks-public-artifact-triage-20261019'
report_path = tmp / 'metodobase-retirement-ui-scan-7c_07ul3/secret-scan-full.json'
sha = lambda blob: hashlib.sha256(blob).hexdigest()
git = lambda *args: subprocess.check_output(['git', '--no-replace-objects', *args], cwd=root)
assert not out.exists()
report_blob = report_path.read_bytes()
assert sha(report_blob) == '0e5d0cfc77c1626912beca8c9b39e91fe56464e9e9cc71502947e44288b09352'
report = json.loads(report_blob)
rows = json.loads((previous / 'unclassified-locations.json').read_bytes())
assert len(rows) == 10850
tracked = set(git('ls-tree', '-r', '--name-only', '-z', 'de216543a2eec05584168cdb888f627901b0e0b1').decode().split('\0')[:-1])
pattern = re.compile(r'\s*"(?P<path>[^"\\]+)"\s*:\s*"(?P<digest>[0-9a-f]{64})"\s*,?\s*')
cache = {}
eligible = []
unclassified = []
for row in rows:
    name = row['file']
    if name not in cache:
        blob = (root / name).read_bytes()
        assert sha(blob) == row['file_sha256'] == report['files'][name]
        transform = report['encoding_transforms'].get(name)
        cache[name] = blob.decode(transform['source_encoding'] if transform else 'utf-8', errors='strict').split('\n')
    lines = cache[name]
    match = pattern.fullmatch(lines[row['line'] - 1]) if 0 < row['line'] <= len(lines) else None
    if match and name.startswith('docs/implementation/20261018-evolution/evidence/') and ('/' in match['path'] or '.' in match['path']):
        eligible.append((row, match['path'], match['digest']))
    else:
        unclassified.append(row)
wanted = {digest for _, _, digest in eligible}
proofs = {}
for name, digest in report['files'].items():
    if digest in wanted and name in tracked:
        blob = (root / name).read_bytes()
        assert sha(blob) == digest
        proofs[digest] = {'public_artifact': name, 'artifact_sha256': digest, 'kind': 'Exact_scanned_frozen_public_artifact_bytes'}
archives = sorted(name for name in tracked if name.endswith('.zip'))
archive_controls = []
for name in archives:
    blob = git('show', 'de216543a2eec05584168cdb888f627901b0e0b1:' + name)
    path = root / name
    assert path.read_bytes() == blob, name
    total = 0
    skipped = []
    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()
        assert len(members) <= 20000
        for member in members:
            if member.is_dir():
                continue
            if member.file_size > 32 * 1024 * 1024 or total + member.file_size > 128 * 1024 * 1024:
                skipped.append(member.filename)
                continue
            payload = archive.read(member)
            total += len(payload)
            digest = sha(payload)
            if digest in wanted:
                proofs[digest] = {'public_artifact': name, 'archive_sha256': sha(blob), 'member': member.filename,
                    'member_bytes': len(payload), 'member_sha256': digest, 'kind': 'Exact_member_bytes_in_frozen_public_Git_archive'}
    archive_controls.append({'path': name, 'sha256': sha(blob), 'members': len(members), 'bytes_hashed': total, 'skipped_bounded_members': skipped})
classified = []
for row, path, digest in eligible:
    proof = proofs.get(digest)
    if proof:
        classified.append({**row, 'metadata_source_path': path, 'checksum': digest, 'proof': proof,
            'reason': 'Complete source-path/checksum evidence line; its entire checksum value is independently reproducible from exact public frozen artifact bytes. Relocated archive/preimage matches do not attest historical execution or original source-path identity.'})
    else:
        unclassified.append(row)
assert len(classified) + len(unclassified) == len(rows)
assert sha(report_path.read_bytes()) == sha(report_blob)
out.mkdir()
(out / 'driver.py').write_bytes(Path(__file__).read_bytes())
for name, value in [('classified.json', classified), ('unclassified-locations.json', unclassified), ('archive-controls.json', archive_controls)]:
    (out / name).write_bytes((json.dumps(value, indent=2) + '\n').encode())
summary = {'input_unclassified': len(rows), 'additional_reproducible_public_artifact_checksums': len(classified), 'remaining_unclassified': len(unclassified),
    'public_archives_examined': len(archives), 'remaining_rules': Counter(row['rule'] for row in unclassified),
    'scope': 'Read-only root triage of pinned prior report. Public archive members are read without extraction, never executed. No reconstructed execution RAW, scanner/allowlist change, new scan or final acceptance. Independent review required.'}
(out / 'summary.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode())
print(json.dumps(summary))
