from collections import Counter
from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path(r'F:\mb-r05-review-classifier-20261019')
report = Path(r'C:\Users\Consu\AppData\Local\Temp\metodobase-r05-reviewed-author-20261019\current-tree-scan.json')
out = Path(r'C:\Users\Consu\AppData\Local\Temp\metodobase-r05-current-fingerprint-triage-20261019')
head = 'f7b12a71a89de2e35b0035ccef147a673ad50d29'
sha = lambda blob: hashlib.sha256(blob).hexdigest()
git = lambda *args: subprocess.check_output(['git', '--no-replace-objects', *args], cwd=root)
assert not out.exists() and git('rev-parse', 'HEAD').decode().strip() == head
assert not git('status', '--porcelain', '--untracked-files=no')
blob = report.read_bytes()
assert sha(blob) == 'f273556e34d1796de1f8a01e17d58842be82c7a6ab2173bdeabb1a2d91714f8d'
data = json.loads(blob)
assert data['source_stable'] and not data['changed_files'] and data['remaining_finding_count'] == len(data['findings']) == 14557
tracked = set(git('ls-tree', '-r', '--name-only', '-z', head).decode().split('\0')[:-1])
cache = {}
public_file_proofs = {}
line_pattern = re.compile(r'\s*"(?P<path>[^"\\]+)"\s*:\s*"(?P<digest>[0-9a-f]{64})"\s*,?\s*')
by_file = {}
for row in data['findings']:
    by_file.setdefault(row['file'], []).append(row)
classified = []
unclassified = []
reasons = Counter()
for name, rows in by_file.items():
    source = root / name
    raw = source.read_bytes() if source.is_file() else b''
    if name not in tracked or sha(raw) != data['files'].get(name) or any(row['file_sha256'] != sha(raw) for row in rows):
        unclassified.extend(rows)
        reasons['finding_file_not_exact_frozen_scanned_bytes'] += len(rows)
        continue
    transform = data['encoding_transforms'].get(name)
    text = raw.decode(transform['source_encoding'] if transform else 'utf-8', errors='strict')
    lines = text.split('\n')
    for row in rows:
        line = lines[row['line'] - 1] if 0 < row['line'] <= len(lines) else ''
        match = line_pattern.fullmatch(line)
        if match is None or not name.startswith('docs/implementation/20261018-evolution/evidence/'):
            unclassified.append(row)
            reasons['not_a_complete_evidence_source_path_digest_line'] += 1
            continue
        target = match['path']
        digest = match['digest']
        if target not in cache:
            path = root / target
            payload = path.read_bytes() if target in tracked and path.is_file() else b''
            cache[target] = sha(payload) if payload and sha(payload) == data['files'].get(target) else None
        if cache[target] != digest:
            unclassified.append(row)
            reasons['source_digest_not_current_frozen_public_file'] += 1
            continue
        public_file_proofs[target] = digest
        classified.append({**row, 'source_path': target, 'source_sha256': digest, 'physical_line_sha256': sha(line.encode()),
            'reason': 'Complete metadata line names a tracked public file; its digest independently recomputed from unchanged frozen working bytes and equals the scanned source inventory. No scanner or allowlist change.'})
assert len(classified) + len(unclassified) == 14557
assert git('rev-parse', 'HEAD').decode().strip() == head and not git('status', '--porcelain', '--untracked-files=no')
assert sha(report.read_bytes()) == sha(blob)
assert all(sha((root / name).read_bytes()) == digest for name, digest in public_file_proofs.items())
out.mkdir()
(out / 'driver.py').write_bytes(Path(__file__).read_bytes())
for name, value in [('classified.json', classified), ('unclassified-locations.json', unclassified), ('source-digests.json', public_file_proofs)]:
    (out / name).write_bytes((json.dumps(value, indent=2) + '\n').encode())
summary = {'source': head, 'report_sha256': sha(blob), 'input_remaining': 14557, 'verified_source_fingerprint_locations': len(classified),
    'remaining_unclassified': len(unclassified), 'unclassified_reasons': reasons, 'rules': Counter(row['rule'] for row in data['findings']),
    'unclassified_top_files': Counter(row['file'] for row in unclassified).most_common(12),
    'scope': 'Read-only root triage of the pinned prior report; not a new scanner run, generic allowlist, final acceptance or classification of every finding. Independent review remains required.'}
(out / 'summary.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode())
print(json.dumps(summary))
