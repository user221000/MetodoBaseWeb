import hashlib
import json
from pathlib import Path

TMP=Path('C:/Users/Consu/AppData/Local/Temp')
original=TMP/'metodobase-gitleaks-public-artifact-triage.py'
raw=original.read_bytes();text=raw.decode()
replacements={
    r'F:\mb-progress-retirement-ui-20261019':r'F:\mb-r05-review-classifier-20261019',
    'metodobase-gitleaks-historical-fingerprint-triage-20261019':'metodobase-r05-current-historical-triage-20261019',
    'metodobase-retirement-ui-scan-7c_07ul3/secret-scan-full.json':'metodobase-r05-reviewed-author-20261019/current-tree-scan.json',
    'metodobase-gitleaks-public-artifact-triage-20261019':'metodobase-r05-current-artifact-triage-20261019',
    'de216543a2eec05584168cdb888f627901b0e0b1':'f7b12a71a89de2e35b0035ccef147a673ad50d29',
    '0e5d0cfc77c1626912beca8c9b39e91fe56464e9e9cc71502947e44288b09352':'f273556e34d1796de1f8a01e17d58842be82c7a6ab2173bdeabb1a2d91714f8d',
    '10850':'5405',
}
for old,new in replacements.items():
    assert old in text,old
    text=text.replace(old,new)
target=TMP/'metodobase-r05-current-artifact-triage-20261019.py';assert not target.exists();target.write_bytes(text.encode())
inverse=text
for old,new in reversed(list(replacements.items())):inverse=inverse.replace(new,old)
assert inverse.encode()==raw
proof={'base_digest':hashlib.sha256(raw).hexdigest(),'generated_digest':hashlib.sha256(target.read_bytes()).hexdigest(),
    'inverse_exact':True,'scope':'Read-only public artifact/member checksum phase; no extraction/execution;32MiB/member and128MiB/archive bounds retained. No generic scanner exceptions or acceptance.'}
(TMP/'metodobase-r05-current-artifact-derivation-20261019.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof))
