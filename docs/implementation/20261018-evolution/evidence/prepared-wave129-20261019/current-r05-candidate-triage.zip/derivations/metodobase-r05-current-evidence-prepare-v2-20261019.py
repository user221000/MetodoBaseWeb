import hashlib
import json
from pathlib import Path
import subprocess
import sys

TMP=Path('C:/Users/Consu/AppData/Local/Temp')
source=TMP/'metodobase-r05-current-evidence-triage-20261019.py'
failed=source.read_bytes();text=failed.decode()
replacements={
    "['git', '--no-replace-objects', *args]":"['git', '--no-replace-objects', '--literal-pathspecs', *args]",
    'wanted = {path for _, path, _ in eligible}':"wanted = {path for _, path, _ in eligible if not path.startswith('/') and ':' not in path and '\\\\' not in path and all(part not in {'', '.', '..'} for part in path.split('/'))}",
    'metodobase-r05-current-evidence-triage-20261019':'metodobase-r05-current-evidence-triage-v2-20261019',
}
for old,new in replacements.items():
    assert old in text,old
    text=text.replace(old,new)
target=TMP/'metodobase-r05-current-evidence-triage-v2-20261019.py';assert not target.exists();target.write_bytes(text.encode())
inverse=text
for old,new in reversed(list(replacements.items())):inverse=inverse.replace(new,old)
assert inverse.encode()==failed
proof={'base_digest':hashlib.sha256(failed).hexdigest(),'generated_digest':hashlib.sha256(target.read_bytes()).hexdigest(),
    'inverse_exact':True,'erratum':'First historical-evidence driver rejected an absolute /usr metadata path as Git pathspec. Successor limits Git lookup to canonical relative literal paths only. Ineligible input findings remain in the blocking output; none is dropped.',
    'original_failure_output':'observed in tool transcript; not retrospectively claimed as a captured RAW file'}
(TMP/'metodobase-r05-current-evidence-v2-derivation-20261019.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof))
out=TMP/'metodobase-r05-reviewed-author-20261019'
with (out/'evidence-v2-triage.stdout').open('xb') as stdout,(out/'evidence-v2-triage.stderr').open('xb') as stderr:
    result=subprocess.run([sys.executable,str(target)],cwd='F:/mb-r05-review-classifier-20261019',check=False,stdout=stdout,stderr=stderr)
assert result.returncode==0, result.returncode
print((out/'evidence-v2-triage.stdout').read_text())
