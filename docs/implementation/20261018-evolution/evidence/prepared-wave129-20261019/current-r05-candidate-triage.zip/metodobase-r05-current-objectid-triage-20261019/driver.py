from pathlib import Path
import collections
import hashlib
import json
import re
import subprocess

ROOT=Path('F:/mb-r05-review-classifier-20261019')
TMP=Path('C:/Users/Consu/AppData/Local/Temp')
OUT=TMP/'metodobase-r05-current-objectid-triage-20261019';assert not OUT.exists()
rows=json.loads((TMP/'metodobase-r05-current-evidence-triage-v2-20261019/unclassified-locations.json').read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git','--no-replace-objects','--literal-pathspecs',*args],cwd=ROOT)
pattern=re.compile(r'\s*"(?P<path>[^"\\]+)"\s*:\s*"(?P<oid>[0-9a-f]{40})"\s*,?\s*')
cache={};classified=[];remaining=[];shapes=[]
for row in rows:
    name=row['file']
    if name not in cache:
        raw=(ROOT/name).read_bytes();assert sha(raw)==row['file_sha256']
        enc=('utf-32' if raw.startswith((b'\xff\xfe\0\0',b'\0\0\xfe\xff')) else
            'utf-16' if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
        cache[name]=raw.decode(enc).split('\n')
    line=cache[name][row['line']-1];match=pattern.fullmatch(line)
    if match and not match['path'].startswith('/') and ':' not in match['path']:
        oid=match['oid'];kind=git('cat-file','-t',oid).decode().strip()
        if kind=='blob':
            raw=git('cat-file','blob',oid)
            assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid
            # Preserve the exact path witness in its frozen JSON's inventory;
            # additionally require the object at that path in a reachable tree.
            references=git('log','--all','--find-object='+oid,'--format=%H','--',match['path']).decode().splitlines()
            proven=None
            for commit in references:
                candidates=[commit]+git('rev-list','--parents','-n','1',commit).decode().split()[1:]
                for target in candidates:
                    found=subprocess.run(['git','--no-replace-objects','--literal-pathspecs','rev-parse',target+':'+match['path']],cwd=ROOT,capture_output=True,check=False)
                    if found.returncode==0 and found.stdout.decode().strip()==oid:
                        proven=target;break
                if proven:break
            if proven:
                classified.append({**row,'metadata_path':match['path'],'Git_blob_oid':oid,'witness_commit':proven,
                    'object_content_digest':sha(raw),'physical_line_sha256':sha(line.encode()),
                    'reason':'complete path/Git object inventory line; SHA1 recomputed over the actual blob header+bytes, with exact path witness in a reachable commit'})
                continue
    remaining.append(row)
OUT.mkdir()
for name,value in [('classified.json',classified),('unclassified-locations.json',remaining)]:
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
(OUT/'driver.py').write_bytes(Path(__file__).read_bytes())
summary={'input':len(rows),'verified_public_Git_object_inventory_locations':len(classified),'remaining':len(remaining),
    'files':len({r['file'] for r in remaining}),'scope':'candidate read-only classifications only; independent review required; no current full scanner acceptance'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
