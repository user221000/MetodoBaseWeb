from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path(r'F:\mb-r05-review-classifier-20261019')
tmp = Path(r'C:\Users\Consu\AppData\Local\Temp')
previous = tmp / 'metodobase-r05-current-artifact-triage-20261019'
report_path = tmp / 'metodobase-r05-reviewed-author-20261019/current-tree-scan.json'
out = tmp / 'metodobase-r05-current-evidence-triage-v2-20261019'
sha = lambda blob: hashlib.sha256(blob).hexdigest()
git = lambda *args: subprocess.check_output(['git', '--no-replace-objects', '--literal-pathspecs', *args], cwd=root)
assert not out.exists()
report_blob = report_path.read_bytes()
assert sha(report_blob) == 'f273556e34d1796de1f8a01e17d58842be82c7a6ab2173bdeabb1a2d91714f8d'
report = json.loads(report_blob)
rows = json.loads((previous / 'unclassified-locations.json').read_bytes())
assert len(rows) == 3859
pattern = re.compile(r'\s*"(?P<path>[^"\\]+)"\s*:\s*"(?P<digest>[0-9a-f]{64})"\s*,?\s*')
file_cache = {}
eligible = []
not_eligible = []
for row in rows:
    name = row['file']
    if name not in file_cache:
        blob = (root / name).read_bytes()
        assert sha(blob) == row['file_sha256'] == report['files'][name]
        transform = report['encoding_transforms'].get(name)
        file_cache[name] = blob.decode(transform['source_encoding'] if transform else 'utf-8', errors='strict').split('\n')
    lines = file_cache[name]
    match = pattern.fullmatch(lines[row['line'] - 1]) if 0 < row['line'] <= len(lines) else None
    if match and name.startswith('docs/implementation/20261018-evolution/evidence/'):
        eligible.append((row, match['path'], match['digest']))
    else:
        not_eligible.append(row)
wanted = {path for _, path, _ in eligible if not path.startswith('/') and ':' not in path and '\\' not in path and all(part not in {'', '.', '..'} for part in path.split('/'))}
commits = git('rev-list', '--all').decode().splitlines()
assert len(commits) == len(set(commits)) and all(re.fullmatch('[0-9a-f]{40}', value) for value in commits)
raw_log = git('log', '-m', '--raw', '--no-abbrev', '--no-renames', '-z', '--format=', *commits, '--', *sorted(wanted))
chunks = raw_log.split(b'\0')
objects = defaultdict(set)
index = 0
while index < len(chunks):
    meta = chunks[index].lstrip(b'\n')
    if not meta:
        index += 1
        continue
    assert meta.startswith(b':'), meta[:80]
    fields = meta[1:].split()
    assert len(fields) == 5
    path = chunks[index + 1].decode()
    if path in wanted:
        for mode, oid in [(fields[0], fields[2]), (fields[1], fields[3])]:
            if mode in {b'100644', b'100755'} and oid != b'0' * 40:
                objects[oid.decode()].add(path)
    index += 2
matches = {}
process = subprocess.Popen(['git', '--no-replace-objects', 'cat-file', '--batch'], cwd=root, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
try:
    for oid, paths in objects.items():
        process.stdin.write((oid + '\n').encode())
        process.stdin.flush()
        header = process.stdout.readline().decode().strip().split()
        assert len(header) == 3 and header[0] == oid and header[1] == 'blob'
        blob = process.stdout.read(int(header[2]))
        assert len(blob) == int(header[2]) and process.stdout.read(1) == b'\n'
        variants = {'Git_blob_bytes': blob}
        try:
            blob.decode('utf-8', errors='strict')
            if b'\0' not in blob and b'\n' in blob and b'\r\n' not in blob:
                variants['DERIVED_GitLF_to_CRLF_checksum_not_historical_RAW'] = blob.replace(b'\n', b'\r\n')
        except UnicodeDecodeError:
            pass
        for variant, content in variants.items():
            digest = sha(content)
            for path in paths:
                matches[(path, digest)] = {'Git_blob_oid': oid, 'derivation': variant, 'public_source_path': path, 'sha256': digest}
finally:
    process.stdin.close()
    assert process.wait(timeout=30) == 0 and not process.stderr.read()
classified = []
unclassified = list(not_eligible)
for row, path, digest in eligible:
    proof = matches.get((path, digest))
    if proof:
        classified.append({**row, **proof, 'reason': 'Whole source-path/digest metadata line equals checksum independently computed from a reachable Git blob at that exact path, or its explicitly labelled deterministic LF-to-CRLF variant. No historical RAW execution is reconstructed or claimed.'})
    else:
        unclassified.append(row)
assert len(classified) + len(unclassified) == len(rows)
assert sha(report_path.read_bytes()) == sha(report_blob)
out.mkdir()
(out / 'driver.py').write_bytes(Path(__file__).read_bytes())
for name, value in [('classified.json', classified), ('unclassified-locations.json', unclassified), ('pinned-commits.json', commits)]:
    (out / name).write_bytes((json.dumps(value, indent=2) + '\n').encode())
summary = {'input_unclassified': len(rows), 'additional_verified_public_source_fingerprints': len(classified),
    'remaining_unclassified': len(unclassified), 'public_Git_blobs_examined': len(objects), 'pinned_commits': len(commits),
    'derivations': Counter(row['derivation'] for row in classified), 'remaining_rules': Counter(row['rule'] for row in unclassified),
    'scope': 'Read-only secondary root triage of the pinned prior scan. Derived newline checksums are not reconstructed execution RAW. Scanner and allowlist unchanged. Remaining findings remain blocking; independent review required.'}
(out / 'summary.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode())
print(json.dumps(summary))
