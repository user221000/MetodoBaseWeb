import ast
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('F:/mb-google33-reviewed-common-20261019')
OUT=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-google33-common-compose-20261019')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.run(['git','--no-replace-objects',*args],cwd=ROOT,capture_output=True,check=True)
prepared=json.loads((OUT/'composition.json').read_bytes())
assert git('write-tree').stdout.decode().strip()==prepared['index_tree']
warning=(OUT/'whitespace-check.stdout').read_bytes()
assert warning==b'tests/test_google33_association_security.py:141: new blank line at EOF.\n'
path=ROOT/'tests/test_google33_association_security.py';before=path.read_bytes();after=before.rstrip(b'\n')+b'\n'
assert before==after+b'\n'
assert ast.dump(ast.parse(before),include_attributes=False)==ast.dump(ast.parse(after),include_attributes=False)
path.write_bytes(after)
git('-c','core.autocrlf=false','add','tests/test_google33_association_security.py')
git('diff','--cached','--check')
commit=git('commit','-m','Compose Google33 identity, account UI and reviewed scan classifier')
(OUT/'compose-commit.stdout').write_bytes(commit.stdout)
composed=git('rev-parse','HEAD').stdout.decode().strip()
before_tree=git('write-tree').stdout.decode().strip()
parents=['de506b6077ba055587f02e7d839387e7f5c56f84','bfbfcefd9f970893af6c306438f654a6df65e9c0',
    'a02a9ac04e0c619f6754bc86d89680d1a6bf95a0','f7b12a71a89de2e35b0035ccef147a673ad50d29']
merge=git('-c','core.autocrlf=false','merge','--no-ff','-s','ours','-m',
    'Preserve reviewed producer and historical31 ancestry after exact source composition',*parents)
(OUT/'ancestry-merge.stdout').write_bytes(merge.stdout)
head=git('rev-parse','HEAD').stdout.decode().strip();after_tree=git('write-tree').stdout.decode().strip()
assert before_tree==after_tree
for parent in parents:git('merge-base','--is-ancestor',parent,'HEAD')
assert not git('status','--porcelain=v1','-uno').stdout.strip()
sources=[]
for row in prepared['sources']:
    blob=(ROOT/row['path']).read_bytes();current=git('show','HEAD:'+row['path']).stdout
    assert current==blob
    if row['path']=='tests/test_google33_association_security.py':assert blob==after
    else:assert sha(blob)==row['digest']
    sources.append({**row,'composed_digest':sha(blob),'exact_producer_bytes':sha(blob)==row['digest']})
result={'base':prepared['base'],'compose_commit':composed,'head':head,'tree':after_tree,
    'preserved_ancestry':parents,'ancestry_only_merge_tree_exact':True,
    'sources':sources,'source_counts':{'imports':58,'exact_producer_Git_bytes':57,'one_test_EOF_only':1},
    'source_exception':{'path':'tests/test_google33_association_security.py','producer_digest':sha(before),
        'composed_digest':sha(after),'inverse_exact':after+b'\n'==before,'AST_exact':True,
        'reason':'one blank EOF line removed after retaining the exact producer warning; no test/assert/body changed'},
    'unrelated_git_entries_exact':prepared['unrelated_git_entries_exact'],'old_alembic_paths_exact':prepared['old_alembic_paths_exact'],
    'cleanup227_exact':True,'Dockerfile_exact':True,'working_tree_clean':True,
    'acceptance':'COMPOSED SOURCE ONLY; no current33 broad/PG/browser/provider/image PASS attributed'}
(OUT/'frozen-common.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
(OUT/'finish-driver.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({k:v for k,v in result.items() if k!='sources'}))
