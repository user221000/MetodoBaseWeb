import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess

ROOT=Path('F:/mb-google33-reviewed-common-20261019')
OUT=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-google33-common-compose-20261019')
OUT.mkdir(exist_ok=False)
BASE='6f822ff50d93e01bb10249556a9bfc4e1a3b246b'
PRODUCERS=[('backend','fcfb55e5849e0e20b568be8729dcc1b8c6b1762e','bfbfcefd9f970893af6c306438f654a6df65e9c0',37),
    ('frontend','2273616eb218adfdd30680e111da50a4599a8c53','a02a9ac04e0c619f6754bc86d89680d1a6bf95a0',17),
    ('finite_scanner',BASE,'f7b12a71a89de2e35b0035ccef147a673ad50d29',4)]
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,check=True):
    return subprocess.run(['git','--no-replace-objects',*args],cwd=ROOT,check=check,capture_output=True)
def tree(ref):
    result={}
    for row in git('ls-tree','-r','-z','--full-tree',ref).stdout.split(b'\0'):
        if not row:continue
        metadata,name=row.split(b'\t',1);mode,kind,oid=metadata.decode().split()
        assert kind=='blob'
        result[name.decode()]={'mode':mode,'oid':oid}
    return result
assert git('rev-parse','HEAD').stdout.decode().strip()==BASE
assert not git('status','--porcelain=v1','-uno').stdout.strip()
base=tree(BASE);changed={};records=[]
for owner,parent,head,expected in PRODUCERS:
    names=[n for n in git('diff','--name-only','-z',parent,head).stdout.decode().split('\0') if n and not n.startswith('docs/')]
    assert len(names)==expected,(owner,len(names),names)
    source_tree=tree(head)
    for name in names:
        assert name not in changed and PurePosixPath(name).as_posix()==name and '..' not in PurePosixPath(name).parts
        entry=source_tree[name];assert entry['mode']=='100644'
        blob=git('show',head+':'+name).stdout
        destination=ROOT/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(blob)
        changed[name]=entry
        records.append({'path':name,'owner':owner,'producer':head,'mode':entry['mode'],'git_blob':entry['oid'],
            'bytes':len(blob),'digest':sha(blob),'scope':'exact producer Git bytes; not a claim that its execution RAW had LF'})
git('-c','core.autocrlf=false','add','--',*sorted(changed))
index=tree(git('write-tree').stdout.decode().strip())
assert set(index)==set(base)|set(changed)
assert all(index[name]==entry for name,entry in changed.items())
assert all(index[name]==entry for name,entry in base.items() if name not in changed)
assert all(sha((ROOT/row['path']).read_bytes())==row['digest'] for row in records)
assert (ROOT/'web/routes/progress_retirement.py').read_bytes()==git('show',BASE+':web/routes/progress_retirement.py').stdout
assert index['Dockerfile']==base['Dockerfile']
targets=[name for name in base if name.startswith('web/database/alembic/')]
assert all(index[name]==base[name] for name in targets)
check=git('diff','--cached','--check',check=False)
(OUT/'whitespace-check.stdout').write_bytes(check.stdout)
(OUT/'whitespace-check.stderr').write_bytes(check.stderr)
result={'base':BASE,'producers':PRODUCERS,'imported':len(changed),'unrelated_git_entries_exact':len(base)-len(set(base)&set(changed)),
    'old_alembic_paths_exact':len(targets),'cleanup227_exact':True,'Dockerfile_exact':True,
    'index_tree':git('write-tree').stdout.decode().strip(),'whitespace_exit':check.returncode,
    'whitespace_output_digest':sha(check.stdout),'whitespace_lines':len(check.stdout.splitlines()),'sources':records,
    'status':'staged exact blobs; commit awaits explicit review of any producer whitespace warnings'}
(OUT/'composition.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
(OUT/'driver.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({k:v for k,v in result.items() if k!='sources'}))
if check.returncode:print(check.stdout.decode('utf-8',errors='replace')[:1000])
