import json,sys
from pathlib import Path
p,k,n,s,bad=sys.argv[1:]
n=int(n);s=int(s)
r={'checks':[{'name':str(i)} if k=='named' else str(i) for i in range(n)],'pageErrors':[],'screens':[str(i) for i in range(s)]}
if bad=='empty':r['checks']=[]
Path(p).write_text(json.dumps(r))
