from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
ROOT=Path('F:/mb-qa-account37-20261020');T=Path(__file__).resolve().parent;P=T/'private'
PROFILE=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-qa-pg55483-private-ok6hrpyq/env.json')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
spec=importlib.util.spec_from_file_location('qa_snapshot','C:/Users/Consu/AppData/Local/Temp/metodobase-qa-nutrition35-saas-20261020/phase.py')
lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib);lib.ROOT=ROOT;lib.TASK=T;lib.PRIVATE=P
def photograph(label):
    data=lib.snapshot(label)
    config=json.loads(PROFILE.read_bytes());pg=Path(config['METODOBASE_TEST_PG_BIN'])
    data.update(profile_sha256=sha(PROFILE.read_bytes()),Python_base_sha256=sha(Path(sys._base_executable).read_bytes()),
                PG_tools={name:sha((pg/name).read_bytes()) for name in ['pg_dump.exe','pg_restore.exe']})
    (P/(label+'-full.json')).write_text(json.dumps(data,indent=2),encoding='utf-8')
    return data
def main(stage):
    assert stage in {'restore2'} and (T/'SQL-ACK.json').exists()
    assert not (T/(stage+'-summary.json')).exists()
    before=photograph(stage+'-before');lib.pipcheck(stage+'-before')
    start=time.monotonic()
    with (P/(stage+'.stdout')).open('xb') as out,(P/(stage+'.stderr')).open('xb') as err:
        result=subprocess.run([sys.executable,'-B','-X','utf8',str(T/'runner_restore2.py'),stage],cwd=ROOT,stdout=out,stderr=err)
    tree=ET.parse(P/stage/'junit.xml').getroot();suites=list(tree) if tree.tag=='testsuites' else [tree]
    counts={key:sum(int(row.get(key,0)) for row in suites) for key in ['tests','failures','errors','skipped']}
    leases=[json.loads(path.read_bytes()) for path in (T/'leases').glob('lease-*.json')]
    assert all(row['state']=='closed_absent' and row['sessions_before_drop']==0 for row in leases)
    import psycopg2
    config=json.loads(PROFILE.read_bytes());url=config.get('METODOBASE_TEST_MIGRATOR_URL',config.get('migrator_url'))
    with psycopg2.connect(url.replace('postgresql+psycopg2://','postgresql://',1)) as db,db.cursor() as cursor:
        for row in leases:
            cursor.execute('SELECT count(*) FROM pg_database WHERE datname=%s',(row['database'],));assert cursor.fetchone()[0]==0
            cursor.execute('SELECT count(*) FROM pg_stat_activity WHERE datname=%s',(row['database'],));assert cursor.fetchone()[0]==0
    (P/(stage+'-fresh-absence.json')).write_text(json.dumps({'owned_databases':[row['database'] for row in leases],'all_sessions_zero':True,'all_absent':True,'new_control_connection':True,'FORCE_or_cancel_used':False},indent=2),encoding='utf-8')
    after=photograph(stage+'-after');lib.pipcheck(stage+'-after')
    quiet={key:before[key]==after[key] for key in before};assert all(quiet.values()),quiet
    record={'source_head':before['head'],'stage':stage,'exit_code':result.returncode,'counts':counts,
            'elapsed_s':round(time.monotonic()-start,3),'quiet':quiet,'source_files':len(before['source']),
            'packages':len(before['packages']),'installed_files':len(before['installed']),'pip':[0,0],
            'owned_databases_closed_so_far':len(leases),'fresh_absence_and_zero_sessions':True,'no_Chrome_Redis_VM_provider':True}
    (T/(stage+'-summary.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps(record),flush=True)
    return result.returncode
if __name__=='__main__':raise SystemExit(main(sys.argv[1]))
