from pathlib import Path
import importlib.util,json,os,socket,sys
ROOT=Path('F:/mb-qa-account37-20261020');T=Path(__file__).resolve().parent;P=T/'private'
PROFILE=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-qa-pg55483-private-ok6hrpyq/env.json')
os.chdir(ROOT);sys.path.insert(0,str(ROOT));sys.dont_write_bytecode=True
for key in ('_METODOBASE_TEST_ROOT','METODOBASE_TEST_DATABASE_URL','METODOBASE_TEST_MIGRATOR_URL',
            'METODOBASE_TEST_POSTGRES_URL','METODOBASE_TEST_REDIS_URL'):
    os.environ.pop(key,None)
data=P/'metodobase-test-account37';data.mkdir(exist_ok=True)
os.environ['_METODOBASE_TEST_ROOT']=str(data)
from tests.isolation import prepare_environment,block_external_sockets
prepare_environment(discard_inherited=True);block_external_sockets()
stage=sys.argv[1]
if stage=='collect':
    def no_connection(*args,**kwargs):raise RuntimeError('No network is permitted during QA collection/preflight')
    socket.socket.connect=no_connection;socket.socket.connect_ex=no_connection
else:
    assert (T/'SQL-ACK.json').is_file(),'Explicit ROOT SQL plan ACK required'
    config=json.loads(PROFILE.read_bytes())
    for key,alias in [('METODOBASE_TEST_MIGRATOR_URL','migrator_url'),('METODOBASE_TEST_POSTGRES_URL','app_url')]:
        os.environ[key]=config.get(key,config.get(alias))
    os.environ['METODOBASE_TEST_PG_BIN']=config['METODOBASE_TEST_PG_BIN']
os.environ['ACCOUNT37_PRIVATE_LEASES']=str(T/'leases')
output=P/stage;output.mkdir(exist_ok=False)
os.environ['METODOBASE_TEST_EVIDENCE_DIR']=str(output)
import pytest
class Fence:
    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_call(self,item):
        yield
        if stage=='http':
            from tests.account37_qa_pg_fixtures import assert_blank_pool
            from sqlalchemy import text
            case=item.funcargs['account_http'];shared=item.funcargs['peer37_database'][1]
            assert case['engine'] is shared
            assert_blank_pool(shared)
            with shared.connect() as db:
                gucs=tuple(db.execute(text("SELECT current_setting('app.current_tenant',true),current_setting('app.mfa_actor',true),current_setting('app.client_invitation_digest',true),current_setting('app.notification_exclude_digest',true)")).one())
            assert gucs==('','','','') and shared.pool.checkedout()==0
            with (output/'actual-HTTP-pool-receipts.jsonl').open('a',encoding='utf-8') as stream:
                stream.write(json.dumps({'nodeid':item.nodeid,'factory':case['factory_name'],'same_engine_as_autouse':True,'checked_out':0,'GUCs':list(gucs)})+'\n')
    def pytest_collection_finish(self,session):
        origins={}
        for name,module in list(sys.modules.items()):
            if name.split('.')[0] not in {'web','api','core','config','src','tests','scripts'}:continue
            filename=getattr(module,'__file__',None)
            if filename:
                path=Path(filename).resolve();assert path.is_relative_to(ROOT),(name,str(path))
                origins[name]=path.relative_to(ROOT).as_posix()
        from web.database.models import Base
        assert Path(sys.modules[Base.__module__].__file__).resolve().is_relative_to(ROOT)
        (output/'module-origins.json').write_text(json.dumps({'source_root':str(ROOT),'Base_exact_root':True,'modules':origins,'external_plugin':'Only this explicit private QA runner, no external tests.'},indent=2),encoding='utf-8')
        (output/'nodeids.json').write_text(json.dumps([item.nodeid for item in session.items],indent=2),encoding='utf-8')
import pytest
targets=['tests/integration_security_account37_peer.py','tests/integration_current37_restore.py'] if stage=='collect' else ['tests/integration_security_account37_peer.py'] if stage in {'peer','http'} else ['tests/integration_current37_restore.py']
args=['--noconftest','--import-mode=importlib','-p','no:cacheprovider','-q','--tb=short','--basetemp',str(output/'pytest'),'--junitxml',str(output/'junit.xml'),*targets]
if stage=='http':args.extend(['-k','bearer_b_and_contact or rejected_admission or unexpected_failure or public_get_with_proof'])
if stage=='collect':args.insert(0,'--collect-only')
raise SystemExit(pytest.main(args,plugins=[Fence()]))
