from collections import Counter
from pathlib import Path, PurePosixPath
import ast
import hashlib
import io
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile

R = Path(r"F:\mb-r05-review-classifier-20261019")
T = Path(r"C:\Users\Consu\AppData\Local\Temp")
O = T/"metodobase-desktop35-author-final-v2-20261020"
C = T/"metodobase-desktop35-author-seal-20261020"
PRIVATE = T/"metodobase-desktop35-author-private-20261020"
P = R/"docs/implementation/20261018-evolution/evidence/desktop35-author-20261020"
HEAD = "0d20f6b55bd348edc3f140081f41f12b545b88bf"
BASE = "55a3f4f9b1c1d03937bae78a5cee4f1d1b6379af"
SHA = lambda data: hashlib.sha256(data).hexdigest()
ENC = lambda value: (json.dumps(value,ensure_ascii=False,indent=2)+"\n").encode()

def git(*args):
    return subprocess.check_output(["git",*args],cwd=R)

assert git("rev-parse","HEAD").decode().strip() == HEAD
assert not git("status","--porcelain").strip()
assert not C.exists() and not PRIVATE.exists() and not P.exists()
C.mkdir()
result = json.loads((O/"result.json").read_bytes())
assert result["baseline_cases"] == {"tests":4,"failures":4,"errors":0,"skipped":0}
assert result["after_cases"] == {"tests":100,"failures":0,"errors":0,"skipped":0}
assert result["source_quiet"] and result["packages_quiet"]
assert result["pip_before"]["exit"] == result["pip_after"]["exit"] == result["green"]["exit"] == 0
assert not result["ruff_new_diagnostics"]
assert set(git("diff","--name-only",BASE,HEAD).decode().splitlines()) == set(result["scope"])
for name,expected in result["source_sha256"].items():
    data = (R/name).read_bytes()
    assert SHA(data) == expected and git("show",HEAD+":"+name) == data

originals = {}
for phase in ("metodobase-desktop35-author-20261020", "metodobase-desktop35-author-v2-20261020",
              "metodobase-desktop35-author-final-20261020", "metodobase-desktop35-author-final-v2-20261020"):
    for path in sorted((T/phase).rglob("*")):
        if path.is_file():
            assert not path.is_symlink()
            originals[phase+"/"+path.relative_to(T/phase).as_posix()] = path.read_bytes()
for name in ("metodobase-desktop35-author-run-20261020.py", "metodobase-desktop35-prepare-v2-20261020.py",
             "metodobase-desktop35-author-run-v2-20261020.py", "metodobase-desktop35-author-final-run-20261020.py",
             "metodobase-desktop35-author-final-run-v2-20261020.py", "metodobase-desktop35-author-seal-20261020.py"):
    originals["drivers/"+name] = (T/name).read_bytes()
for name in result["scope"]:
    originals["products/"+name] = (R/name).read_bytes()

acl_source = Path(r"F:\MetodoBaseWeb-execution-20261018\docs\implementation\20261018-evolution\evidence\root-mfa31-reviewed-serial-20261019\archive-acl.ps1")
acl = acl_source.read_text(encoding="utf-8")
old = "$names = @('serial-originals.zip')"
assert acl.count(old) == 1
acl = acl.replace(old,"$names = @('desktop35-originals.zip')")
(C/"archive-acl.ps1").write_bytes(acl.encode())

def protect(mode):
    call = subprocess.run(["powershell.exe","-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass",
        "-File",str(C/"archive-acl.ps1"),"-Mode",mode,"-PrivateRoot",str(PRIVATE)],capture_output=True)
    (C/("acl-"+mode+".stdout")).write_bytes(call.stdout)
    (C/("acl-"+mode+".stderr")).write_bytes(call.stderr)
    assert call.returncode == 0
    return json.loads(call.stdout.decode("utf-8-sig"))

protect("create")
before_acl = protect("verify")
assert before_acl["verified_before_payload"]
archive = PRIVATE/"desktop35-originals.zip"
assert archive.stat().st_size == 0
with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED) as z:
    for name,data in originals.items():
        z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(originals)
    assert all(z.read(name) == data for name,data in originals.items())
final_acl = protect("final")

# Selected public originals retain exact bytes. Installed-file inventories and
# the obsolete overlong-param pytest error remain in the protected full archive.
selected = {}
for name in ("after.log","after.xml","baseline.log","baseline.xml","pip-before.log","pip-after.log",
             "result.json","ruff.baseline.json","ruff.current.json"):
    selected["final/"+name] = (O/name).read_bytes()
for path in (O/"preimages").rglob("*"):
    if path.is_file():
        selected["preimages/"+path.relative_to(O/"preimages").as_posix()] = path.read_bytes()
for name in result["scope"]:
    selected["products/"+name] = (R/name).read_bytes()
for name in ("metodobase-desktop35-author-final-run-v2-20261020.py", "metodobase-desktop35-author-seal-20261020.py"):
    selected["drivers/"+name] = (T/name).read_bytes()

definition = next(node for node in ast.parse((T/"metodobase-checkpoint119-prepare.py").read_bytes()).body
                  if isinstance(node,ast.FunctionDef) and node.name == "scan")
exec(compile(ast.Module(body=[definition],type_ignores=[]),"scanner119","exec"))
for name,data in selected.items():
    scan(data,name)
buffer = io.BytesIO()
with zipfile.ZipFile(buffer,"w",zipfile.ZIP_DEFLATED) as z:
    for name,data in selected.items():
        z.writestr(name,data)
cases = ET.parse(O/"after.xml").findall(".//testcase")
case_counts = dict(Counter(case.attrib["classname"] for case in cases))
summary = {
    "product_head":HEAD,"base_head":BASE,"product_paths":len(result["scope"]),
    "author_passed":100,"errors":0,"skipped":0,"case_counts":case_counts,
    "baseline_red":4,"baseline_error":0,"baseline_source_exact":True,
    "source_count":1081,"package_count":83,"package_python_and_metadata_files":8562,
    "source_and_packages_quiet":True,"pip_before":0,"pip_after":0,
    "ruff_preexisting_before":87,"ruff_current":70,"ruff_new_diagnostics":0,
    "QA19_confirmed":"Real 55a3 Qt edit handler calls missing actualizar_cliente; same assertion passes after fix",
    "scope":"SQLite persistence and supported Qt gym/personal flows; constructors and crypto service remain existing domain adapters",
    "not_claimed":["independent QA/security acceptance","packaged installer validation","PostgreSQL", "clinical validation", "filesystem/database atomic publication", "global at-rest encryption", "global gitleaks acceptance"],
}
source = {
    "product_head":HEAD,"base_head":BASE,"source_sha256":result["source_sha256"],
    "preimage_sha256":result["preimage_sha256"],
    "wire_file_sha256":SHA((R/"docs/implementation/20261018-evolution/NUTRICION35_WIRE.json").read_bytes()),
    "private_original_manifest":{name:{"bytes":len(data),"sha256":SHA(data)} for name,data in originals.items()},
    "selected_public_original_manifest":{name:{"bytes":len(data),"sha256":SHA(data)} for name,data in selected.items()},
    "private_archive":{"basename":archive.name,"sha256":SHA(archive.read_bytes()),"members":len(originals)},
    "private_acl_before_payload":before_acl,"private_acl_final":final_acl,
    "execution_directories_acl_at_creation_attested":False,
    "selected_public_originals_exact":True,
    "package_attestation_boundary":"83 distributions, 8562 Python/.pyi/METADATA files and both Python executable bytes; not all DLLs or a built installer",
    "source_attestation_boundary":"1081 tracked/non-document source entries plus new product files, exact before/after; documents excluded",
    "first_harness_erratum":"Initial obsolete run had 21 passed plus setup/teardown errors on one oversize parameter whose generated pytest ID exceeded Windows environment length. Only short parameter IDs fixed; RAW retained privately. Later final run has 100 passed.",
}
review = """# Declaraciones nutricionales en desktop: candidato local

Producto 0d20f6b55bd348edc3f140081f41f12b545b88bf sobre 55a3f4f9.
Son doce rutas de producto/pruebas. La fuente base y el soporte desktop se
conservan. No se modifican Alembic, web/API ni los constructores de dominio.

SQLite añade una columna nullable nutrition_restrictions_storage. NULL antiguo
sigue siendo información desconocida, sin afirmar ausencia de alergias. La
envoltura cerrada version1 contiene modo plain/cipher y payload JSON version1
con declaration y excluded_foods separados. Máximo 131072 bytes del JSON interior
y 262144 de envoltura. Rechaza claves duplicadas, formatos/IDs desconocidos,
corrupción y ciphertext sin clave. CryptoService protege los nuevos hechos
cuando se elige modo seguro; una clave ausente no autoriza plaintext. Un cambio
explícito tampoco rebaja ciphertext a plaintext. Esto no afirma cifrado global
del resto de campos o de archivos anteriores.

La escritura de perfil y snapshot usa una transacción BEGIN IMMEDIATE; omitir
declaración o pasar None conserva la celda anterior. La migración segura cifra
los snapshots existentes y revierte toda la transacción si una fila es inválida.
La actualización de perfil resuelve actualizar_cliente ausente y evita contar
esa edición como otro plan. Las búsquedas parciales se hidratan por ID antes de
editar. Los controles Qt permiten unknown/none/reported, other_reported, pedir
revisión y excluir alimentos del catálogo. Guardar el perfil sigue disponible
con una declaración que bloquea generación. Editar otros datos no reemplaza la
declaración precargada si el usuario no la cambió.

Los tres workers Qt reales reciben y comprueban los hechos antes de motor,
constructores y PDF. Los objetos parciales deben usar el snapshot persistido;
un snapshot explícito diferente requiere guardar/revisar el perfil. La escritura
para plan y el historial vuelven a comprobarlo bajo bloqueo SQLite. Un alta con
hechos nuevos requiere guardarlos explícitamente antes de registrar generación.
El flujo personal conserva el archivo de preferencias y sus campos ajenos,
añade una única clave versionada, protege según su modo de cifrado y usa replace
desde un archivo temporal único. Un archivo existente ilegible no se reinicia a
vacío. Un guardado no confirmado mantiene el formulario abierto. El worker
personal comprueba el snapshot antes de CPU, antes de PDF y antes del éxito.

No se mutan CATEGORIAS globales. El ensayo concurrente ejecutó dos constructores
de opciones reales con exclusiones diferentes, validó ambos planes y comprobó
igualdad global antes/después; PDF y señales fueron dobles de borde. Los tres
workers se invocaron con entradas/senales de prueba para demostrar que el guard
impide CPU/constructores/salida; no se atribuye una sesión visual completa. Qt
registro/perfil sí se montaron offscreen y sus handlers se ejecutaron.

Hay 100 PASS, cero errores/skips. La preimagen exacta 55a3 de gestor y diálogo
produjo cuatro RED esperados, incluido AttributeError en actualizar_cliente
(candidato QA-19). La misma aserción de aceptación y persistencia pasa después.
El upgrade usó una base real creada por el gestor antiguo y conservó filas e
historial. Se ensayaron rollback, cifrado, clave ausente, corrupción, omisión,
snapshot stale, listas/exclusiones, estados Qt y fallos de guardado. Pip 0/0;
1081 fuentes, 83 distribuciones, 8562 Python/pyi/METADATA y ambos Python quietos.
Ruff pasa en los tres archivos nuevos; 87 diagnósticos previos bajan a70 sin
diagnósticos nuevos. No se declara que todo el código heredado esté libre de lint.

Límites: un PDF que ya se exportó puede seguir en disco si el perfil cambia antes
del registro final; el SQL rechaza el historial/éxito, sin prometer atomicidad con
filesystem. Las comprobaciones de preferencias son snapshots, no una transacción
distribuida con PDF. El formato antiguo se actualiza sin borrar datos; no se ha
validado usar binarios antiguos que ignoran las nuevas declaraciones. No hay
validación clínica, instalador nuevo, prueba visual interactiva, PostgreSQL,
proveedor real ni aceptación independiente integrada en esta evidencia.

Los RAW finales seleccionados son exactos. Los inventarios completos de paquetes
y la salida del primer harness obsoleto están en la copia privada protegida antes
del payload y verificada después. No hay atestación retroactiva de ACL de los
directorios originales. El guard recursivo119 no sustituye un gitleaks global.
"""
public = {".gitattributes":b"* -text\n","author-evidence.zip":buffer.getvalue(),
          "archive-acl.ps1":(C/"archive-acl.ps1").read_bytes(),"summary.json":ENC(summary),
          "source.json":ENC(source),"review.md":review.encode()}
for name,data in public.items():
    scan(data,name)
P.mkdir()
for name,data in public.items():
    (P/name).write_bytes(data)
manifest = {path.name:{"bytes":path.stat().st_size,"sha256":SHA(path.read_bytes())}
            for path in P.iterdir() if path.is_file()}
(P/"manifest.json").write_bytes(ENC(manifest))
prefix = P.relative_to(R).as_posix()
git("-c","core.autocrlf=false","add","-f","--",prefix)
git("diff","--cached","--check")
for path in P.iterdir():
    assert git("show",":"+path.relative_to(R).as_posix()) == path.read_bytes()
git("commit","-m","Seal desktop nutrition persistence and Qt author evidence")
sealed = {"head":git("rev-parse","HEAD").decode().strip(),"product_head":HEAD,"files":7,
          "source_sha256":SHA((P/"source.json").read_bytes()),"manifest_sha256":SHA((P/"manifest.json").read_bytes()),
          "canary_sha256":result["source_sha256"]["tests/test_desktop35_nutrition.py"]}
(C/"result.json").write_bytes(ENC(sealed))
print(json.dumps(sealed))
