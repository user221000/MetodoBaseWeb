﻿"""Final desktop author gate; no installs, providers, services or app data."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(r"F:\mb-r05-review-classifier-20261019")
PYTHON = Path(r"C:\Users\Consu\AppData\Local\Temp\metodobase-desktop31215-package-20261019\Scripts\python.exe")
RUFF = Path(r"C:\Users\Consu\AppData\Local\Temp\metodobase-qa-20261018\Scripts\python.exe")
OUT = Path(r"C:\Users\Consu\AppData\Local\Temp\metodobase-desktop35-author-final-v2-20261020")
OUT.mkdir(exist_ok=False)
BASE = "55a3f4f9b1c1d03937bae78a5cee4f1d1b6379af"
NEW = ["core/services/nutrition_storage.py", "tests/test_desktop35_nutrition.py",
       "ui_desktop/pyside/nutrition_declaration_widget.py"]
MODIFIED = subprocess.check_output(["git", "diff", "--name-only", BASE], cwd=ROOT).decode().splitlines()
PATHS = sorted(set(MODIFIED + NEW))
env = os.environ.copy()
env.update(QT_QPA_PLATFORM="offscreen", PYTHONDONTWRITEBYTECODE="1")

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

preimages = {}
for name in MODIFIED:
    data = subprocess.check_output(["git", "show", BASE+":"+name], cwd=ROOT)
    dest = OUT/"preimages"/name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    preimages[name] = hashlib.sha256(data).hexdigest()
env["DESKTOP35_OLD_GESTOR"] = str(OUT/"preimages/src/gestor_bd.py")

def run(name, args, more=None, executable=PYTHON):
    local = env.copy()
    local.update(more or {})
    started = time.monotonic()
    with (OUT/(name+".log")).open("wb") as output:
        result = subprocess.run([str(executable), "-X", "utf8", *args], cwd=ROOT, env=local,
                                stdout=output, stderr=subprocess.STDOUT, check=False)
    return {"exit": result.returncode, "elapsed_seconds": round(time.monotonic()-started, 3),
            "log_sha256":digest(OUT/(name+".log"))}

def sources():
    names = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT).decode().split("\0") + NEW
    return {name:digest(ROOT/name) for name in sorted(set(names))
            if name and (ROOT/name).is_file() and not name.startswith(("docs/", "evidence/"))}

PACKAGE_SCRIPT = '''import hashlib, importlib.metadata, json, pathlib, sys
result = {"python":str(pathlib.Path(sys.executable)),"base_python_sha256":hashlib.sha256(pathlib.Path(sys._base_executable).read_bytes()).hexdigest(),"packages":{}}
for dist in importlib.metadata.distributions():
    files = {}
    for relative in dist.files or ():
        path = pathlib.Path(dist.locate_file(relative))
        if path.is_file() and (path.suffix in {".py", ".pyi"} or path.name == "METADATA"):
            files[str(relative)] = hashlib.sha256(path.read_bytes()).hexdigest()
    result["packages"][dist.metadata["Name"].lower()]={"version":dist.version,"python_and_metadata_files":files}
print(json.dumps(result,sort_keys=True))'''

def packages(phase):
    data = subprocess.check_output([str(PYTHON),"-X","utf8","-c",PACKAGE_SCRIPT],env=env,cwd=ROOT)
    (OUT/("packages."+phase+".json")).write_bytes(data)
    return json.loads(data)

def ruff(phase, baseline=False):
    diagnostics = []
    for name in MODIFIED if baseline else PATHS:
        source = (OUT/"preimages"/name).read_bytes() if baseline else (ROOT/name).read_bytes()
        call = subprocess.run([str(RUFF),"-m","ruff","check","--stdin-filename",name,"--output-format","json","-"],
                              input=source,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert call.returncode in (0,1), call.stderr.decode(errors="replace")
        for row in json.loads(call.stdout):
            diagnostics.append({"path":name,"code":row["code"],"message":row["message"],"location":row["location"]})
    (OUT/("ruff."+phase+".json")).write_text(json.dumps(diagnostics,indent=2),encoding="utf-8")
    return Counter((row["path"],row["code"],row["message"]) for row in diagnostics)

before = sources()
(OUT/"sources.before.json").write_text(json.dumps(before,indent=2),encoding="utf-8")
pkg_before = packages("before")
results = {"baseline":BASE,"scope":PATHS,"preimage_sha256":preimages,"source_count":len(before),
           "python_sha256":digest(PYTHON),"pip_before":run("pip-before",["-m","pip","check"])}
results["red"] = run("baseline",["tests/run_isolated.py","tests/test_desktop35_nutrition.py","-q",
    "-k","persisted_declared_facts_roundtrip or secure_mode_without_key or stale_snapshot_does_not or edit_handler_uses",
    "--junitxml="+str(OUT/"baseline.xml")],{
        "DESKTOP35_BASELINE_GESTOR":str(OUT/"preimages/src/gestor_bd.py"),
        "DESKTOP35_BASELINE_DIALOG":str(OUT/"preimages/ui_desktop/pyside/dialogo_registro_cliente.py")})
results["green"] = run("after",["tests/run_isolated.py","tests/test_desktop35_nutrition.py",
    "tests/test_nutrition35_restrictions.py","tests/services/test_crypto_service.py",
    "tests/test_desktop_entrypoints.py","-q","--junitxml="+str(OUT/"after.xml")])
baseline_ruff = ruff("baseline",baseline=True)
current_ruff = ruff("current")
results["ruff_new_diagnostics"] = [list(item)+[count] for item,count in (current_ruff-baseline_ruff).items()]
results["ruff_baseline_count"] = sum(baseline_ruff.values())
results["ruff_current_count"] = sum(current_ruff.values())
results["pip_after"] = run("pip-after",["-m","pip","check"])
pkg_after = packages("after")
after = sources()
(OUT/"sources.after.json").write_text(json.dumps(after,indent=2),encoding="utf-8")
results.update(source_quiet=before==after,packages_quiet=pkg_before==pkg_after,
               package_count=len(pkg_before["packages"]),
               package_python_and_metadata_files=sum(len(row["python_and_metadata_files"]) for row in pkg_before["packages"].values()))
for phase in ("baseline","after"):
    suite = ET.parse(OUT/(phase+".xml")).getroot()
    results[phase+"_cases"] = {key:sum(int(row.get(key,0)) for row in suite.iter("testsuite"))
                              for key in ("tests","failures","errors","skipped")}
results["source_sha256"] = {name:digest(ROOT/name) for name in PATHS}
(OUT/"result.json").write_text(json.dumps(results,indent=2),encoding="utf-8")
print(json.dumps({key:value for key,value in results.items() if key not in {"source_sha256","preimage_sha256","scope"}}))
assert results["baseline_cases"] == {"tests":4,"failures":4,"errors":0,"skipped":0}
assert results["green"]["exit"] == results["pip_before"]["exit"] == results["pip_after"]["exit"] == 0
assert results["source_quiet"] and results["packages_quiet"] and not results["ruff_new_diagnostics"]

