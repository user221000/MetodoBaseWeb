# -*- coding: utf-8 -*-
"""
GestorPreferencias — Almacén ligero de preferencias por usuario.

Guarda un JSON por usuario en ~/.metodobase/prefs/<id_usuario>.json.
Contiene: perfil corporal, alimentos excluidos, idioma, etc.

API pública
───────────
  gestor = GestorPreferencias(id_usuario)
  datos  = gestor.cargar()               # dict (vacío si no existe)
  gestor.guardar(datos)                  # persiste
  gestor.actualizar(clave, valor)        # actualiza un subconjunto y persiste
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

from core.services.nutrition_storage import (
    NutritionStorageUnavailable,
    decode_restrictions,
    encode_restrictions,
    restrictions_from_row,
    storage_mode,
)
from utils.logger import logger

_BASE_DIR = Path.home() / ".metodobase" / "prefs"


def _prefs_path(id_usuario: str) -> Path:
    """Devuelve la ruta del archivo de preferencias para un usuario."""
    _BASE_DIR.mkdir(parents=True, exist_ok=True)
    # Normalizar id para nombre de archivo seguro
    safe_id = "".join(c for c in id_usuario if c.isalnum() or c in "-_")
    return _BASE_DIR / f"{safe_id}.json"


class GestorPreferencias:
    """Gestor de preferencias persistentes por usuario (JSON en disco)."""

    def __init__(self, id_usuario: str, *, secure_mode: bool = False, crypto_service=None) -> None:
        if not id_usuario:
            raise ValueError("id_usuario no puede estar vacío.")
        self._id = id_usuario
        self._path = _prefs_path(id_usuario)
        self._secure_mode = secure_mode
        self._crypto_service = crypto_service

    # ── API pública ───────────────────────────────────────────────────────

    def _read_disk(self) -> dict[str, Any]:
        if not self._path.exists():
            return {}
        try:
            if self._path.stat().st_size > 2_097_152:
                raise NutritionStorageUnavailable()
            def unique(pairs):
                result = {}
                for key, value in pairs:
                    if key in result:
                        raise NutritionStorageUnavailable()
                    result[key] = value
                return result
            with open(self._path, encoding="utf-8") as fh:
                datos = json.load(fh, object_pairs_hook=unique)
            if type(datos) is not dict:
                raise NutritionStorageUnavailable()
            return datos
        except (ValueError, TypeError, OSError, RecursionError):
            raise NutritionStorageUnavailable() from None

    def cargar(self) -> dict[str, Any]:
        """Missing files remain legacy unknown; unreadable existing facts fail closed."""
        datos = self._read_disk()
        if "_nutrition35" in datos:
            if "restricciones_nutricionales" in datos or "alimentos_excluidos" in datos:
                raise NutritionStorageUnavailable()
            restrictions = decode_restrictions(datos.pop("_nutrition35"), self._crypto_service)
        else:
            restrictions = restrictions_from_row(datos)
        datos["restricciones_nutricionales"] = restrictions.declaration_payload()
        datos["alimentos_excluidos"] = list(restrictions.excluded_foods)
        return datos

    def guardar(self, datos: dict[str, Any]) -> bool:
        """Escribe el dict de preferencias a disco. Retorna True en éxito."""
        if not isinstance(datos, dict):
            raise TypeError("datos debe ser un dict.")
        tmp = None
        try:
            old = self._read_disk()
            current = self.cargar()
            merged = dict(old)
            merged.update({key: value for key, value in datos.items()
                           if key not in {"_nutrition35", "nutrition_restrictions",
                                          "restricciones_nutricionales", "alimentos_excluidos"}})
            declaration = datos.get("restricciones_nutricionales")
            excluded = datos.get("alimentos_excluidos")
            if declaration is not None or excluded is not None:
                facts = restrictions_from_row({
                    "restricciones_nutricionales": declaration if declaration is not None
                    else current["restricciones_nutricionales"],
                    "alimentos_excluidos": excluded if excluded is not None else current["alimentos_excluidos"],
                })
                merged["_nutrition35"] = encode_restrictions(
                    facts, secure=self._secure_mode or storage_mode(old.get("_nutrition35")) == "cipher",
                    crypto=self._crypto_service,
                )
                merged.pop("restricciones_nutricionales", None)
                merged.pop("alimentos_excluidos", None)
            _BASE_DIR.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self._path.parent,
                                             prefix=self._path.stem + "-", suffix=".tmp", delete=False) as fh:
                tmp = Path(fh.name)
                json.dump(merged, fh, ensure_ascii=False, indent=2)
                fh.flush()
                os.fsync(fh.fileno())
            tmp.replace(self._path)
            return True
        except (OSError, ValueError):
            logger.error("[PREFS] No se pudo confirmar el guardado de preferencias.")
            return False
        finally:
            if tmp is not None and tmp.exists():
                tmp.unlink()

    def actualizar(self, clave: str, valor: Any) -> bool:
        """Carga, establece clave=valor y persiste."""
        datos = self.cargar()
        datos[clave] = valor
        return self.guardar(datos)

    def obtener(self, clave: str, default: Any = None) -> Any:
        """Lee un valor específico sin cargar todo el dict en memoria."""
        return self.cargar().get(clave, default)
