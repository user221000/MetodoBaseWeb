"""
Gestor de base de datos SQLite para clientes y planes.

⚠️ DEPRECATION WARNING ⚠️
========================
Este módulo está DEPRECADO desde 2026-03-24.
La nueva arquitectura usa SQLAlchemy via web/database/.

MIGRAR A:
- Para operaciones CRUD: src/repositories/cliente_repository.py
- Para modelos: web/database/models.py
- Para sesiones: web/database/engine.py

Este módulo se mantiene SOLO para:
1. Compatibilidad con UI desktop (ui_desktop/) durante transición
2. Rollback de emergencia si falla SQLAlchemy

NO AGREGAR NUEVA FUNCIONALIDAD AQUÍ.
TODO el código nuevo debe usar ClienteRepository o web/database/.

Para la capa de compatibilidad, ver: src/compat/gestor_bd_compat.py
========================

Gestiona (LEGACY):
- Registro de clientes con todos sus datos
- Historial de planes generados
- Búsqueda rápida de clientes
- Estadísticas del gym
- Backup automático

Base de datos: registros/clientes.db
Backups: registros/backups/clientes_YYYYMMDD_HHMMSS.db
"""

import hashlib
import re
import shutil
import sqlite3
import warnings
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from config.constantes import CARPETA_REGISTROS
from core.nutrition_restrictions import NutritionRestrictions
from core.services.nutrition_storage import (
    NutritionStorageUnavailable,
    decode_restrictions,
    encode_restrictions,
    storage_mode,
)
from utils.logger import logger
from utils.telemetria import registrar_evento

# Emitir warning de deprecación al importar
warnings.warn(
    "src.gestor_bd está deprecado. Usar src.repositories.cliente_repository o web.database.",
    DeprecationWarning,
    stacklevel=2
)

# ── sqlite3 datetime adapters (required since Python 3.12) ───────────────────
sqlite3.register_adapter(datetime, lambda dt: dt.isoformat())
sqlite3.register_converter("timestamp", lambda b: datetime.fromisoformat(b.decode()))



class GestorBDClientes:
    """
    Gestiona almacenamiento persistente de clientes y planes.

    Tablas:
    - clientes: datos personales y antropométricos
    - planes_generados: historial de planes con PDFs
    - estadisticas_gym: métricas agregadas por mes
    """

    def __init__(self, db_path: str = None, secure_mode: bool = False, crypto_service: Any = None):
        if db_path is None:
            db_path = str(Path(CARPETA_REGISTROS) / "clientes.db")
        self.db_path = Path(db_path)
        self.backup_dir = self.db_path.parent / "backups"
        self._secure_mode = secure_mode
        self._crypto_service = crypto_service

        # Crear directorios si no existen
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)

        # Crear tablas si no existen
        self._crear_tablas()

        # Backup automático cada 7 días
        self._verificar_backup_automatico()

        logger.info("[BD] Gestor inicializado: %s", self.db_path)

    def _conn(self) -> sqlite3.Connection:
        """Abre una conexión con WAL mode y foreign keys habilitados."""
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.row_factory = sqlite3.Row
        return conn

    _TABLAS_VALIDAS = frozenset({"clientes", "planes_generados", "estadisticas_gym"})

    def _crear_tablas(self) -> None:
        """Crea las tablas de la base de datos si no existen."""
        conn = self._conn()
        c = conn.cursor()

        c.execute('''
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                id_cliente TEXT UNIQUE NOT NULL,
                nombre TEXT NOT NULL,
                telefono TEXT,
                email TEXT,
                edad INTEGER,
                sexo TEXT CHECK(sexo IN ('M', 'F', 'Otro', NULL)),
                peso_kg REAL,
                estatura_cm REAL,
                grasa_corporal_pct REAL,
                masa_magra_kg REAL,
                nivel_actividad TEXT,
                objetivo TEXT,
                fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                ultimo_plan TIMESTAMP,
                total_planes_generados INTEGER DEFAULT 0,
                activo BOOLEAN DEFAULT 1,
                notas TEXT
            )
        ''')

        c.execute('CREATE INDEX IF NOT EXISTS idx_nombre ON clientes(nombre)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_telefono ON clientes(telefono)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_activo ON clientes(activo)')

        c.execute('''
            CREATE TABLE IF NOT EXISTS planes_generados (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                id_cliente TEXT NOT NULL,
                fecha_generacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                tmb REAL,
                get_total REAL,
                kcal_objetivo REAL,
                kcal_real REAL,
                proteina_g REAL,
                carbs_g REAL,
                grasa_g REAL,
                objetivo TEXT,
                nivel_actividad TEXT,
                ruta_pdf TEXT,
                peso_en_momento REAL,
                grasa_en_momento REAL,
                desviacion_maxima_pct REAL,
                FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
            )
        ''')

        c.execute('CREATE INDEX IF NOT EXISTS idx_cliente_planes ON planes_generados(id_cliente)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_fecha_planes ON planes_generados(fecha_generacion)')

        c.execute('''
            CREATE TABLE IF NOT EXISTS estadisticas_gym (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mes INTEGER NOT NULL,
                anio INTEGER NOT NULL,
                total_clientes_nuevos INTEGER DEFAULT 0,
                total_planes_generados INTEGER DEFAULT 0,
                promedio_kcal REAL,
                objetivo_deficit_count INTEGER DEFAULT 0,
                objetivo_superavit_count INTEGER DEFAULT 0,
                objetivo_mantenimiento_count INTEGER DEFAULT 0,
                fecha_calculo TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(mes, anio)
            )
        ''')

        self._asegurar_columna(
            c, "clientes", "plantilla_tipo TEXT DEFAULT 'general'"
        )
        self._asegurar_columna(
            c, "planes_generados", "plantilla_tipo TEXT DEFAULT 'general'"
        )
        self._asegurar_columna(
            c, "planes_generados", "tipo_plan TEXT DEFAULT 'menu_fijo'"
        )

        # Campos cifrados (PII) + indices hash para busqueda exacta
        self._asegurar_columna(c, "clientes", "nombre_enc TEXT")
        self._asegurar_columna(c, "clientes", "telefono_enc TEXT")
        self._asegurar_columna(c, "clientes", "email_enc TEXT")
        self._asegurar_columna(c, "clientes", "notas_enc TEXT")
        self._asegurar_columna(c, "clientes", "nombre_idx TEXT")
        self._asegurar_columna(c, "clientes", "telefono_idx TEXT")
        self._asegurar_columna(c, "clientes", "email_idx TEXT")
        self._asegurar_columna(c, "clientes", "datos_cifrados BOOLEAN DEFAULT 0")
        self._asegurar_columna(c, "clientes", "nutrition_restrictions_storage TEXT")

        conn.commit()
        conn.close()
        logger.info("[BD] Tablas creadas/verificadas exitosamente")

    def _obtener_columnas_tabla(self, cursor, tabla: str) -> set[str]:
        if tabla not in self._TABLAS_VALIDAS:
            raise ValueError(f"Tabla no permitida: {tabla}")
        cursor.execute(f"PRAGMA table_info({tabla})")
        return {row[1] for row in cursor.fetchall()}

    def _asegurar_columna(self, cursor, tabla: str, definicion_columna: str) -> None:
        if tabla not in self._TABLAS_VALIDAS:
            raise ValueError(f"Tabla no permitida: {tabla}")
        nombre_columna = definicion_columna.split()[0].strip()
        columnas = self._obtener_columnas_tabla(cursor, tabla)
        if nombre_columna in columnas:
            return
        cursor.execute(f"ALTER TABLE {tabla} ADD COLUMN {definicion_columna}")
        logger.info("[BD] Migracion aplicada: %s.%s", tabla, nombre_columna)

    @staticmethod
    def _normalizar_tipo_plan(tipo_plan: str | None) -> str:
        valor = str(tipo_plan or "").strip().lower()
        if valor in {"con_opciones", "opciones", "con opciones"}:
            return "con_opciones"
        return "menu_fijo"

    @staticmethod
    def _normalizar_idx(valor: str | None) -> str:
        if not valor:
            return ""
        limpio = re.sub(r"[^a-z0-9]", "", valor.strip().lower())
        return limpio

    @staticmethod
    def _hash_idx(valor: str | None) -> str:
        norm = GestorBDClientes._normalizar_idx(valor)
        if not norm:
            return ""
        return hashlib.sha256(norm.encode("utf-8")).hexdigest()

    @staticmethod
    def _placeholder_nombre(id_cliente: str) -> str:
        return f"ENC-{str(id_cliente)[:8]}"

    def _usar_seguridad(self, secure_mode: bool | None, crypto_service: Any | None) -> tuple[bool, Any | None]:
        modo = self._secure_mode if secure_mode is None else secure_mode
        crypto = self._crypto_service if crypto_service is None else crypto_service
        return modo and crypto is not None, crypto

    def _cifrar_campos(self, cliente, crypto) -> dict:
        return {
            "nombre_enc": crypto.encrypt(getattr(cliente, "nombre", "")),
            "telefono_enc": crypto.encrypt(getattr(cliente, "telefono", "")),
            "email_enc": crypto.encrypt(getattr(cliente, "email", "")),
            "notas_enc": crypto.encrypt(getattr(cliente, "notas", "")),
            "nombre_idx": self._hash_idx(getattr(cliente, "nombre", "")),
            "telefono_idx": self._hash_idx(getattr(cliente, "telefono", "")),
            "email_idx": self._hash_idx(getattr(cliente, "email", "")),
        }

    def _descifrar_campos(self, row: dict, crypto) -> dict:
        if not row:
            return row
        try:
            if row.get("nombre_enc"):
                row["nombre"] = crypto.decrypt(row.get("nombre_enc"))
            if row.get("telefono_enc"):
                row["telefono"] = crypto.decrypt(row.get("telefono_enc"))
            if row.get("email_enc"):
                row["email"] = crypto.decrypt(row.get("email_enc"))
            if row.get("notas_enc"):
                row["notas"] = crypto.decrypt(row.get("notas_enc"))
        except Exception as exc:
            logger.warning("[BD] Error descifrando campos: %s", exc)
        for key in ("nombre_enc", "telefono_enc", "email_enc", "notas_enc"):
            row.pop(key, None)
        return row

    def registrar_cliente(self, cliente, secure_mode: bool | None = None, crypto_service: Any | None = None) -> bool:
        """Registra o actualiza un cliente en la base de datos."""
        return self._guardar_cliente(cliente, secure_mode, crypto_service)

    def actualizar_cliente(self, cliente, secure_mode: bool | None = None, crypto_service: Any | None = None) -> bool:
        """Edit the existing profile without counting a generated plan."""
        return self._guardar_cliente(cliente, secure_mode, crypto_service, solo_perfil=True)

    def registrar_cliente_para_plan(self, cliente) -> bool:
        """Persist generation data only if its captured nutrition facts still match."""
        return self._guardar_cliente(cliente, None, None, para_plan=True)

    def _guardar_cliente(self, cliente, secure_mode, crypto_service, *, solo_perfil=False, para_plan=False) -> bool:
        usar_seguridad, crypto = self._usar_seguridad(secure_mode, crypto_service)
        secure_requested = self._secure_mode if secure_mode is None else secure_mode
        conn = self._conn()
        c = conn.cursor()
        plantilla_tipo = getattr(cliente, 'plantilla_tipo', 'general') or 'general'

        try:
            conn.execute("BEGIN IMMEDIATE")
            c.execute(
                'SELECT id, total_planes_generados, nutrition_restrictions_storage FROM clientes WHERE id_cliente = ?',
                (cliente.id_cliente,),
            )
            resultado = c.fetchone()
            if solo_perfil and not resultado:
                return False
            previous = resultado["nutrition_restrictions_storage"] if resultado else None
            restrictions = getattr(cliente, "nutrition_restrictions", None)
            if para_plan:
                self._require_generation_snapshot(cliente, previous, crypto)
            # None/omission is a partial update, never an instruction to erase.
            storage = previous
            if restrictions is not None and not (para_plan and resultado):
                storage = encode_restrictions(
                    restrictions, secure=bool(secure_requested or storage_mode(previous) == "cipher"), crypto=crypto,
                )

            if resultado:
                campos_seg = {}
                if usar_seguridad:
                    campos_seg = self._cifrar_campos(cliente, crypto)
                c.execute('''
                    UPDATE clientes SET
                        nombre = ?,
                        telefono = ?,
                        email = ?,
                        edad = ?,
                        sexo = ?,
                        peso_kg = ?,
                        estatura_cm = ?,
                        grasa_corporal_pct = ?,
                        nivel_actividad = ?,
                        objetivo = ?,
                        notas = ?,
                        plantilla_tipo = ?,
                        nombre_enc = ?,
                        telefono_enc = ?,
                        email_enc = ?,
                        notas_enc = ?,
                        nombre_idx = ?,
                        telefono_idx = ?,
                        email_idx = ?,
                        datos_cifrados = ?,
                        ultimo_plan = CASE WHEN ? THEN ? ELSE ultimo_plan END,
                        total_planes_generados = total_planes_generados + ?
                    WHERE id_cliente = ?
                ''', (
                    self._placeholder_nombre(cliente.id_cliente) if usar_seguridad else cliente.nombre,
                    None if usar_seguridad else getattr(cliente, 'telefono', None),
                    None if usar_seguridad else getattr(cliente, 'email', None),
                    cliente.edad,
                    getattr(cliente, 'sexo', None),
                    cliente.peso_kg,
                    cliente.estatura_cm,
                    cliente.grasa_corporal_pct,
                    cliente.nivel_actividad,
                    cliente.objetivo,
                    None if usar_seguridad else getattr(cliente, 'notas', None),
                    plantilla_tipo,
                    campos_seg.get("nombre_enc"),
                    campos_seg.get("telefono_enc"),
                    campos_seg.get("email_enc"),
                    campos_seg.get("notas_enc"),
                    campos_seg.get("nombre_idx"),
                    campos_seg.get("telefono_idx"),
                    campos_seg.get("email_idx"),
                    1 if usar_seguridad else 0,
                    not solo_perfil,
                    datetime.now(),
                    0 if solo_perfil else 1,
                    cliente.id_cliente,
                ))
                logger.info("[BD] Cliente actualizado: %s", cliente.id_cliente)
            else:
                campos_seg = {}
                if usar_seguridad:
                    campos_seg = self._cifrar_campos(cliente, crypto)
                c.execute('''
                    INSERT INTO clientes
                    (id_cliente, nombre, telefono, email, edad, sexo, peso_kg, estatura_cm,
                     grasa_corporal_pct, nivel_actividad, objetivo, notas, plantilla_tipo,
                     ultimo_plan, total_planes_generados,
                     nombre_enc, telefono_enc, email_enc, notas_enc,
                     nombre_idx, telefono_idx, email_idx, datos_cifrados)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    cliente.id_cliente,
                    self._placeholder_nombre(cliente.id_cliente) if usar_seguridad else cliente.nombre,
                    None if usar_seguridad else getattr(cliente, 'telefono', None),
                    None if usar_seguridad else getattr(cliente, 'email', None),
                    cliente.edad,
                    getattr(cliente, 'sexo', None),
                    cliente.peso_kg,
                    cliente.estatura_cm,
                    cliente.grasa_corporal_pct,
                    cliente.nivel_actividad,
                    cliente.objetivo,
                    None if usar_seguridad else getattr(cliente, 'notas', None),
                    plantilla_tipo,
                    datetime.now(),
                    1,
                    campos_seg.get("nombre_enc"),
                    campos_seg.get("telefono_enc"),
                    campos_seg.get("email_enc"),
                    campos_seg.get("notas_enc"),
                    campos_seg.get("nombre_idx"),
                    campos_seg.get("telefono_idx"),
                    campos_seg.get("email_idx"),
                    1 if usar_seguridad else 0,
                ))
                logger.info("[BD] Cliente nuevo registrado: %s", cliente.id_cliente)

            if storage != previous:
                c.execute("UPDATE clientes SET nutrition_restrictions_storage = ? WHERE id_cliente = ?",
                          (storage, cliente.id_cliente))
            conn.commit()
            return True

        except Exception as e:
            logger.error("[BD] Error registrando cliente: %s", e, exc_info=True)
            conn.rollback()
            return False

        finally:
            conn.close()

    def _hydrate_nutrition(self, data: dict, crypto) -> dict:
        restrictions = decode_restrictions(data.get("nutrition_restrictions_storage"), crypto)
        data.pop("nutrition_restrictions_storage", None)
        data["nutrition_restrictions"] = restrictions
        data["restricciones_nutricionales"] = restrictions.declaration_payload()
        data["alimentos_excluidos"] = list(restrictions.excluded_foods)
        return data

    @staticmethod
    def _require_generation_snapshot(cliente, storage, crypto) -> None:
        current = decode_restrictions(storage, crypto)
        captured = getattr(cliente, "nutrition_restrictions", None)
        if captured is None:
            # Old callers remain compatible only while persisted facts are unknown.
            NutritionRestrictions.from_declaration(None, ()).require_current(current)
        else:
            captured.require_current(current)

    def attach_nutrition_restrictions(self, cliente):
        """Hydrate partial UI objects before any generation work; reject stale facts."""
        conn = self._conn()
        try:
            row = conn.execute("SELECT nutrition_restrictions_storage FROM clientes WHERE id_cliente = ?",
                               (cliente.id_cliente,)).fetchone()
            if row:
                current = decode_restrictions(row[0], self._crypto_service)
                captured = getattr(cliente, "nutrition_restrictions", None)
                if captured is not None:
                    captured.require_current(current)
                cliente.nutrition_restrictions = current
            elif getattr(cliente, "nutrition_restrictions", None) is None:
                cliente.nutrition_restrictions = decode_restrictions(None)
            cliente.nutrition_restrictions.require_automated_generation()
            return cliente
        finally:
            conn.close()

    def registrar_plan_generado(
        self, cliente, plan: Dict, ruta_pdf: str, tipo_plan: str | None = None
    ) -> bool:
        """Registra un plan generado en el historial."""
        conn = self._conn()
        c = conn.cursor()
        plantilla_tipo = getattr(cliente, 'plantilla_tipo', 'general') or 'general'
        tipo_plan_normalizado = self._normalizar_tipo_plan(tipo_plan)

        if tipo_plan is None:
            metadata_tipo = str(plan.get("metadata", {}).get("tipo_plan", "")).strip().lower()
            if metadata_tipo in {"opciones", "con_opciones"}:
                tipo_plan_normalizado = "con_opciones"
            elif "_OPCIONES_" in str(ruta_pdf or "").upper():
                tipo_plan_normalizado = "con_opciones"

        try:
            conn.execute("BEGIN IMMEDIATE")
            row = c.execute("SELECT nutrition_restrictions_storage FROM clientes WHERE id_cliente = ?",
                            (cliente.id_cliente,)).fetchone()
            if row is None:
                raise NutritionStorageUnavailable()
            self._require_generation_snapshot(cliente, row[0], self._crypto_service)
            comidas = ['desayuno', 'almuerzo', 'comida', 'cena']
            kcal_real = sum(
                plan.get(m, {}).get('kcal_real', 0) for m in comidas
            )
            desv_max = max(
                (plan.get(m, {}).get('desviacion_pct', 0) for m in comidas if m in plan),
                default=0,
            )

            c.execute('''
                INSERT INTO planes_generados
                (id_cliente, tmb, get_total, kcal_objetivo, kcal_real,
                 proteina_g, carbs_g, grasa_g, objetivo, nivel_actividad,
                 ruta_pdf, peso_en_momento, grasa_en_momento, desviacion_maxima_pct,
                 plantilla_tipo, tipo_plan)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                cliente.id_cliente,
                getattr(cliente, 'tmb', 0),
                getattr(cliente, 'get_total', 0),
                getattr(cliente, 'kcal_objetivo', 0),
                kcal_real,
                getattr(cliente, 'proteina_g', 0),
                getattr(cliente, 'carbs_g', 0),
                getattr(cliente, 'grasa_g', 0),
                cliente.objetivo,
                cliente.nivel_actividad,
                ruta_pdf,
                cliente.peso_kg,
                cliente.grasa_corporal_pct,
                desv_max,
                plantilla_tipo,
                tipo_plan_normalizado,
            ))

            conn.commit()
            logger.info("[BD] Plan registrado para cliente: %s", cliente.id_cliente)
            registrar_evento("planes", "plan_generado", {
                "objetivo": cliente.objetivo,
                "tipo_plan": tipo_plan_normalizado,
                "plantilla": plantilla_tipo,
                "kcal_objetivo": getattr(cliente, 'kcal_objetivo', 0),
            })
            return True

        except Exception as e:
            logger.error("[BD] Error registrando plan: %s", e, exc_info=True)
            registrar_evento("planes", "plan_error", {"error": str(e)})
            conn.rollback()
            return False

        finally:
            conn.close()

    def buscar_clientes(self, termino: str,
                        solo_activos: bool = True,
                        limite: int = 50,
                        secure_mode: bool | None = None,
                        crypto_service: Any | None = None) -> List[Dict]:
        """Busca clientes por nombre, teléfono o ID."""
        usar_seguridad, crypto = self._usar_seguridad(secure_mode, crypto_service)
        conn = self._conn()
        c = conn.cursor()

        try:
            if usar_seguridad:
                query = '''
                    SELECT
                        id_cliente, nombre, telefono, email, edad,
                        peso_kg, grasa_corporal_pct, objetivo, nivel_actividad,
                        plantilla_tipo, fecha_registro, ultimo_plan,
                        total_planes_generados, activo,
                        nombre_enc, telefono_enc, email_enc, notas_enc
                    FROM clientes
                    WHERE (
                        nombre_idx = ? OR
                        telefono_idx = ? OR
                        email_idx = ? OR
                        id_cliente = ?
                    )
                '''
                idx = self._hash_idx(termino)
                params = [idx, idx, idx, termino]
            else:
                query = '''
                    SELECT
                        id_cliente, nombre, telefono, email, edad,
                        peso_kg, grasa_corporal_pct, objetivo, nivel_actividad,
                        plantilla_tipo, fecha_registro, ultimo_plan,
                        total_planes_generados, activo
                    FROM clientes
                    WHERE (
                        nombre LIKE ? OR
                        telefono LIKE ? OR
                        id_cliente LIKE ?
                    )
                '''
                params = [f'%{termino}%', f'%{termino}%', f'%{termino}%']

            if solo_activos:
                query += ' AND activo = 1'

            query += ' ORDER BY ultimo_plan DESC, nombre ASC LIMIT ?'
            params.append(limite)

            c.execute(query, params)

            resultados = []
            for row in c.fetchall():
                item = {
                    'id_cliente': row['id_cliente'],
                    'nombre': row['nombre'],
                    'telefono': row['telefono'],
                    'email': row['email'],
                    'edad': row['edad'],
                    'peso_kg': row['peso_kg'],
                    'grasa_corporal_pct': row['grasa_corporal_pct'],
                    'objetivo': row['objetivo'],
                    'nivel_actividad': row['nivel_actividad'],
                    'plantilla_tipo': row['plantilla_tipo'],
                    'fecha_registro': row['fecha_registro'],
                    'ultimo_plan': row['ultimo_plan'],
                    'total_planes_generados': row['total_planes_generados'],
                    'total_planes': row['total_planes_generados'],
                    'activo': bool(row['activo']),
                }
                if usar_seguridad:
                    item = self._descifrar_campos(item | {
                        "nombre_enc": row["nombre_enc"],
                        "telefono_enc": row["telefono_enc"],
                        "email_enc": row["email_enc"],
                        "notas_enc": row["notas_enc"],
                    }, crypto)
                resultados.append(item)

            logger.info("[BD] Búsqueda '%s': %s resultados", termino, len(resultados))
            return resultados

        except Exception as e:
            logger.error("[BD] Error en búsqueda: %s", e, exc_info=True)
            return []

        finally:
            conn.close()

    def obtener_cliente_por_id(self, id_cliente: str,
                               secure_mode: bool | None = None,
                               crypto_service: Any | None = None) -> Optional[Dict]:
        """Obtiene todos los datos de un cliente por su ID."""
        usar_seguridad, crypto = self._usar_seguridad(secure_mode, crypto_service)
        conn = self._conn()
        c = conn.cursor()

        try:
            c.execute('SELECT * FROM clientes WHERE id_cliente = ?', (id_cliente,))
            row = c.fetchone()
            data = dict(row) if row else None
            if data and usar_seguridad:
                data = self._descifrar_campos(data, crypto)
            if data:
                data = self._hydrate_nutrition(data, crypto)
            return data

        except NutritionStorageUnavailable:
            raise
        except Exception as e:
            logger.error("[BD] Error obteniendo cliente: %s", e, exc_info=True)
            return None

        finally:
            conn.close()

    def obtener_historial_planes(self, id_cliente: str,
                                 limite: int = 20) -> List[Dict]:
        """Obtiene el historial de planes generados para un cliente."""
        conn = self._conn()
        c = conn.cursor()

        try:
            c.execute('''
                SELECT
                    fecha_generacion, kcal_objetivo, kcal_real,
                    proteina_g, carbs_g, grasa_g, objetivo,
                    ruta_pdf, peso_en_momento, grasa_en_momento,
                    desviacion_maxima_pct, plantilla_tipo, tipo_plan
                FROM planes_generados
                WHERE id_cliente = ?
                ORDER BY fecha_generacion DESC
                LIMIT ?
            ''', (id_cliente, limite))

            return [dict(row) for row in c.fetchall()]

        except Exception as e:
            logger.error("[BD] Error obteniendo historial: %s", e, exc_info=True)
            return []

        finally:
            conn.close()

    def obtener_progreso_cliente(self, id_cliente: str) -> Dict:
        """Calcula progreso de peso y grasa a partir del historial de planes."""
        conn = self._conn()
        c = conn.cursor()

        try:
            c.execute('''
                SELECT fecha_generacion, peso_en_momento, grasa_en_momento
                FROM planes_generados
                WHERE id_cliente = ?
                ORDER BY fecha_generacion ASC
            ''', (id_cliente,))
            registros = [dict(row) for row in c.fetchall()]

            if not registros:
                return {
                    'planes_registrados': 0,
                    'peso_inicial': None,
                    'peso_actual': None,
                    'delta_peso': None,
                    'grasa_inicial': None,
                    'grasa_actual': None,
                    'delta_grasa': None,
                    'fecha_inicio': None,
                    'fecha_fin': None,
                }

            peso_inicial = None
            peso_actual = None
            grasa_inicial = None
            grasa_actual = None

            for item in registros:
                peso = item.get('peso_en_momento')
                grasa = item.get('grasa_en_momento')

                if peso is not None:
                    if peso_inicial is None:
                        peso_inicial = float(peso)
                    peso_actual = float(peso)
                if grasa is not None:
                    if grasa_inicial is None:
                        grasa_inicial = float(grasa)
                    grasa_actual = float(grasa)

            delta_peso = (
                round(peso_actual - peso_inicial, 2)
                if peso_inicial is not None and peso_actual is not None
                else None
            )
            delta_grasa = (
                round(grasa_actual - grasa_inicial, 2)
                if grasa_inicial is not None and grasa_actual is not None
                else None
            )

            return {
                'planes_registrados': len(registros),
                'peso_inicial': peso_inicial,
                'peso_actual': peso_actual,
                'delta_peso': delta_peso,
                'grasa_inicial': grasa_inicial,
                'grasa_actual': grasa_actual,
                'delta_grasa': delta_grasa,
                'fecha_inicio': registros[0].get('fecha_generacion'),
                'fecha_fin': registros[-1].get('fecha_generacion'),
            }

        except Exception as e:
            logger.error("[BD] Error obteniendo progreso cliente: %s", e, exc_info=True)
            return {
                'planes_registrados': 0,
                'peso_inicial': None,
                'peso_actual': None,
                'delta_peso': None,
                'grasa_inicial': None,
                'grasa_actual': None,
                'delta_grasa': None,
                'fecha_inicio': None,
                'fecha_fin': None,
            }
        finally:
            conn.close()

    def obtener_estadisticas_gym(self,
                                 fecha_inicio: Optional[datetime] = None,
                                 fecha_fin: Optional[datetime] = None) -> Dict:
        """Obtiene estadísticas generales del gimnasio."""
        conn = self._conn()
        c = conn.cursor()

        try:
            if not fecha_inicio:
                fecha_inicio = datetime.now() - timedelta(days=30)
            if not fecha_fin:
                fecha_fin = datetime.now()

            c.execute('SELECT COUNT(*) FROM clientes WHERE activo = 1')
            total_clientes = c.fetchone()[0]

            c.execute('''
                SELECT COUNT(*) FROM clientes
                WHERE fecha_registro BETWEEN ? AND ?
            ''', (fecha_inicio, fecha_fin))
            clientes_nuevos = c.fetchone()[0]

            c.execute('''
                SELECT COUNT(*) FROM planes_generados
                WHERE fecha_generacion BETWEEN ? AND ?
            ''', (fecha_inicio, fecha_fin))
            planes_periodo = c.fetchone()[0]

            c.execute('''
                SELECT AVG(kcal_objetivo) FROM planes_generados
                WHERE fecha_generacion BETWEEN ? AND ?
            ''', (fecha_inicio, fecha_fin))
            promedio_kcal = c.fetchone()[0] or 0

            c.execute('''
                SELECT objetivo, COUNT(*) as count
                FROM planes_generados
                WHERE fecha_generacion BETWEEN ? AND ?
                GROUP BY objetivo
            ''', (fecha_inicio, fecha_fin))
            objetivos = {row[0]: row[1] for row in c.fetchall()}

            c.execute('''
                SELECT c.nombre, c.telefono, c.objetivo, c.ultimo_plan,
                       (SELECT pg.kcal_objetivo FROM planes_generados pg
                        WHERE pg.id_cliente = c.id_cliente
                        ORDER BY pg.fecha_generacion DESC LIMIT 1) as kcal_objetivo
                FROM clientes c
                WHERE c.activo = 1
                ORDER BY c.ultimo_plan DESC NULLS LAST
                LIMIT 10
            ''')
            top_clientes = [
                {
                    'nombre': row[0],
                    'telefono': row[1],
                    'objetivo': row[2],
                    'ultima_actualizacion': row[3],
                    'kcal_objetivo': row[4],
                }
                for row in c.fetchall()
            ]

            # --- KPIs de negocio adicionales ---

            # Clientes activos: con plan generado en el período
            c.execute('''
                SELECT COUNT(DISTINCT id_cliente) FROM planes_generados
                WHERE fecha_generacion BETWEEN ? AND ?
            ''', (fecha_inicio, fecha_fin))
            clientes_activos = c.fetchone()[0]

            # Renovaciones: clientes con más de 1 plan en el período
            c.execute('''
                SELECT COUNT(*) FROM (
                    SELECT id_cliente, COUNT(*) as cnt
                    FROM planes_generados
                    WHERE fecha_generacion BETWEEN ? AND ?
                    GROUP BY id_cliente
                    HAVING cnt > 1
                )
            ''', (fecha_inicio, fecha_fin))
            renovaciones = c.fetchone()[0]

            # Tasa de retención: clientes activos / total clientes (%)
            tasa_retencion = (
                round(clientes_activos / total_clientes * 100, 1)
                if total_clientes > 0 else 0.0
            )

            # Planes por tipo (menú fijo vs opciones)
            c.execute('''
                SELECT tipo_plan, COUNT(*) FROM planes_generados
                WHERE fecha_generacion BETWEEN ? AND ?
                GROUP BY tipo_plan
            ''', (fecha_inicio, fecha_fin))
            planes_por_tipo = {row[0] or "menu_fijo": row[1] for row in c.fetchall()}

            # Clientes activos sin plan generado nunca
            c.execute('''
                SELECT COUNT(*) FROM clientes
                WHERE activo = 1 AND ultimo_plan IS NULL
            ''')
            sin_plan = c.fetchone()[0]

            # Planes por día (últimos 7 días) para gráfica de evolución
            DIAS = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]
            planes_por_dia = []
            planes_labels = []
            ahora = fecha_fin or datetime.now()
            for i in range(6, -1, -1):
                dia = ahora - timedelta(days=i)
                inicio_dia = dia.replace(hour=0, minute=0, second=0, microsecond=0)
                fin_dia = dia.replace(hour=23, minute=59, second=59, microsecond=999999)
                c.execute(
                    "SELECT COUNT(*) FROM planes_generados "
                    "WHERE fecha_generacion BETWEEN ? AND ?",
                    (inicio_dia.isoformat(), fin_dia.isoformat()),
                )
                planes_por_dia.append(c.fetchone()[0])
                planes_labels.append(DIAS[dia.weekday()])

            return {
                'total_clientes': total_clientes,
                'clientes_nuevos': clientes_nuevos,
                'clientes_activos': clientes_activos,
                'planes_periodo': planes_periodo,
                'promedio_kcal': round(promedio_kcal, 1),
                'objetivos': objetivos,
                'top_clientes': top_clientes,
                'renovaciones': renovaciones,
                'tasa_retencion': tasa_retencion,
                'planes_por_tipo': planes_por_tipo,
                'sin_plan': sin_plan,
                'planes_por_dia': planes_por_dia,
                'planes_labels': planes_labels,
                'fecha_inicio': fecha_inicio.isoformat(),
                'fecha_fin': fecha_fin.isoformat(),
            }

        except Exception as e:
            logger.error("[BD] Error obteniendo estadísticas: %s", e, exc_info=True)
            return {}

        finally:
            conn.close()

    def desactivar_cliente(self, id_cliente: str) -> bool:
        """Marca un cliente como inactivo (no lo elimina)."""
        conn = self._conn()
        c = conn.cursor()

        try:
            c.execute('UPDATE clientes SET activo = 0 WHERE id_cliente = ?',
                      (id_cliente,))
            conn.commit()
            logger.info("[BD] Cliente desactivado: %s", id_cliente)
            return True

        except Exception as e:
            logger.error("[BD] Error desactivando cliente: %s", e, exc_info=True)
            return False

        finally:
            conn.close()

    def reactivar_cliente(self, id_cliente: str) -> bool:
        """Reactiva un cliente previamente desactivado."""
        conn = self._conn()
        c = conn.cursor()

        try:
            c.execute('UPDATE clientes SET activo = 1 WHERE id_cliente = ?',
                      (id_cliente,))
            conn.commit()
            logger.info("[BD] Cliente reactivado: %s", id_cliente)
            return True

        except Exception as e:
            logger.error("[BD] Error reactivando cliente: %s", e, exc_info=True)
            return False

        finally:
            conn.close()

    def crear_backup(self) -> Optional[str]:
        """Crea un backup de la base de datos."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            nombre_backup = f"clientes_{timestamp}.db"
            ruta_backup = self.backup_dir / nombre_backup
            shutil.copy2(self.db_path, ruta_backup)
            logger.info("[BD] Backup creado: %s", ruta_backup)
            return str(ruta_backup)

        except Exception as e:
            logger.error("[BD] Error creando backup: %s", e, exc_info=True)
            return None

    def _verificar_backup_automatico(self) -> None:
        """Verifica si es necesario crear un backup automático (cada 7 días)."""
        try:
            backups = sorted(self.backup_dir.glob("clientes_*.db"), reverse=True)

            if not backups:
                self.crear_backup()
                return

            ultimo_backup = backups[0]
            fecha_backup = datetime.fromtimestamp(ultimo_backup.stat().st_mtime)

            if (datetime.now() - fecha_backup).days >= 7:
                logger.info("[BD] Backup automático (>7 días desde último)")
                self.crear_backup()

        except Exception as e:
            logger.error("[BD] Error en backup automático: %s", e, exc_info=True)

    def limpiar_backups_antiguos(self, dias_antiguedad: int = 90) -> int:
        """Elimina backups más antiguos que N días."""
        try:
            fecha_limite = datetime.now() - timedelta(days=dias_antiguedad)
            backups_eliminados = 0

            for backup in self.backup_dir.glob("clientes_*.db"):
                fecha_backup = datetime.fromtimestamp(backup.stat().st_mtime)
                if fecha_backup < fecha_limite:
                    backup.unlink()
                    backups_eliminados += 1

            if backups_eliminados > 0:
                logger.info("[BD] Eliminados %s backups antiguos", backups_eliminados)

            return backups_eliminados

        except Exception as e:
            logger.error("[BD] Error limpiando backups: %s", e, exc_info=True)
            return 0

    def migrar_datos_sensibles(self, crypto_service: Any) -> int:
        """Migra datos planos a cifrados en clientes.

        Retorna cantidad de filas migradas.
        """
        conn = self._conn()
        c = conn.cursor()
        migrados = 0

        try:
            c.execute("SELECT * FROM clientes WHERE datos_cifrados = 0")
            filas = c.fetchall()
            for row in filas:
                data = dict(row)
                class _Tmp:
                    pass
                tmp = _Tmp()
                tmp.nombre = data.get("nombre", "")
                tmp.telefono = data.get("telefono", "")
                tmp.email = data.get("email", "")
                tmp.notas = data.get("notas", "")
                nutrition_storage = data.get("nutrition_restrictions_storage")
                if nutrition_storage is not None:
                    nutrition_storage = encode_restrictions(
                        decode_restrictions(nutrition_storage, crypto_service), secure=True, crypto=crypto_service,
                    )
                campos_seg = self._cifrar_campos(tmp, crypto_service)
                c.execute('''
                    UPDATE clientes SET
                        nombre = ?,
                        telefono = ?,
                        email = ?,
                        nombre_enc = ?,
                        telefono_enc = ?,
                        email_enc = ?,
                        notas_enc = ?,
                        nombre_idx = ?,
                        telefono_idx = ?,
                        email_idx = ?,
                        datos_cifrados = 1
                    WHERE id_cliente = ?
                ''', (
                    self._placeholder_nombre(data.get("id_cliente", "")),
                    None,
                    None,
                    campos_seg.get("nombre_enc"),
                    campos_seg.get("telefono_enc"),
                    campos_seg.get("email_enc"),
                    campos_seg.get("notas_enc"),
                    campos_seg.get("nombre_idx"),
                    campos_seg.get("telefono_idx"),
                    campos_seg.get("email_idx"),
                    data.get("id_cliente"),
                ))
                if nutrition_storage is not None:
                    c.execute("UPDATE clientes SET nutrition_restrictions_storage = ? WHERE id_cliente = ?",
                              (nutrition_storage, data.get("id_cliente")))
                migrados += 1

            # Profiles whose older PII was already encrypted may still hold a
            # plain nutrition snapshot. Upgrade it in the same transaction.
            for row in c.execute("SELECT id_cliente,nutrition_restrictions_storage FROM clientes "
                                 "WHERE datos_cifrados = 1 AND nutrition_restrictions_storage IS NOT NULL").fetchall():
                if storage_mode(row["nutrition_restrictions_storage"]) == "plain":
                    protected = encode_restrictions(
                        decode_restrictions(row["nutrition_restrictions_storage"]),
                        secure=True, crypto=crypto_service,
                    )
                    c.execute("UPDATE clientes SET nutrition_restrictions_storage = ? WHERE id_cliente = ?",
                              (protected, row["id_cliente"]))
                    migrados += 1

            conn.commit()
            return migrados

        except Exception as exc:
            logger.error("[BD] Error migrando datos sensibles: %s", exc, exc_info=True)
            conn.rollback()
            return 0

        finally:
            conn.close()

    def obtener_todos_clientes(self, solo_activos: bool = False,
                               secure_mode: bool | None = None,
                               crypto_service: Any | None = None) -> list[dict]:
        """Devuelve todos los clientes de la base de datos para exportación."""
        usar_seguridad, crypto = self._usar_seguridad(secure_mode, crypto_service)
        conn = self._conn()
        c = conn.cursor()

        try:
            query = '''
                SELECT id_cliente, nombre, telefono, email, edad,
                       peso_kg, estatura_cm, grasa_corporal_pct,
                       nivel_actividad, objetivo, plantilla_tipo, fecha_registro,
                       ultimo_plan, total_planes_generados, activo,
                       nombre_enc, telefono_enc, email_enc, notas_enc
                FROM clientes
            '''
            if solo_activos:
                query += ' WHERE activo = 1'
            query += ' ORDER BY nombre ASC'

            c.execute(query)
            resultados = [dict(row) for row in c.fetchall()]
            if usar_seguridad:
                resultados = [self._descifrar_campos(r, crypto) for r in resultados]
            logger.info("[BD] Exportando todos los clientes: %s registros", len(resultados))
            return resultados

        except Exception as e:
            logger.error("[BD] Error obteniendo todos los clientes: %s", e, exc_info=True)
            return []

        finally:
            conn.close()

    def obtener_clientes_recientes(self, limite: int = 10,
                                  solo_activos: bool = True) -> list[dict]:
        """Devuelve los clientes con actividad más reciente (último plan o registro)."""
        conn = self._conn()
        c = conn.cursor()
        try:
            query = '''
                SELECT id_cliente, nombre, telefono, edad, peso_kg,
                       estatura_cm, grasa_corporal_pct, nivel_actividad,
                       objetivo, plantilla_tipo, fecha_registro,
                       ultimo_plan, total_planes_generados
                FROM clientes
            '''
            if solo_activos:
                query += ' WHERE activo = 1'
            query += ' ORDER BY COALESCE(ultimo_plan, fecha_registro) DESC LIMIT ?'
            c.execute(query, (limite,))
            return [dict(row) for row in c.fetchall()]
        except Exception as e:
            logger.error("[BD] Error obteniendo clientes recientes: %s", e)
            return []
        finally:
            conn.close()

    def buscar_duplicados_nombre(self, nombre: str,
                                 solo_activos: bool = True) -> list[dict]:
        """Busca clientes con nombre similar para detectar duplicados."""
        conn = self._conn()
        c = conn.cursor()
        try:
            query = '''
                SELECT id_cliente, nombre, telefono, edad, peso_kg, objetivo,
                       fecha_registro, total_planes_generados
                FROM clientes
                WHERE nombre LIKE ?
            '''
            if solo_activos:
                query += ' AND activo = 1'
            query += ' LIMIT 5'
            c.execute(query, (f'%{nombre}%',))
            return [dict(row) for row in c.fetchall()]
        except Exception as e:
            logger.error("[BD] Error buscando duplicados: %s", e)
            return []
        finally:
            conn.close()

    def importar_clientes_csv(self, filas: list[dict]) -> tuple[int, int]:
        """Importa clientes desde lista de dicts CSV. Retorna (exitosos, fallidos)."""
        from core.modelos import ClienteEvaluacion
        ok, fail = 0, 0
        for fila in filas:
            try:
                cliente = ClienteEvaluacion(
                    nombre=fila.get("nombre", "").strip(),
                    telefono=fila.get("telefono", "").strip() or None,
                    edad=int(fila["edad"]) if fila.get("edad") else 25,
                    peso_kg=float(fila["peso_kg"]) if fila.get("peso_kg") else 70.0,
                    estatura_cm=float(fila["estatura_cm"]) if fila.get("estatura_cm") else 170.0,
                    grasa_corporal_pct=float(fila["grasa_corporal_pct"]) if fila.get("grasa_corporal_pct") else 15.0,
                    nivel_actividad=fila.get("nivel_actividad", "moderada").strip(),
                    objetivo=fila.get("objetivo", "Mantenimiento").strip(),
                )
                if not cliente.nombre:
                    fail += 1
                    continue
                if self.registrar_cliente(cliente):
                    ok += 1
                else:
                    fail += 1
            except Exception as exc:
                logger.warning("[BD] Error importando fila CSV: %s", exc)
                fail += 1
        logger.info("[BD] Import CSV: %d OK, %d fallidos", ok, fail)
        return ok, fail

    def obtener_planes_periodo(self,
                               fecha_inicio: datetime,
                               fecha_fin: datetime) -> list[dict]:
        """Devuelve todos los planes generados en el período con nombre del cliente."""
        conn = self._conn()
        c = conn.cursor()

        try:
            c.execute('''
                SELECT
                    c.nombre,
                    p.fecha_generacion, p.kcal_objetivo, p.kcal_real,
                    p.proteina_g, p.carbs_g, p.grasa_g, p.objetivo,
                    p.plantilla_tipo, p.tipo_plan,
                    p.peso_en_momento, p.grasa_en_momento,
                    p.desviacion_maxima_pct, p.ruta_pdf
                FROM planes_generados p
                LEFT JOIN clientes c ON p.id_cliente = c.id_cliente
                WHERE p.fecha_generacion BETWEEN ? AND ?
                ORDER BY p.fecha_generacion DESC
            ''', (fecha_inicio, fecha_fin))
            resultados = [dict(row) for row in c.fetchall()]
            logger.info("[BD] Planes período: %s registros", len(resultados))
            return resultados

        except Exception as e:
            logger.error("[BD] Error obteniendo planes del período: %s", e, exc_info=True)
            return []

        finally:
            conn.close()
