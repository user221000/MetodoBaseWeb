"""Explicit desktop declarations using catalog IDs, without clinical inference."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from core.nutrition_restrictions import NutritionRestrictions
from src.alimentos_base import ALIMENTOS_BASE


class NutritionDeclarationWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.dirty = False
        layout = QVBoxLayout(self)
        label = QLabel("Declaración de alergias")
        self.status = QComboBox()
        self.status.setAccessibleName("Declaración de alergias")
        for text, value in (("Sin información declarada", "not_reported"),
                            ("Declara no tener alergias", "none_reported"),
                            ("Declara alergias", "reported")):
            self.status.addItem(text, value)
        label.setBuddy(self.status)
        layout.addWidget(label)
        layout.addWidget(self.status)
        self.other = QCheckBox("Declara otra alergia que no aparece en el catálogo")
        self.other.setAccessibleName(self.other.text())
        layout.addWidget(self.other)
        self.review = QCheckBox("Solicita revisión profesional de la alimentación")
        layout.addWidget(self.review)
        self.tabs = QTabWidget()
        self.allergy_foods = self._foods("Alimentos declarados para alergias")
        self.excluded_foods = self._foods("Alimentos excluidos del plan")
        self.tabs.addTab(self.allergy_foods, "Alergias declaradas")
        self.tabs.addTab(self.excluded_foods, "Excluir alimentos")
        self.tabs.setMaximumHeight(170)
        layout.addWidget(self.tabs)
        self.explanation = QLabel(
            "Son datos declarados, sin garantía clínica. Una alergia declarada o una solicitud "
            "de revisión impide generar planes automáticamente. Guarda el perfil y solicita "
            "revisión profesional por tu canal habitual. Las notas no sustituyen esta declaración."
        )
        self.explanation.setWordWrap(True)
        layout.addWidget(self.explanation)
        self.status.currentIndexChanged.connect(self._status_changed)
        self.other.toggled.connect(self._changed)
        self.review.toggled.connect(self._changed)
        self.allergy_foods.itemChanged.connect(self._changed)
        self.excluded_foods.itemChanged.connect(self._changed)
        self.load(NutritionRestrictions.from_declaration(None, ALIMENTOS_BASE))

    @staticmethod
    def _foods(label):
        listing = QListWidget()
        listing.setAccessibleName(label)
        for food_id in sorted(ALIMENTOS_BASE):
            item = QListWidgetItem(food_id)
            item.setData(Qt.ItemDataRole.UserRole, food_id)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Unchecked)
            listing.addItem(item)
        return listing

    def _changed(self, *args):
        self.dirty = True

    def _status_changed(self, *args):
        reported = self.status.currentData() == "reported"
        self.other.setEnabled(reported)
        self.allergy_foods.setEnabled(reported)
        if not reported:
            self.other.setChecked(False)
            for index in range(self.allergy_foods.count()):
                self.allergy_foods.item(index).setCheckState(Qt.CheckState.Unchecked)
        self.dirty = True

    def load(self, restrictions: NutritionRestrictions):
        self.status.setCurrentIndex(self.status.findData(restrictions.allergies.status))
        self._status_changed()
        self.other.setChecked(restrictions.allergies.other_reported)
        self.review.setChecked(restrictions.professional_review_requested)
        for listing, selected in ((self.allergy_foods, restrictions.allergies.foods),
                                  (self.excluded_foods, restrictions.excluded_foods)):
            for index in range(listing.count()):
                item = listing.item(index)
                item.setCheckState(Qt.CheckState.Checked if item.data(Qt.ItemDataRole.UserRole) in selected
                                   else Qt.CheckState.Unchecked)
        self.dirty = False

    @staticmethod
    def _selected(listing):
        return [listing.item(index).data(Qt.ItemDataRole.UserRole) for index in range(listing.count())
                if listing.item(index).checkState() == Qt.CheckState.Checked]

    def value(self) -> NutritionRestrictions:
        return NutritionRestrictions.from_profile(
            ALIMENTOS_BASE,
            allergies={"version": 1, "status": self.status.currentData(),
                       "foods": self._selected(self.allergy_foods), "other_reported": self.other.isChecked()},
            excluded_foods=self._selected(self.excluded_foods),
            professional_review_requested=self.review.isChecked(),
        )
