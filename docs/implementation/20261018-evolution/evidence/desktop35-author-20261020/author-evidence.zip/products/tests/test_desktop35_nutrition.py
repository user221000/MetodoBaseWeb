"""Desktop persistence and real Qt handler contracts, using synthetic local data."""
from __future__ import annotations

import copy
import importlib.util
import json
import os
import sqlite3

import pytest

from core.modelos import ClienteEvaluacion
from core.nutrition_restrictions import (
    NutritionRestrictions,
    ProfessionalNutritionReviewRequired,
)
from core.services.crypto_service import CryptoService
from core.services.key_manager import KeyManager
from core.services.nutrition_storage import (
    MAX_STORAGE_BYTES,
    NutritionStorageUnavailable,
    decode_restrictions,
    restrictions_from_row,
)
from src.alimentos_base import ALIMENTOS_BASE, CATEGORIAS
from src.gestor_bd import GestorBDClientes

FOODS = sorted(ALIMENTOS_BASE)


def facts(*, reported=False, review=False, excluded=()):
    return NutritionRestrictions.from_profile(
        ALIMENTOS_BASE,
        allergies={"version": 1, "status": "reported" if reported else "not_reported",
                   "foods": [FOODS[0]] if reported else [], "other_reported": False},
        excluded_foods=list(excluded), professional_review_requested=review,
    )


def client(restrictions=None):
    value = ClienteEvaluacion(nombre="Synthetic Desktop", edad=25, peso_kg=70, estatura_cm=170,
                              grasa_corporal_pct=15, nivel_actividad="moderada", objetivo="mantenimiento")
    value.id_cliente = "D35TEST1"
    value.nutrition_restrictions = restrictions
    return value


@pytest.fixture
def crypto(tmp_path, monkeypatch):
    monkeypatch.delenv("METODO_BASE_MASTER_KEY", raising=False)
    km = KeyManager(tmp_path / "private" / "synthetic-keys.json")
    km.create_key()
    return CryptoService(km)


@pytest.fixture
def gestor_type():
    baseline = os.environ.get("DESKTOP35_BASELINE_GESTOR")
    if not baseline:
        return GestorBDClientes
    spec = importlib.util.spec_from_file_location("desktop35_baseline_gestor", baseline)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.GestorBDClientes


@pytest.fixture
def bd(tmp_path, gestor_type):
    return gestor_type(str(tmp_path / "synthetic.db"))


def stored(bd):
    with sqlite3.connect(bd.db_path) as db:
        return db.execute("SELECT nutrition_restrictions_storage FROM clientes").fetchone()[0]


def test_persisted_declared_facts_roundtrip(bd):
    value = client(facts(reported=True, excluded=[FOODS[1]]))
    assert bd.registrar_cliente(value)
    actual = bd.obtener_cliente_por_id(value.id_cliente)
    assert isinstance(actual.get("nutrition_restrictions"), NutritionRestrictions)
    assert actual["nutrition_restrictions"] == value.nutrition_restrictions
    assert actual["alimentos_excluidos"] == [FOODS[1]]


def test_secure_mode_without_key_never_writes_plaintext(bd):
    assert not bd.registrar_cliente(client(facts(reported=True)), secure_mode=True)
    with sqlite3.connect(bd.db_path) as db:
        assert db.execute("SELECT COUNT(*) FROM clientes").fetchone()[0] == 0


def test_stale_snapshot_does_not_enter_plan_history(bd):
    captured = client(facts())
    assert bd.registrar_cliente(captured)
    changed = client(facts(review=True))
    assert bd.registrar_cliente(changed)
    assert not bd.registrar_plan_generado(captured, {}, "synthetic-existing.pdf")
    with sqlite3.connect(bd.db_path) as db:
        assert db.execute("SELECT COUNT(*) FROM planes_generados").fetchone()[0] == 0


def test_edit_handler_uses_real_supported_update_method(bd, monkeypatch):
    from PySide6.QtWidgets import QApplication, QDialog

    from ui_desktop.pyside import dialogo_registro_cliente as ui

    baseline_ui = os.environ.get("DESKTOP35_BASELINE_DIALOG")
    if baseline_ui:
        spec = importlib.util.spec_from_file_location("desktop35_baseline_dialog", baseline_ui)
        ui = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(ui)
    app = QApplication.instance() or QApplication([])
    notices = []
    monkeypatch.setattr(ui, "mostrar_toast", lambda parent, text, level: notices.append(text))
    value = client()
    assert bd.registrar_cliente(value)
    dialog = ui.DialogoRegistroCliente(bd, cliente_data={"id_cliente": value.id_cliente})
    dialog.entry_nombre.setText("Synthetic Changed")
    dialog._on_guardar_edicion()
    assert dialog.result() == QDialog.DialogCode.Accepted, notices
    assert bd.obtener_cliente_por_id(value.id_cliente)["nombre"] == "Synthetic Changed"
    dialog.close()
    app.processEvents()


def test_legacy_file_upgrade_keeps_null_unknown_and_history(tmp_path):
    path = tmp_path / "upgrade.db"
    # Obtain the exact historical preimage schema, not a hand-made miniature.
    baseline = os.environ.get("DESKTOP35_OLD_GESTOR")
    assert baseline, "The author runner must provide the exact 55a3 legacy module."
    spec = importlib.util.spec_from_file_location("desktop35_old_upgrade", baseline)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    old = module.GestorBDClientes(str(path))
    value = client()
    assert old.registrar_cliente(value)
    assert old.registrar_plan_generado(value, {}, "synthetic-old.pdf")
    with sqlite3.connect(path) as db:
        before = db.execute("SELECT id_cliente,nombre,total_planes_generados FROM clientes").fetchall()
        history = db.execute("SELECT * FROM planes_generados").fetchall()
    upgraded = GestorBDClientes(str(path))
    assert stored(upgraded) is None
    loaded = upgraded.obtener_cliente_por_id(value.id_cliente)
    assert loaded["nutrition_restrictions"].allergies.status == "not_reported"
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT id_cliente,nombre,total_planes_generados FROM clientes").fetchall() == before
        assert db.execute("SELECT * FROM planes_generados").fetchall() == history
    GestorBDClientes(str(path))
    assert stored(upgraded) is None


@pytest.mark.parametrize("secure", [False, True])
def test_none_update_preserves_snapshot_byte_exact(tmp_path, crypto, secure):
    bd = GestorBDClientes(str(tmp_path / "preserve.db"), secure_mode=secure,
                          crypto_service=crypto if secure else None)
    assert bd.registrar_cliente(client(facts(reported=True, excluded=[FOODS[1]])))
    before = stored(bd)
    value = client()
    value.nombre = "Synthetic Other Edit"
    assert bd.actualizar_cliente(value)
    assert stored(bd) == before
    assert bd.obtener_cliente_por_id(value.id_cliente)["nutrition_restrictions"].allergies.status == "reported"


def test_ciphertext_no_key_and_corruption_fail_closed(tmp_path, crypto):
    path = tmp_path / "cipher.db"
    bd = GestorBDClientes(str(path), secure_mode=True, crypto_service=crypto)
    assert bd.registrar_cliente(client(facts(reported=True, excluded=[FOODS[1]])))
    envelope = stored(bd)
    assert json.loads(envelope)["mode"] == "cipher"
    assert FOODS[0] not in envelope and FOODS[1] not in envelope
    no_key = GestorBDClientes(str(path))
    with pytest.raises(NutritionStorageUnavailable):
        no_key.obtener_cliente_por_id("D35TEST1")
    with pytest.raises(NutritionStorageUnavailable):
        no_key.attach_nutrition_restrictions(client())
    assert not no_key.registrar_plan_generado(client(), {}, "synthetic-existing.pdf")
    with sqlite3.connect(path) as db:
        db.execute("UPDATE clientes SET nutrition_restrictions_storage = ?", ('{"version":1}',))
    with pytest.raises(NutritionStorageUnavailable):
        bd.obtener_cliente_por_id("D35TEST1")


def test_partial_and_stale_generation_objects_cannot_drop_declarations(bd):
    assert bd.registrar_cliente(client(facts(reported=True)))
    with pytest.raises(ProfessionalNutritionReviewRequired):
        bd.attach_nutrition_restrictions(client())
    assert not bd.registrar_cliente_para_plan(client(facts()))
    assert bd.obtener_cliente_por_id("D35TEST1")["nutrition_restrictions"].allergies.status == "reported"


def test_new_declared_generation_requires_explicit_profile_save(bd):
    assert not bd.registrar_cliente_para_plan(client(facts(reported=True)))
    assert not bd.registrar_cliente_para_plan(client(facts(excluded=[FOODS[1]])))
    with sqlite3.connect(bd.db_path) as db:
        assert db.execute("SELECT COUNT(*) FROM clientes").fetchone()[0] == 0


@pytest.mark.parametrize("raw", [
    "", "{}", "[]", '{"version":1,"version":1,"mode":"plain","payload":"{}"}',
    '{"version":true,"mode":"plain","payload":"{}"}',
    '{"version":1,"mode":"unknown","payload":"{}"}',
    '{"version":1,"mode":"plain","payload":"null"}',
    '{"version":1,"mode":"plain","payload":"{}","extra":1}',
    "x" * (MAX_STORAGE_BYTES + 1),
], ids=["empty", "empty-object", "array", "duplicate-key", "bool-version", "unknown-mode",
        "null-inner", "extra-field", "oversize"])
def test_malformed_storage_never_defaults_to_unknown(raw):
    with pytest.raises(NutritionStorageUnavailable):
        decode_restrictions(raw)


def test_inner_duplicates_and_invalid_foods_rejected():
    inner = ('{"version":1,"declaration":null,"declaration":null,"excluded_foods":[]}')
    with pytest.raises(NutritionStorageUnavailable):
        decode_restrictions(json.dumps({"version": 1, "mode": "plain", "payload": inner}))
    with pytest.raises(NutritionStorageUnavailable):
        restrictions_from_row({"nutrition_restrictions_storage": "unreadable"})


def test_ciphertext_never_silently_downgrades(tmp_path, crypto):
    bd = GestorBDClientes(str(tmp_path / "no-downgrade.db"), crypto_service=crypto)
    assert bd.registrar_cliente(client(facts(review=True)), secure_mode=True)
    assert bd.actualizar_cliente(client(facts()), secure_mode=False)
    assert json.loads(stored(bd))["mode"] == "cipher"


def test_real_widget_preserves_preload_then_records_explicit_change(bd, monkeypatch):
    from PySide6.QtWidgets import QApplication

    from ui_desktop.pyside.dialogo_registro_cliente import DialogoRegistroCliente
    app = QApplication.instance() or QApplication([])
    assert bd.registrar_cliente(client(facts(reported=True, excluded=[FOODS[1]])))
    dialog = DialogoRegistroCliente(bd, cliente_data={"id_cliente": "D35TEST1", "nombre": "Partial"})
    assert dialog.nutrition_widget.value() == facts(reported=True, excluded=[FOODS[1]])
    assert dialog._build_cliente().nutrition_restrictions is None
    dialog.nutrition_widget.status.setCurrentIndex(dialog.nutrition_widget.status.findData("none_reported"))
    changed = dialog._build_cliente().nutrition_restrictions
    assert changed.allergies.status == "none_reported"
    assert changed.excluded_foods == (FOODS[1],)
    dialog.close()
    app.processEvents()


def test_reported_can_save_profile_without_generation(bd, monkeypatch):
    from PySide6.QtWidgets import QApplication, QDialog

    from ui_desktop.pyside import dialogo_registro_cliente as ui
    app = QApplication.instance() or QApplication([])
    monkeypatch.setattr(ui, "mostrar_toast", lambda *args: None)
    dialog = ui.DialogoRegistroCliente(bd)
    dialog.entry_nombre.setText("Synthetic Report")
    widget = dialog.nutrition_widget
    widget.status.setCurrentIndex(widget.status.findData("reported"))
    widget.other.setChecked(True)
    dialog._on_registrar()
    assert dialog.result() == QDialog.DialogCode.Accepted
    saved = bd.obtener_cliente_por_id(dialog.cliente_registrado["id_cliente"])
    with pytest.raises(ProfessionalNutritionReviewRequired):
        saved["nutrition_restrictions"].require_automated_generation()
    assert dialog.generar_plan is False
    dialog.close()
    app.processEvents()


def test_secure_migration_protects_existing_plain_snapshot_atomically(bd, crypto):
    assert bd.registrar_cliente(client(facts(reported=True, excluded=[FOODS[1]])))
    assert json.loads(stored(bd))["mode"] == "plain"
    assert bd.migrar_datos_sensibles(crypto) == 1
    assert json.loads(stored(bd))["mode"] == "cipher"
    assert bd.obtener_cliente_por_id("D35TEST1", secure_mode=True,
                                    crypto_service=crypto)["nutrition_restrictions"] == facts(reported=True, excluded=[FOODS[1]])


def test_invalid_new_snapshot_rolls_back_entire_profile_edit(bd):
    assert bd.registrar_cliente(client(facts(review=True)))
    before = stored(bd)
    invalid = client()
    invalid.nombre = "Must Not Persist"
    invalid.nutrition_restrictions = object()
    assert not bd.actualizar_cliente(invalid)
    actual = bd.obtener_cliente_por_id("D35TEST1")
    assert actual["nombre"] == "Synthetic Desktop"
    assert stored(bd) == before


def test_profile_edit_does_not_increment_generated_plan_count(bd):
    assert bd.registrar_cliente(client(facts()))
    before = bd.obtener_cliente_por_id("D35TEST1")
    assert bd.actualizar_cliente(client(facts(review=True)))
    after = bd.obtener_cliente_por_id("D35TEST1")
    assert after["total_planes_generados"] == before["total_planes_generados"]
    assert after["ultimo_plan"] == before["ultimo_plan"]


def test_secure_migration_failure_rolls_back_other_rows(bd, crypto):
    assert bd.registrar_cliente(client(facts(review=True)))
    broken = client(facts())
    broken.id_cliente = "D35TEST2"
    assert bd.registrar_cliente(broken)
    with sqlite3.connect(bd.db_path) as db:
        db.execute("UPDATE clientes SET nutrition_restrictions_storage = '{}' WHERE id_cliente = ?", (broken.id_cliente,))
        before = db.execute("SELECT * FROM clientes ORDER BY id_cliente").fetchall()
    assert bd.migrar_datos_sensibles(crypto) == 0
    with sqlite3.connect(bd.db_path) as db:
        assert db.execute("SELECT * FROM clientes ORDER BY id_cliente").fetchall() == before


@pytest.mark.parametrize("secure", [False, True])
def test_personal_prefs_preserve_declaration_and_exclusions(tmp_path, monkeypatch, crypto, secure):
    from src import gestor_preferencias as prefs
    monkeypatch.setattr(prefs, "_BASE_DIR", tmp_path / "prefs")
    gp = prefs.GestorPreferencias("synthetic-user", secure_mode=secure, crypto_service=crypto if secure else None)
    value = facts(review=True, excluded=[FOODS[1]])
    assert gp.guardar({"peso_kg": 70, "restricciones_nutricionales": value.declaration_payload(),
                       "alimentos_excluidos": list(value.excluded_foods)})
    before = json.loads(gp._path.read_text(encoding="utf-8"))["_nutrition35"]
    assert gp.guardar({"peso_kg": 71, "restricciones_nutricionales": None, "alimentos_excluidos": None})
    after = json.loads(gp._path.read_text(encoding="utf-8"))
    assert after["_nutrition35"] == before
    assert after["peso_kg"] == 71
    assert restrictions_from_row(gp.cargar()) == value
    if secure:
        assert FOODS[1] not in gp._path.read_text(encoding="utf-8")
        with pytest.raises(NutritionStorageUnavailable):
            prefs.GestorPreferencias("synthetic-user").cargar()


def test_personal_prefs_unreadable_or_no_key_never_reset(tmp_path, monkeypatch):
    from src import gestor_preferencias as prefs
    monkeypatch.setattr(prefs, "_BASE_DIR", tmp_path / "prefs")
    gp = prefs.GestorPreferencias("synthetic-user", secure_mode=True)
    assert not gp.guardar({"restricciones_nutricionales": facts(review=True).declaration_payload()})
    assert not gp._path.exists()
    gp._path.write_text('{"peso_kg":70,"peso_kg":71}', encoding="utf-8")
    before = gp._path.read_bytes()
    with pytest.raises(NutritionStorageUnavailable):
        gp.cargar()
    assert not gp.guardar({"peso_kg": 72})
    assert gp._path.read_bytes() == before


def test_personal_legacy_preferences_upgrade_keeps_food_exclusions(tmp_path, monkeypatch):
    from src import gestor_preferencias as prefs
    monkeypatch.setattr(prefs, "_BASE_DIR", tmp_path / "prefs")
    gp = prefs.GestorPreferencias("synthetic-user")
    gp._path.write_text(json.dumps({"peso_kg": 73, "idioma": "es", "alimentos_excluidos": [FOODS[1]]}), encoding="utf-8")
    loaded = gp.cargar()
    assert restrictions_from_row(loaded).allergies.status == "not_reported"
    assert restrictions_from_row(loaded).excluded_foods == (FOODS[1],)
    assert gp.guardar({"restricciones_nutricionales": facts(review=True).declaration_payload()})
    after = gp.cargar()
    assert after["peso_kg"] == 73 and after["idioma"] == "es"
    assert after["alimentos_excluidos"] == [FOODS[1]]


def test_personal_profile_widget_keeps_unsaved_changes_on_failed_persistence(monkeypatch):
    from PySide6.QtWidgets import QApplication, QDialog

    from core.services.auth_service import SesionActiva
    from ui_desktop.pyside.panel_perfil_detalle import PanelPerfilDetalle
    app = QApplication.instance() or QApplication([])
    written = []
    value = facts(reported=True, excluded=[FOODS[1]])
    dialog = PanelPerfilDetalle(SesionActiva("synthetic-user", "Synthetic", "usuario"),
        prefs_actuales={"peso_kg":70, "restricciones_nutricionales":value.declaration_payload(),
                        "alimentos_excluidos":list(value.excluded_foods)},
        save_profile=lambda data: written.append(data) or False)
    dialog._spin_peso.setValue(71)
    dialog._guardar()
    assert dialog.result() != QDialog.DialogCode.Accepted
    assert "confirmar" in dialog._nutrition_error.text()
    assert len(written) == 1
    assert "restricciones_nutricionales" not in written[0]
    assert dialog.nutrition_widget.value() == value
    assert dialog._spin_peso.value() == 71
    dialog.close()
    app.processEvents()


class _Signal:
    def __init__(self):
        self.values = []

    def emit(self, *args):
        self.values.append(args)


def _signals():
    from types import SimpleNamespace
    return SimpleNamespace(**{key: _Signal() for key in (
        "progress", "done", "error", "error_msg", "log_msg", "set_progress", "set_step", "btn_spinner")})


@pytest.mark.parametrize("path", ["gym-panel", "gym-main", "personal"])
def test_three_real_worker_paths_guard_before_cpu_constructor_and_pdf(bd, monkeypatch, path):
    from types import SimpleNamespace

    from core import generador_opciones, generador_planes, motor_nutricional
    from ui_desktop.pyside import dialogo_generar_plan, generar_plan_panel, main_window
    value = client(facts(reported=True))
    value.telefono = "5512345678"
    assert bd.registrar_cliente(value)
    calls = []
    def forbidden(*args, **kwargs):
        calls.append("generation-side-effect")
        raise AssertionError("Guard must precede this side effect")
    monkeypatch.setattr(motor_nutricional.MotorNutricional, "calcular_motor", forbidden)
    monkeypatch.setattr(generador_planes.ConstructorPlanNuevo, "construir", forbidden)
    monkeypatch.setattr(generador_opciones.ConstructorPlanConOpciones, "construir", forbidden)
    sig = _signals()
    if path == "gym-panel":
        context = SimpleNamespace(gestor_bd=bd, _cliente_actual=client(), _sig=sig)
        generar_plan_panel.GenerarPlanPanel._procesar_en_hilo(context)
        errors = sig.error_msg.values
    elif path == "gym-main":
        field = lambda text: SimpleNamespace(text=lambda: text)
        context = SimpleNamespace(
            gestor_bd=bd, _sig=sig, entry_nombre=field("Synthetic"), entry_telefono=field("5512345678"),
            entry_edad=field("25"), entry_peso=field("70"), entry_estatura=field("170"), entry_grasa=field("15"),
            combo_actividad=SimpleNamespace(currentText=lambda: "moderada"),
            combo_plantilla=SimpleNamespace(currentText=lambda: "Mantenimiento"),
            _tipo_plan_activo=lambda: "Con Opciones",
        )
        main_window.MainWindow._procesar_datos(context)
        errors = sig.error_msg.values
    else:
        context = SimpleNamespace(_sig=sig, _tiene_grasa=True,
            _perfil={"grasa_corporal_pct":15, "restricciones_nutricionales":facts(reported=True).declaration_payload()},
            _sesion=SimpleNamespace(nombre_display="Synthetic"), _excluidos=[])
        dialogo_generar_plan.DialogoGenerarPlan._worker(context, "con_opciones")
        errors = sig.error.values
    assert not calls
    assert len(errors) == 1 and "revisión profesional" in errors[0][0]
    assert not sig.done.values


def test_real_personal_worker_concurrent_catalogs_leave_globals_unchanged(tmp_path, monkeypatch):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Barrier
    from types import MethodType, SimpleNamespace

    from core.exportador_opciones import GeneradorPDFConOpciones
    from core.food_catalog import FoodCatalog
    from core.generador_opciones import ConstructorPlanConOpciones
    from src import gestor_preferencias as prefs
    from ui_desktop.pyside.dialogo_generar_plan import DialogoGenerarPlan
    monkeypatch.setattr(prefs, "_BASE_DIR", tmp_path / "prefs")
    before = copy.deepcopy(CATEGORIAS)
    original = ConstructorPlanConOpciones.construir
    barrier = Barrier(2)
    plans = {}
    def build(value, **kwargs):
        barrier.wait(timeout=20)
        plan = original(value, **kwargs)
        FoodCatalog.from_data(ALIMENTOS_BASE, CATEGORIAS, value.nutrition_restrictions.excluded_foods).validate_plan(plan)
        plans[value.nombre] = plan
        return plan
    monkeypatch.setattr(ConstructorPlanConOpciones, "construir", build)
    def export(pdf, value, plan):
        path = tmp_path / (value.nombre + ".synthetic-pdf")
        path.write_bytes(b"synthetic export boundary")
        return str(path)
    monkeypatch.setattr(GeneradorPDFConOpciones, "generar", export)
    contexts = []
    for index, excluded in enumerate((["huevo", "avena"], ["arroz_blanco", "nueces"])):
        uid = "synthetic-" + str(index)
        gp = prefs.GestorPreferencias(uid)
        assert gp.guardar({"peso_kg":70, "grasa_corporal_pct":15, "alimentos_excluidos":excluded})
        loaded = gp.cargar()
        context = SimpleNamespace(_sig=_signals(), _tiene_grasa=True, _perfil=loaded,
            _sesion=SimpleNamespace(nombre_display=uid, id_usuario=uid), _excluidos=excluded,
            _generar_ruta_pdf=DialogoGenerarPlan._generar_ruta_pdf)
        context._require_current_nutrition = MethodType(DialogoGenerarPlan._require_current_nutrition, context)
        contexts.append(context)
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(lambda ctx: DialogoGenerarPlan._worker(ctx, "con_opciones"), contexts))
    assert CATEGORIAS == before
    assert len(plans) == 2
    for context in contexts:
        assert not context._sig.error.values
        assert len(context._sig.done.values) == 1
