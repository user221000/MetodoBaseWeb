"""Bounded desktop storage for declared nutrition facts, without health logging.

The nullable column upgrades existing SQLite files without rewriting old rows.
Its versioned envelope records encryption explicitly; unreadable facts never
become an unknown declaration. Exclusions share the protected snapshot but keep
their independent domain/wire field.
"""
from __future__ import annotations

import json
from typing import Any

from core.nutrition_restrictions import NutritionRestrictions
from src.alimentos_base import ALIMENTOS_BASE

MAX_PLAIN_BYTES = 131_072
MAX_STORAGE_BYTES = 262_144


class NutritionStorageUnavailable(ValueError):
    """Persisted facts cannot safely be read, changed or used for a plan."""

    code = "nutrition_profile_unavailable"

    def __init__(self) -> None:
        super().__init__("No se pudo leer la declaración alimentaria. Revisa el perfil antes de generar un plan.")


def _closed_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result = {}
    for key, value in pairs:
        if key in result:
            raise NutritionStorageUnavailable()
        result[key] = value
    return result


def _loads(value: object, limit: int) -> object:
    if type(value) is not str or not value or len(value.encode("utf-8")) > limit:
        raise NutritionStorageUnavailable()
    return json.loads(value, object_pairs_hook=_closed_pairs)


def _json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def storage_mode(value: object) -> str | None:
    if value is None:
        return None
    try:
        envelope = _loads(value, MAX_STORAGE_BYTES)
        if (type(envelope) is not dict or set(envelope) != {"version", "mode", "payload"}
                or type(envelope["version"]) is not int or envelope["version"] != 1
                or envelope["mode"] not in {"plain", "cipher"}
                or type(envelope["payload"]) is not str):
            raise NutritionStorageUnavailable()
        return envelope["mode"]
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError):
        raise NutritionStorageUnavailable() from None


def decode_restrictions(value: object, crypto: Any = None) -> NutritionRestrictions:
    """NULL is legacy unknown; every non-null invalid envelope fails closed."""
    if value is None:
        return NutritionRestrictions.from_declaration(None, ALIMENTOS_BASE)
    try:
        mode = storage_mode(value)
        envelope = _loads(value, MAX_STORAGE_BYTES)
        payload = envelope["payload"]
        if mode == "cipher":
            if crypto is None:
                raise NutritionStorageUnavailable()
            payload = crypto.decrypt(payload)
        facts = _loads(payload, MAX_PLAIN_BYTES)
        if (type(facts) is not dict
                or set(facts) != {"version", "declaration", "excluded_foods"}
                or type(facts["version"]) is not int or facts["version"] != 1
                or facts["declaration"] is None):
            raise NutritionStorageUnavailable()
        return NutritionRestrictions.from_declaration(
            facts["declaration"], ALIMENTOS_BASE, excluded_foods=facts["excluded_foods"],
        )
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, RuntimeError):
        raise NutritionStorageUnavailable() from None


def encode_restrictions(value: object, *, secure: bool, crypto: Any = None) -> str:
    """Never fall back to plaintext if encryption was requested."""
    try:
        if type(value) is not NutritionRestrictions:
            raise NutritionStorageUnavailable()
        validated = NutritionRestrictions.from_declaration(
            value.declaration_payload(), ALIMENTOS_BASE, excluded_foods=value.excluded_foods,
        )
        payload = _json({"version": 1, "declaration": validated.declaration_payload(),
                         "excluded_foods": list(validated.excluded_foods)})
        if len(payload.encode("utf-8")) > MAX_PLAIN_BYTES:
            raise NutritionStorageUnavailable()
        if secure:
            if crypto is None:
                raise NutritionStorageUnavailable()
            payload = crypto.encrypt(payload)
            if type(payload) is not str or not payload:
                raise NutritionStorageUnavailable()
        result = _json({"version": 1, "mode": "cipher" if secure else "plain", "payload": payload})
        if len(result.encode("utf-8")) > MAX_STORAGE_BYTES:
            raise NutritionStorageUnavailable()
        return result
    except (ValueError, TypeError, KeyError, AttributeError, OSError, RecursionError, RuntimeError):
        raise NutritionStorageUnavailable() from None


def restrictions_from_row(row: dict) -> NutritionRestrictions:
    """Read hydrated DTOs only; raw ciphertext cannot masquerade as missing."""
    if row.get("nutrition_profile_unavailable"):
        raise NutritionStorageUnavailable()
    if type(row.get("nutrition_restrictions")) is NutritionRestrictions:
        return row["nutrition_restrictions"]
    if row.get("nutrition_restrictions_storage") is not None:
        raise NutritionStorageUnavailable()
    return NutritionRestrictions.from_declaration(
        row.get("restricciones_nutricionales"), ALIMENTOS_BASE,
        excluded_foods=row.get("alimentos_excluidos") or (),
    )
