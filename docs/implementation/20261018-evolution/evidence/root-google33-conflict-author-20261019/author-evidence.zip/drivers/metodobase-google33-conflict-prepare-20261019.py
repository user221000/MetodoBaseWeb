"""Pin the unchanged RED input, then extend only the Google write boundary."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

ROOT = Path('F:/mb-google33-conflict-window-20261019')
OUT = Path('C:/Users/Consu/AppData/Local/Temp/metodobase-google33-conflict-author-20261019')
SERVICE = ROOT / 'web/services/google_link.py'
TEST = ROOT / 'tests/test_google33_conflict_window.py'
OUT.mkdir(exist_ok=True)
receipt = OUT / 'before-inputs.json'
assert not receipt.exists()
entries = {}
for relative, source in [('web/services/google_link.py', SERVICE), ('tests/test_google33_conflict_window.py', TEST)]:
    payload = source.read_bytes()
    target = OUT / 'before-source' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    target.write_bytes(payload)
    entries[relative] = {'sha256': hashlib.sha256(payload).hexdigest(), 'bytes': len(payload)}
entries['head'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
for name in ['before.xml', 'before.stdout', 'before.stderr']:
    payload = (OUT / name).read_bytes()
    entries[name] = {'sha256': hashlib.sha256(payload).hexdigest(), 'bytes': len(payload)}
receipt.write_text(json.dumps(entries, indent=2) + '\n', encoding='utf-8')
original = SERVICE.read_bytes()
text = original.decode('utf-8')
newline = '\r\n' if '\r\n' in text else '\n'
text = text.replace('\r\n', '\n')
text = text.replace('from datetime import datetime, timezone\n', 'from contextlib import contextmanager\nfrom datetime import datetime, timezone\n', 1)
helper = '''@contextmanager
def _write_conflicts(db):
    """Classify constraint races across every flush in an owned write.

    Rollback must succeed before publishing a conflict. Rollback uncertainty
    remains 503; this boundary never retries, re-queries or adopts a winner.
    """
    try:
        yield
    except IntegrityError:
        rollback(db)
        fail(409,"google_link_conflict")


'''
text = text.replace('def close_owned_session(db):\n', helper + 'def close_owned_session(db):\n', 1)
confirm_begin = text.index('    if existing is None:\n', text.index('def confirm('))
confirm_end = text.index('    return result\n', confirm_begin)
confirm_tail = text[confirm_begin:confirm_end]
text = text[:confirm_begin] + '    with _write_conflicts(db):\n' + ''.join('    ' + line if line.strip() else line for line in confirm_tail.splitlines(keepends=True)) + text[confirm_end:]
begin = text.index('    db.add(row)\n', text.index('def resolve_or_register('))
end = text.index('    return identity\n', begin)
old_tail = text[begin:end]
old_try = '''    try:
        db.flush()
    except IntegrityError:
        rollback(db)
        fail(409,"google_link_conflict")
'''
assert old_tail.count(old_try) == 1
tail = old_tail.replace(old_try, '    db.flush()\n', 1)
text = text[:begin] + '    with _write_conflicts(db):\n' + ''.join('    ' + line if line.strip() else line for line in tail.splitlines(keepends=True)) + text[end:]
ast.parse(text)
# The inverse recovers the complete preimage, including the old narrow catch.
inverse = text.replace('from contextlib import contextmanager\n', '', 1).replace(helper, '', 1)
for function, result in [('confirm', 'result'), ('resolve_or_register', 'identity')]:
    start = inverse.index('    with _write_conflicts(db):\n', inverse.index('def ' + function + '('))
    stop = inverse.index('    return ' + result + '\n', start)
    body = inverse[start + len('    with _write_conflicts(db):\n'):stop]
    body = ''.join(line[4:] if line.strip() else line for line in body.splitlines(keepends=True))
    if function == 'resolve_or_register':
        body = body.replace('    db.flush()\n', old_try, 1)
    inverse = inverse[:start] + body + inverse[stop:]
assert inverse.replace('\n', newline).encode('utf-8') == original
SERVICE.write_bytes(text.replace('\n', newline).encode('utf-8'))
(OUT / 'mutation.json').write_text(json.dumps({'service_before': entries['web/services/google_link.py']['sha256'], 'service_after': hashlib.sha256(SERVICE.read_bytes()).hexdigest(), 'full_inverse_exact': True, 'ast_parse': True}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'pinned': len(entries), 'full_inverse_exact': True}))
