from pathlib import Path, PurePosixPath
import ast
import hashlib
import io
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile

T=Path('C:/Users/Consu/AppData/Local/Temp')
R=Path('F:/mb-google33-conflict-window-20261019')
O=T/'metodobase-google33-conflict-author-20261019'
C=T/'metodobase-google33-conflict-seal-20261019'
PRIVATE=T/'metodobase-google33-conflict-private-20261019'
PUB=R/'docs/implementation/20261018-evolution/evidence/root-google33-conflict-author-20261019'
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda v:(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def git(*a):return subprocess.run(['git',*a],cwd=R,capture_output=True,check=True)
HEAD='8a5e5dc235e96a47488befb743fc02a24b491939'
assert git('rev-parse','HEAD').stdout.decode().strip()==HEAD
assert not git('status','--porcelain','-uno').stdout.strip()
assert not C.exists() and not PRIVATE.exists() and not PUB.exists()
C.mkdir()
freeze=json.loads((O/'product-freeze.json').read_bytes())
assert freeze['head']==HEAD and freeze['tracked_quiet']
for p,d in freeze['sources'].items():assert sha((R/p).read_bytes())==d
run=json.loads((O/'after-run.json').read_bytes())
assert run['pip_check_exit']==0 and all(run[k] for k in ['source_quiet','packages_quiet','python_quiet'])
def cases(name):
    found=ET.parse(O/name).findall('.//testcase')
    return [{'classname':n.get('classname'),'name':n.get('name'),'outcome':next((k for k in ['failure','error','skipped'] if n.find(k) is not None),'passed')} for n in found]
baseline=cases('before.xml');exact=cases('after-exact.xml');focal=cases('after-focal.xml');final=cases('after-final-framing.xml')
assert len(baseline)==4 and sum(x['outcome']=='failure' for x in baseline)==2 and sum(x['outcome']=='passed' for x in baseline)==2
for rows,n in [(exact,4),(focal,58),(final,4)]:assert len(rows)==n and all(x['outcome']=='passed' for x in rows)
assert {(x['classname'],x['name']) for x in baseline}=={(x['classname'],x['name']) for x in final}
raw={p.relative_to(O).as_posix():p.read_bytes() for p in O.rglob('*') if p.is_file()}
for name in ['prepare','run','finish','seal']:
    p=T/('metodobase-google33-conflict-'+name+'-20261019.py');raw['drivers/'+p.name]=p.read_bytes()
originals_before={n:sha(b) for n,b in raw.items() if not n.startswith('drivers/')}
acl_source=Path('F:/MetodoBaseWeb-execution-20261018/docs/implementation/20261018-evolution/evidence/root-mfa31-reviewed-serial-20261019/archive-acl.ps1')
acl=acl_source.read_text()
old="$names = @('serial-originals.zip')";new="$names = @('google33-conflict-originals.zip')"
assert acl.count(old)==1;acl=acl.replace(old,new,1)
(C/'archive-acl.ps1').write_text(acl,encoding='utf-8')
def protect(mode):
    p=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(C/'archive-acl.ps1'),'-Mode',mode,'-PrivateRoot',str(PRIVATE)],capture_output=True)
    (C/('acl-'+mode+'.stdout')).write_bytes(p.stdout);(C/('acl-'+mode+'.stderr')).write_bytes(p.stderr)
    assert p.returncode==0
    return json.loads(p.stdout.decode('utf-8-sig'))
protect('create');verified=protect('verify');assert verified['verified_before_payload']
archive=PRIVATE/'google33-conflict-originals.zip';assert archive.stat().st_size==0
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in raw.items():z.writestr(n,b)
with zipfile.ZipFile(archive) as z:assert set(z.namelist())==set(raw) and all(z.read(n)==b for n,b in raw.items())
closed=protect('final')
assert all(sha((O/n).read_bytes())==d for n,d in originals_before.items())
scan_def=next(n for n in ast.parse((T/'metodobase-checkpoint119-prepare.py').read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='scan')
exec(compile(ast.Module(body=[scan_def],type_ignores=[]),'scanner119','exec'))
# Full failed pytest output stays only in the protected original archive.
# Public case outcomes are derived from XML, with original hashes retained.
public_members={n:b for n,b in raw.items() if n not in {'before.xml','before.stdout','before.stderr'}}
public_members['baseline-cases.DERIVED.json']=enc({'original_before_xml_sha256':sha(raw['before.xml']),'cases':baseline,'failure_observation':'rollback-confirmed signup conflicts returned 503 instead of expected409 in both factories','private_originals_retained':True,'not_original_RAW':True})
for n,b in public_members.items():scan(b,n)
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in public_members.items():z.writestr(n,b)
summary={'product_head':HEAD,'before_cases':4,'before_passed':2,'before_failed':2,'after_exact_passed':4,'existing_focal_passed':58,'final_import_framing_passed':4,'overlapping_replays_not_added':True,'source_files_quiet':842,'packages':92,'pip_check_exit':0,'product_and_dependencies_quiet':True,'service_lint_existing_diagnostics_unchanged':8,'new_test_lint_exit':0,'postgres_race_acceptance':'pending independent peer','global_acceptance':False}
source={'product_head':HEAD,'products':freeze['sources'],'mutation':json.loads((O/'mutation.json').read_bytes()),'test_function_AST_unchanged':True,'test_framing_inverse_exact':True,'private_archive':{'basename':archive.name,'sha256':sha(archive.read_bytes()),'members':len(raw)},'private_ACL_before_payload':verified,'private_ACL_final':closed,'original_execution_directory_ACL_at_creation_attested':False,'originals_quiet':True,'original_files':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in raw.items()},'public_archive_original_members_exact_except_explicit_derived_baseline':True,'scanner119':'all public members and wrappers, not global gitleaks'}
review='''# Google33: colisiones durante flush previo al commit

Fuente 8a5e5dc235e96a47488befb743fc02a24b491939. El peer original halló
una carrera real de alta gym: 200+503 en vez de 200+409. La transacción sí
conservaba una cuenta, vínculo, perfil y cinco plantillas; no hubo adopción de
cuenta ni credenciales para el perdedor. El flush del perfil ocurría fuera del
catch estrecho. En confirm, autoflush True podía adelantar la misma colisión.

La frontera de IntegrityError ahora cubre todos los flush de ambas escrituras.
Sólo rollback confirmado permite409; incertidumbre de rollback permanece503.
Sin retry, relectura, adopción del ganador ni cambio de identidad, DTO o DDL.
La inversa completa recupera el servicio anterior. El test final conserva el
AST de su función original; sólo cambia el framing de importación de fixtures.

Baseline HTTP sintético de fallo de constraint: dos FAIL y dos PASS, mismos
cuatro casos por fábrica y disponibilidad de rollback. Corrección:4PASS;
58 regresiones existentes PASS; replay de framing final4PASS. Estos replays
se solapan y no se suman. Fuente842,92 paquetes y Python quietos,pip0.
Ruff del test0; los ocho diagnósticos preexistentes del servicio no aumentan.

Los originales fallidos completos quedan en archivo privado protegido antes
del payload y verificado tras readback. La tabla de casos pública es derivada,
no RAW; conserva los hashes originales. El directorio inicial no tiene
atestación retroactiva de ACL. No ejecutó SQL PostgreSQL ni prueba Google real.
La carrera multiproceso espera revisión independiente sobre este commit.
No cierra Google33, R05 global, CI o la release completa.
'''
public={'.gitattributes':b'* -text\n','author-evidence.zip':buf.getvalue(),'archive-acl.ps1':(C/'archive-acl.ps1').read_bytes(),'summary.json':enc(summary),'source.json':enc(source),'review.md':review.encode()}
for n,b in public.items():scan(b,n)
PUB.mkdir();(PUB/'.gitattributes').write_bytes(public.pop('.gitattributes'))
for n,b in public.items():(PUB/n).write_bytes(b)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in PUB.iterdir() if p.is_file()}
(PUB/'manifest.json').write_bytes(enc(manifest))
prefix=PUB.relative_to(R).as_posix()
git('-c','core.autocrlf=false','add','-f','--',prefix);git('diff','--cached','--check')
for p in PUB.iterdir():assert git('show',':'+p.relative_to(R).as_posix()).stdout==p.read_bytes()
git('commit','-m','Retain Google conflict regression baseline and fixed-source author evidence')
result={'head':git('rev-parse','HEAD').stdout.decode().strip(),'product_head':HEAD,'files':len(manifest)+1,'source_sha256':sha((PUB/'source.json').read_bytes()),'manifest_sha256':sha((PUB/'manifest.json').read_bytes()),'independent_peer_pending':True}
(C/'result.json').write_bytes(enc(result));print(json.dumps(result))
