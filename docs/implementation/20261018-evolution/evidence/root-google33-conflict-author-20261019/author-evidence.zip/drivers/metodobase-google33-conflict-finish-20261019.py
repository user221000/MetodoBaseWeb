from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

R=Path('F:/mb-google33-conflict-window-20261019')
O=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-google33-conflict-author-20261019')
P=Path(sys.executable)
RUFF=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-qa-20261018/Scripts/python.exe')
T=R/'tests/test_google33_conflict_window.py'
before=T.read_bytes();(O/'test-before-import-framing.py').write_bytes(before)
text=before.decode().replace('\r\n','\n')
old='from tests.test_google33_http import google_db, google_http  # noqa: F401\n'
new='from tests import test_google33_http as fixtures\n\ngoogle_db = fixtures.google_db\ngoogle_http = fixtures.google_http\n'
assert text.count(old)==1
text=text.replace(old,new,1)
old_model='    from web.database.models import AuthExternalIdentity, GymProfile, PlanSuscripcion, Usuario\n'
new_model='    from web.database.models import (\n        AuthExternalIdentity,\n        GymProfile,\n        PlanSuscripcion,\n        Usuario,\n    )\n'
assert text.count(old_model)==1
text=text.replace(old_model,new_model,1)
inverse=text.replace(new,old,1).replace(new_model,old_model,1)
assert inverse==before.decode().replace('\r\n','\n')
func=lambda s:ast.dump(next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)),include_attributes=False)
assert func(text)==func(before)
T.write_bytes(text.encode())
def run(name,args,stdin=None):
    out=O/(name+'.stdout');err=O/(name+'.stderr');assert not out.exists() and not err.exists()
    result=subprocess.run(args,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8'},input=stdin,capture_output=True)
    out.write_bytes(result.stdout);err.write_bytes(result.stderr)
    return result
lint=run('lint-test-final',[str(RUFF),'-m','ruff','check','tests/test_google33_conflict_window.py'])
assert lint.returncode==0
base=run('lint-service-before',[str(RUFF),'-m','ruff','check','--output-format=json','--stdin-filename','web/services/google_link.py','-'],(O/'before-source/web/services/google_link.py').read_bytes())
after=run('lint-service-after',[str(RUFF),'-m','ruff','check','--output-format=json','web/services/google_link.py'])
keys=lambda b:sorted((x['code'],x['message']) for x in json.loads(b))
assert keys(base.stdout)==keys(after.stdout)
source_before={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in ['web/services/google_link.py','tests/test_google33_conflict_window.py']}
case=run('after-final-framing',[str(P),'-m','pytest','-q','tests/test_google33_conflict_window.py','--junitxml='+str(O/'after-final-framing.xml')])
assert case.returncode==0
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==d for p,d in source_before.items())
def git(*args):return subprocess.run(['git',*args],cwd=R,capture_output=True,check=True)
assert git('diff','--cached','--name-only').stdout==b''
git('-c','core.autocrlf=false','add','--',*source_before)
git('diff','--cached','--check')
for p in source_before:assert git('show',':'+p).stdout==(R/p).read_bytes()
assert set(git('diff','--cached','--name-only').stdout.decode().splitlines())==set(source_before)
done=git('commit','-m','Classify Google identity constraint races across all write flushes')
(O/'product-commit.stdout').write_bytes(done.stdout);(O/'product-commit.stderr').write_bytes(done.stderr)
result={'head':git('rev-parse','HEAD').stdout.decode().strip(),'sources':source_before,'test_full_function_AST_unchanged':True,'test_framing_full_inverse_exact':True,'service_lint_diagnostics_unchanged_from_baseline':True,'service_lint_existing_count':len(json.loads(base.stdout)),'new_test_lint_exit':lint.returncode,'final_exact_fault_exit':case.returncode,'tracked_quiet':not git('status','--porcelain','--untracked-files=no').stdout.strip()}
(O/'product-freeze.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
