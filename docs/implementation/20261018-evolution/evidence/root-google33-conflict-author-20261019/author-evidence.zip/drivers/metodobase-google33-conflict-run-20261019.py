"""Run the fixed-source author checks without changing dependencies or services."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('F:/mb-google33-conflict-window-20261019')
OUT = Path('C:/Users/Consu/AppData/Local/Temp/metodobase-google33-conflict-author-20261019')
PYTHON = Path(sys.executable)
tracked = subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
paths = sorted({p for p in tracked if p and not p.startswith(('docs/','.git/')) and Path(p).suffix.lower() in {'.py','.js','.html','.css','.txt','.toml','.ini','.yml','.yaml','.json','.lock','.cfg'}} | {'tests/test_google33_conflict_window.py'})
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def snapshot():
    return {p:sha(ROOT/p) for p in paths if (ROOT/p).is_file()}
def packages():
    done=subprocess.run([str(PYTHON),'-m','pip','list','--format=json','--disable-pip-version-check'],capture_output=True,cwd=ROOT,check=True)
    return json.loads(done.stdout)
assert not (OUT/'after-run.json').exists()
before={'source':snapshot(),'packages':packages(),'python_sha256':sha(PYTHON),'version':sys.version}
(OUT/'after-run-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
results=[]
env=os.environ.copy()
env.update({'PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
for phase, arguments in [
    ('after-exact',['tests/test_google33_conflict_window.py']),
    ('after-focal',['tests/test_google33_http.py','tests/test_google33_recovery.py','tests/test_google33_association_security.py','tests/test_google33_identity_contract.py','tests/test_google33_mfa_reauth_contract.py']),
]:
    start=time.monotonic()
    with (OUT/(phase+'.stdout')).open('xb') as stdout, (OUT/(phase+'.stderr')).open('xb') as stderr:
        args=[str(PYTHON),'-m','pytest','-q',*arguments,'--junitxml='+str(OUT/(phase+'.xml'))]
        done=subprocess.run(args,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
    result={'phase':phase,'argv':args,'exit_code':done.returncode,'elapsed_seconds':time.monotonic()-start}
    results.append(result)
    print(json.dumps(result),flush=True)
    if done.returncode: break
with (OUT/'pip-check.stdout').open('xb') as stdout, (OUT/'pip-check.stderr').open('xb') as stderr:
    pip=subprocess.run([str(PYTHON),'-m','pip','check'],cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
after={'source':snapshot(),'packages':packages(),'python_sha256':sha(PYTHON),'version':sys.version}
(OUT/'after-run-after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
summary={'results':results,'pip_check_exit':pip.returncode,'source_files':len(before['source']),'source_quiet':before['source']==after['source'],'packages_quiet':before['packages']==after['packages'],'python_quiet':before['python_sha256']==after['python_sha256']}
(OUT/'after-run.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary),flush=True)
assert all(r['exit_code']==0 for r in results) and pip.returncode==0
assert summary['source_quiet'] and summary['packages_quiet'] and summary['python_quiet']
