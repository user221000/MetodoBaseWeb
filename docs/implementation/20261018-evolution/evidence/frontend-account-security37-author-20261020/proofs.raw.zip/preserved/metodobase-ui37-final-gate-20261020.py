"""Frozen own-account UI37 local author gate. No browser, PG or provider I/O."""
from pathlib import Path
import hashlib,importlib.metadata,json,os,subprocess,time,xml.etree.ElementTree as ET
ROOT=Path('F:/mb-followup-actions-ui-20261019');OUT=Path(os.environ['TEMP'])/'metodobase-ui37-final-gate-20261020';SHA=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git','-c','core.autocrlf=false',*args],cwd=ROOT)
HEAD=git('rev-parse','HEAD').decode().strip();assert HEAD.startswith('a994ef84')and not git('status','--porcelain','-uno').strip()and not OUT.exists();OUT.mkdir()
def photo():return{p:SHA((ROOT/p).read_bytes())for p in git('ls-files').decode().splitlines()if not p.startswith('docs/')and(ROOT/p).is_file()}
def packages():return sorted((d.metadata['Name'],d.version)for d in importlib.metadata.distributions())
before,dist=photo(),packages();started=time.monotonic();reports=[];env=os.environ.copy();env['NODE_OPTIONS']='--require='+str(ROOT/'tests/e2e/browser_offline31.cjs').replace('\\','/')
def run(label,command,timeout=40):
 result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=timeout);(OUT/(label+'.stdout.raw')).write_bytes(result.stdout);(OUT/(label+'.stderr.raw')).write_bytes(result.stderr)
 assert result.returncode==0,(label,result.stdout[-1800:],result.stderr[-500:]);return result
for label,file,total in [('transport','account_security37_transport.cjs',19),('state','account_security37_state.cjs',12),('dom','account_security37_dom.cjs',10),('session','browser_session31.cjs',55),('reminder-state','notifications36_state.cjs',19),('reminder-dom','notifications36_dom.cjs',8),('reminder-nav','notifications36_nav.cjs',9)]:
 command=['node','tests/e2e/'+file];report=json.loads(run(label,command).stdout);assert report['passed']==report['total']==total
 reports.append({'command':command,'passed':total,'total':total,'case_names':[row['case']for row in report['results'if'results'in report else'rows']]})
python='C:/Users/Consu/AppData/Local/Temp/metodobase-google33-author-aamidzkr/venv/Scripts/python.exe'
run('HTTP37',[python,'-m','pytest','-q','tests/test_account_security37_ui.py','--disable-warnings','--tb=short','--junitxml',str(OUT/'http37.xml')],120)
run('SSR36',[python,'-m','pytest','-q','tests/test_notifications36_ui.py','-k','not actual_controller','--disable-warnings','--tb=short','--junitxml',str(OUT/'ssr36.xml')],70)
http=[]
for name,total in [('http37.xml',10),('ssr36.xml',6)]:
 cases=ET.parse(OUT/name).findall('.//testcase');assert len(cases)==total and not any(c.find(t)is not None for c in cases for t in['failure','error','skipped']);http.extend(c.attrib['classname']+'::'+c.attrib['name']for c in cases)
run('pip',[python,'-m','pip','check'])
ruff='C:/Users/Consu/AppData/Local/Temp/metodobase-qa-20261018/Scripts/python.exe';run('ruff',[ruff,'-m','ruff','check','tests/test_account_security37_ui.py','web/account_security_paths.py','web/routes/pages.py'])
syntax=['web/static/js/api.js','web/static/js/account-security37.js','tests/e2e/account_security37_transport.cjs','tests/e2e/account_security37_state.cjs','tests/e2e/account_security37_dom.cjs','tests/e2e/account_security37_http_worker.cjs']
for index,path in enumerate(syntax):run('syntax-'+str(index),['node','--check',path])
base='a40d1db8dd5124e167d39270abd40f573b9dee61';raw=(ROOT/'web/static/js/api.js').read_bytes();start=raw.index(b'  // Own account37 operations.');end=raw.index(b'  const billing = {',start);assert(raw[:start]+raw[end:]).replace(b'accountSecurity, ',b'',1)==git('show',base+':web/static/js/api.js')
raw=(ROOT/'web/middleware/security_headers.py').read_bytes().replace(b'_ACCOUNT_SECURITY_PAGES = frozenset({"/cuenta/seguridad", "/cuenta/seguridad/", "/mi-seguridad", "/mi-seguridad/"})\n',b'',1).replace(b' or request.url.path in _ACCOUNT_SECURITY_PAGES',b'',1);assert raw==git('show',base+':web/middleware/security_headers.py')
assert photo()==before and packages()==dist and git('rev-parse','HEAD').decode().strip()==HEAD
result={'head':HEAD,'source_quiet':True,'sources':before,'source_count':len(before),'packages':dist,'distributions':len(dist),'Node_commands':reports,'Node_executions':sum(row['passed']for row in reports),'HTTP_cases':http,'HTTP_passed':len(http),'API_and_GIS_full_RAW_inverse_equals_composed_base':True,'Ruff':0,'syntax_files':syntax,'pip_check':True,'seconds':round(time.monotonic()-started,3),'scope':'Current37 real ASGI/SQLite with browser cookie/MFA/CSRF and SDK doubles, Node VM and minimal DOM; no Chrome, real OAuth/provider, native a11y/layout or PostgreSQL claim.'}
(OUT/'gate.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf8');print(json.dumps({k:result[k]for k in['head','source_quiet','source_count','distributions','Node_executions','HTTP_passed','Ruff','pip_check','seconds','scope']}))
