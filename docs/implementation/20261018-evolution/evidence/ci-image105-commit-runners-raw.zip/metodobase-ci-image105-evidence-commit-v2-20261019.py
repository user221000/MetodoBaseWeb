import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root=Path('F:/MetodoBaseWeb-execution-20261018')
run=root/'docs/implementation/20261018-evolution'
ev=run/'evidence'
temp=Path('C:/Users/Consu/AppData/Local/Temp')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip().startswith('52af400')
folders=['history-landing-ci-independent-20261019','history-landing-main-ci-review-20261019','linux-recovery28-image-bc365c1','linux-owned-shutdown-20261019']
docs=['TRAZABILIDAD.json','TRAZABILIDAD.md','ESTADO.md','VALIDACION.md','CAMBIOS.md','ENTREGA.md']
# These are new proof folders only: preserve RAW .sh bytes despite the repository's
# source-entrypoint *.sh text/eol=lf rule. No historical attributes or proofs change.
for name in folders:
    p=ev/name/'.gitattributes';assert not p.exists()
    p.write_bytes(b'# Preserve original bytes in this new evidence directory only.\n* -text\n')
bundle=ev/'ci-image105-commit-runners-raw.zip';assert not bundle.exists()
with zipfile.ZipFile(bundle,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in [temp/'metodobase-ci-image105-evidence-commit-20261019.py',Path(__file__)]:z.writestr(p.name,p.read_bytes())
raw=[ev/'ci-image105-evidence-commit-driver.py',bundle]
for name in folders:raw.extend(p for p in (ev/name).rglob('*') if p.is_file())
names=sorted(p.relative_to(root).as_posix() for p in raw)
for start in range(0,len(names),25):subprocess.run(['git','-c','core.autocrlf=false','add','-f','--',*names[start:start+25]],cwd=root,check=True,capture_output=True)
buf=subprocess.check_output(['git','cat-file','--batch'],cwd=root,input=''.join(':'+n+'\n' for n in names).encode())
pos=0;digests={}
for name in names:
    e=buf.index(b'\n',pos);header=buf[pos:e].split();assert header[1]==b'blob'
    size=int(header[2]);blob=buf[e+1:e+1+size];pos=e+size+2
    assert blob==(root/name).read_bytes(),name
    digests[name]=sha(blob)
assert pos==len(buf)
for name,manifest_name,expected in [('history-landing-ci-independent-20261019','final-manifest.json','6128847cb3384252e3f8fe3310a1df6a0050403004ec8a71d245d0f8b6967205'),('linux-recovery28-image-bc365c1','evidence-manifest.json','15ff83b09c2340195de8677977ce0d9bd4c7e8cc238c7da2607484d63f71b566')]:
    folder=ev/name;assert sha((folder/manifest_name).read_bytes())==expected
    files=json.loads((folder/manifest_name).read_text(encoding='utf-8'))['files']
    for relative,value in files.items():assert sha((folder/relative).read_bytes())==(value if isinstance(value,str) else value['sha256'])
docpaths=[(run/n).relative_to(root).as_posix() for n in docs]
subprocess.run(['git','diff','--cached','--check','--',*docpaths],cwd=root,check=True)
receipt=ev/'ci-image105-raw-preservation.json';assert not receipt.exists()
receipt.write_text(json.dumps({'new_raw_files':len(names),'git_index_bytes_match_all':True,'pair_hashes_sha256':sha(json.dumps(digests,sort_keys=True,separators=(',',':')).encode()),'qa_manifest_rehashed':150,'image_manifest_rehashed':53,'historical_criteria_preserved':104,'prep_erratum':'First helper stopped before commit because root *.sh text eol=lf normalized a RAW proof shell script even with core.autocrlf=false. Original helper retained. Added scoped -text attributes only to these four new proof folders and restaged; all original manifests and every raw/index pair now match. No product, tests, historical proof or criterion changed.','attributes_scope':folders,'scope':'Original evidence bytes retained, including QA bytecode listed by the frozen manifest. New scoped .gitattributes files are coordinator packaging metadata outside author manifests. Docs whitespace checked separately.'},indent=2)+'\n',encoding='utf-8')
subprocess.run(['git','-c','core.autocrlf=false','add','--',receipt.relative_to(root).as_posix()],cwd=root,check=True,capture_output=True)
assert subprocess.check_output(['git','show',':'+receipt.relative_to(root).as_posix()],cwd=root)==receipt.read_bytes()
staged=set(subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1])
assert staged==set(names+docpaths+[receipt.relative_to(root).as_posix()])
subprocess.run(['git','commit','-m','docs: accept CI composition and preserve final Linux OS comparison'],cwd=root,check=True,capture_output=True)
print(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'raw_files':len(names),'all_raw_index_identical':True,'registry':104}))
