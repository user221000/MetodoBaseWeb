/* R25 DTO normalization. Only fixed contracts are accepted; unknown fields fail closed. */
(() => {
  'use strict';
  const invalid=()=>Object.assign(new Error('Los datos recibidos requieren revisión. No se muestran cifras sustitutas.'),{code:'progress_response_unavailable'});
  function object(value){if(!value||typeof value!=='object'||Array.isArray(value))throw invalid();return value;}
  function keys(value,names){object(value);if(Object.keys(value).length!==names.length||names.some(key=>!Object.hasOwn(value,key)))throw invalid();return value;}
  function day(value){try{ProgresoDatos.date(value);}catch{throw invalid();}return value;}
  function uuid(value){if(typeof value!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value))throw invalid();return value;}
  function boolean(value){if(typeof value!=='boolean')throw invalid();return value;}
  function bounded(value){try{if(new TextEncoder().encode(JSON.stringify(value)).byteLength>262144)throw invalid();}catch{throw invalid();}return value;}
  function context(input){
    const data=keys(bounded(input),['today','timezone','profiles','capabilities','source_profile_required']);
    day(data.today);if(data.timezone!=='America/Mexico_City'||data.source_profile_required!==true)throw invalid();
    const profiles=keys(data.profiles,['items','next_after']),capabilities=keys(data.capabilities,['record_measurements','manage_consent','share_reciprocally']);
    if(!Array.isArray(profiles.items)||capabilities.share_reciprocally!==false)throw invalid();
    const seen=new Set(),items=profiles.items.map(value=>{
      const profile=keys(value,['id','display_name','active','can_record']),id=uuid(profile.id);
      if(seen.has(id)||typeof profile.display_name!=='string'||!profile.display_name.trim()||profile.display_name.length>1024)throw invalid();seen.add(id);
      const active=boolean(profile.active),canRecord=boolean(profile.can_record);if(canRecord&&!active)throw invalid();
      return Object.freeze({id,displayName:profile.display_name,active,canRecord});
    });
    const nextAfter=profiles.next_after===null?null:uuid(profiles.next_after);if(nextAfter!==null&&!items.length)throw invalid();
    return Object.freeze({today:data.today,timezone:data.timezone,sourceProfileRequired:true,profiles:Object.freeze({items:Object.freeze(items),nextAfter}),capabilities:Object.freeze({recordMeasurements:boolean(capabilities.record_measurements),manageConsent:boolean(capabilities.manage_consent),shareReciprocally:false})});
  }
  function completion(input){
    const data=keys(bounded(input),['today','timezone','from_date','through_date','basis','items']);
    day(data.today);if(data.timezone!=='America/Mexico_City'||data.basis!=='completed_of_registered_snapshots'||!Array.isArray(data.items))throw invalid();
    try{ProgresoDatos.queryRange(data.from_date,data.through_date,data.today);}catch{throw invalid();}
    if(!data.from_date||!data.through_date)throw invalid();const seen=new Set();let previous=null;
    const rows=data.items.map(value=>{
      const item=keys(value,['local_date','registered_snapshots','completed_snapshots','ratio','status']),localDate=day(item.local_date);
      if(seen.has(localDate)||localDate<data.from_date||localDate>data.through_date||(previous!==null&&localDate<=previous))throw invalid();seen.add(localDate);previous=localDate;
      let observed;try{observed=ProgresoDatos.observed(item.completed_snapshots,item.registered_snapshots);}catch{throw invalid();}
      if(item.ratio!==observed.ratio||item.status!==(observed.registered===0?'no_registered_snapshots':'observed'))throw invalid();
      return Object.freeze({localDate,registered:observed.registered,completed:observed.completed,ratio:observed.ratio,status:item.status});
    });
    return Object.freeze({today:data.today,timezone:data.timezone,fromDate:data.from_date,throughDate:data.through_date,rows:Object.freeze(rows)});
  }
  window.ProgresoRespuestas=Object.freeze({context,completion});
})();
