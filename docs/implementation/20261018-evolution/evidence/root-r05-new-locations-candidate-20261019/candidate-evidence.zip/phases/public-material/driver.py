from pathlib import Path
import hashlib
import json
import re
import urllib.request

ROOT=Path('F:/mb-r05-review-classifier-20261019')
TMP=Path('C:/Users/Consu/AppData/Local/Temp')
MAIN=Path('F:/MetodoBaseWeb-execution-20261018')
OUT=TMP/'metodobase-r05-current-public-material-triage-20261019';OUT.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=json.loads((TMP/'metodobase-r05-current-objectid-triage-20261019/unclassified-locations.json').read_bytes())
peer=MAIN/'docs/implementation/20261018-evolution/evidence/security-gitleaks-triage-independent-20261019'
keyproof=json.loads((peer/'public-key-proof.STRUCTURAL.json').read_bytes())
key=(MAIN/keyproof['retained_path']).read_bytes()
assert sha(key)==keyproof['retained_key_sha256']=='1de2bbd31e2dd10aab4098c3ab2f937c530d924ddbfa2dd091f0c7cfb2ee182a'
fingerprint='7169605F62C751356D054A26A821E680E5FA6305'
assert keyproof['public_primary_fingerprints']==[fingerprint]
url='https://raw.githubusercontent.com/python/cpython/v3.12.13/Include/internal/pycore_token.h'
request=urllib.request.Request(url,headers={'User-Agent':'MetodoBase local checksum review'})
with urllib.request.urlopen(request,timeout=15) as response:
    assert response.status==200 and response.geturl()==url
    header=response.read(65537);assert len(header)<=65536
(OUT/'pycore_token.h.downloaded-public').write_bytes(header)
header_digest=sha(header)
classified=[];remaining=[];cache={}
for row in rows:
    name=row['file']
    if name not in cache:
        raw=(ROOT/name).read_bytes();assert sha(raw)==row['file_sha256']
        enc='utf-16' if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig'
        cache[name]=raw.decode(enc).split('\n')
    line=cache[name][row['line']-1]
    public_key=re.fullmatch(r'\s*"GPG_KEY=([A-F0-9]{40})",?\s*',line)
    public_header=re.fullmatch(r'\s*"/usr/local/include/python3\.12/internal/pycore_token\.h"\s*:\s*"([a-f0-9]{64})",?\s*',line)
    proof=None
    if public_key and public_key[1]==fingerprint:
        proof={'kind':'exact public signing-key fingerprint, not a private key or credential',
            'reused_independent_proof_digest':sha((peer/'public-key-proof.STRUCTURAL.json').read_bytes()),
            'retained_public_key_digest':sha(key),'official_linked_source':keyproof['official_linked_public_key'],
            'scope':'reuses prior verified public packet identity; no new signature verification or key import'}
    elif public_header and public_header[1]==header_digest:
        proof={'kind':'complete metadata checksum of public CPython header bytes','public_source_url':url,
            'downloaded_public_bytes':len(header),'downloaded_public_digest':header_digest,
            'scope':'current public source preimage only; does not reconstruct or re-attest an earlier container build'}
    if proof:
        classified.append({**row,'physical_line_sha256':sha(line.encode()),'proof':proof})
    else:remaining.append(row)
for name,value in [('classified.json',classified),('unclassified-locations.json',remaining)]:
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
(OUT/'driver.py').write_bytes(Path(__file__).read_bytes())
summary={'input':len(rows),'candidate_verified_public_material':len(classified),'remaining':len(remaining),
    'public_fingerprint_locations':sum(r['proof']['kind'].startswith('exact public') for r in classified),
    'public_header_checksum_locations':sum(r['proof']['kind'].startswith('complete metadata') for r in classified),
    'public_header_digest':header_digest,'source_url':url,'independent_new_review':False,'global_R05_acceptance':False}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary))
