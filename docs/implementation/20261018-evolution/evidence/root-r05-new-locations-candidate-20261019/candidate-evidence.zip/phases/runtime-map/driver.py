from pathlib import Path
from collections import defaultdict
import ast
import hashlib
import json
import re
import subprocess

ROOT=Path('F:/mb-r05-review-classifier-20261019')
TMP=Path('C:/Users/Consu/AppData/Local/Temp')
OUT=TMP/'metodobase-r05-current-runtime-map-triage-20261019';OUT.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git','--no-replace-objects',*args],cwd=ROOT)
rows=json.loads((TMP/'metodobase-r05-current-public-material-triage-20261019/unclassified-locations.json').read_bytes())
maps={};line_digests={}
for name in sorted({r['file'] for r in rows}):
    raw=(ROOT/name).read_bytes();assert all(sha(raw)==r['file_sha256'] for r in rows if r['file']==name)
    if name.endswith('/drivers/runtime_probe.py.txt'):
        tree=ast.parse(raw)
        assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='EXPECTED_APP')
        value=ast.literal_eval(assignment.value);maps[name,assignment.lineno]=value
        line_digests[name,assignment.lineno]=sha(raw.split(b'\n')[assignment.lineno-1])
    elif name.endswith('/server.stdout.raw.log'):
        raw_lines=raw.split(b'\n');entry=json.loads(raw_lines[0]);value=entry['runtime_raw_sha256']
        maps[name,1]=value;line_digests[name,1]=sha(raw_lines[0])
for mapping in maps.values():
    assert isinstance(mapping,dict) and len(mapping) in {299,355}
    assert all(isinstance(k,str) and not k.startswith('/') and '\\' not in k and ':' not in k
        and all(x not in {'','.','..'} for x in k.split('/')) and isinstance(v,str) and re.fullmatch('[a-f0-9]{64}',v) for k,v in mapping.items())
wanted={path for mapping in maps.values() for path in mapping}
commits=git('rev-list','--all').decode().splitlines()
raw_log=git('log','-m','--raw','--no-abbrev','--no-renames','-z','--format=',*commits,'--','.',':!docs/**')
chunks=raw_log.split(b'\0');objects=defaultdict(set);index=0
while index<len(chunks):
    metadata=chunks[index].lstrip(b'\n')
    if not metadata:index+=1;continue
    assert metadata.startswith(b':');fields=metadata[1:].split();assert len(fields)==5
    path=chunks[index+1].decode()
    if path in wanted:
        for mode,oid in [(fields[0],fields[2]),(fields[1],fields[3])]:
            if mode in {b'100644',b'100755'} and oid!=b'0'*40:objects[oid.decode()].add(path)
    index+=2
proofs={}
process=subprocess.Popen(['git','--no-replace-objects','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:
    for oid,paths in objects.items():
        process.stdin.write((oid+'\n').encode());process.stdin.flush()
        header=process.stdout.readline().decode().split();assert len(header)==3 and header[:2]==[oid,'blob']
        content=process.stdout.read(int(header[2]));assert len(content)==int(header[2]) and process.stdout.read(1)==b'\n'
        variants={'Git_blob_bytes':content}
        try:
            content.decode('utf-8')
            if b'\0' not in content and b'\n' in content and b'\r\n' not in content:
                variants['DERIVED_GitLF_to_CRLF_checksum_not_execution_RAW']=content.replace(b'\n',b'\r\n')
        except UnicodeError:pass
        for kind,payload in variants.items():
            digest=sha(payload)
            for path in paths:proofs[path,digest]={'Git_blob_oid':oid,'derivation':kind,'digest':digest}
finally:
    process.stdin.close();assert process.wait(timeout=30)==0 and not process.stderr.read()
map_witnesses=[];accepted=set()
for (name,number),mapping in maps.items():
    missing=[path for path,digest in mapping.items() if (path,digest) not in proofs]
    witness={'file':name,'line':number,'pairs':len(mapping),'verified':len(mapping)-len(missing),'missing_paths':missing,
        'physical_line_digest':line_digests[name,number],
        'proofs':{path:proofs[path,digest] for path,digest in mapping.items() if (path,digest) in proofs}}
    map_witnesses.append(witness)
    if not missing:accepted.add((name,number))
classified=[];remaining=[]
for row in rows:
    coordinate=row['file'],row['line']
    if coordinate in accepted:
        classified.append({**row,'physical_line_sha256':line_digests[coordinate],
            'reason':'complete typed source-checksum map: every path/value pair independently recomputed from public Git blob bytes or explicitly derived CRLF checksum; not reconstructed execution RAW'})
    else:remaining.append(row)
for name,value in [('classified.json',classified),('unclassified-locations.json',remaining),('map-witnesses.json',map_witnesses),('pinned-commits.json',commits)]:
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
(OUT/'driver.py').write_bytes(Path(__file__).read_bytes())
summary={'input':len(rows),'candidate_complete_runtime_map_locations':len(classified),'remaining':len(remaining),
    'maps':[{'file':w['file'],'pairs':w['pairs'],'verified':w['verified'],'missing':len(w['missing_paths'])} for w in map_witnesses],
    'public_blobs_examined':len(objects),'pinned_commits':len(commits),'independent_new_review':False,'global_R05_acceptance':False}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps(summary))
