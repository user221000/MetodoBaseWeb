from pathlib import Path

prior=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r05-candidate-seal-20261019.py')
source=prior.read_text()
replacements=[
    ('assert not P.exists() and not C.exists();C.mkdir()','assert not P.exists() and C.is_dir() and not list(C.iterdir())'),
    ("physical=sha(lines[n-1]);assert row['physical_line_sha256']==physical", "physical=sha(lines[n-1]);assert row.get('physical_line_sha256',physical)==physical"),
    ("for name in drivers:\n", "drivers.append('metodobase-r05-candidate-seal-v2-20261019.py')\nfor name in drivers:\n"),
    ("'candidate_unresolved':0,'phases':phases", "'candidate_unresolved':0,'physical_pins_recomputed_from_report_exact_files':True,'prior_rows_without_explicit_physical_digest':sum('physical_line_sha256' not in row for row in rows),'phases':phases"),
]
revised=source
for old,new in replacements:
    assert revised.count(old)==1;revised=revised.replace(old,new,1)
inverse=revised
for old,new in reversed(replacements):inverse=inverse.replace(new,old,1)
assert inverse==source
exec(compile(revised,str(prior)+':v2_recompute_missing_phase_pin','exec'),{'__name__':'__main__','__file__':str(prior)})
