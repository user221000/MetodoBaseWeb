"""Seal read-only triage candidates; do not change the installed classifier."""
from pathlib import Path, PurePosixPath
from collections import Counter, defaultdict
import ast
import hashlib
import io
import json
import re
import subprocess
import tarfile
import zipfile

T=Path('C:/Users/Consu/AppData/Local/Temp')
R=Path('F:/mb-r05-review-classifier-20261019')
P=R/'docs/implementation/20261018-evolution/evidence/root-r05-new-locations-candidate-20261019'
C=T/'metodobase-r05-new-locations-seal-20261019'
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda v:(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def git(*a):return subprocess.run(['git',*a],cwd=R,capture_output=True,check=True)
BASE='57a036568ac74b7480cca8d4b3af0f79863ba879'
assert git('rev-parse','HEAD').stdout.decode().strip()==BASE
assert not git('status','--porcelain','-uno').stdout.strip()
assert not P.exists() and not C.exists();C.mkdir()
report_path=T/'metodobase-r05-reviewed-author-20261019/current-tree-scan.json'
report_raw=report_path.read_bytes();assert sha(report_raw)=='f273556e34d1796de1f8a01e17d58842be82c7a6ab2173bdeabb1a2d91714f8d'
report=json.loads(report_raw)
assert report['source_stable'] and not report['changed_files'] and len(report['findings'])==14557
names=[('fingerprint',5234),('historical',3918),('artifact',1546),('evidence-v2',3282),('objectid',499),('public-material',15),('runtime-map',48),('final15',15)]
phase_paths={name:T/('metodobase-r05-current-'+name+'-triage-20261019') for name,_ in names}
phase_paths['evidence-v2']=T/'metodobase-r05-current-evidence-triage-v2-20261019'
raw={};rows=[];phases=[]
for name,count in names:
    directory=phase_paths[name]
    candidates=json.loads((directory/'classified.json').read_bytes());assert len(candidates)==count
    for row in candidates:rows.append({**row,'candidate_phase':name})
    files=[p for p in directory.iterdir() if p.is_file()]
    for p in files:
        if p.name.endswith('.downloaded-public'):continue
        raw['phases/'+name+'/'+p.name]=p.read_bytes()
    phases.append({'phase':name,'candidates':count,'files':len(files)})
identity=lambda row:(row['file'],row['line'],row['rule'],row['file_sha256'],row['fingerprint'])
assert Counter(map(identity,rows))==Counter(map(identity,report['findings']))
by_file=defaultdict(list)
for row in rows:by_file[row['file']].append(row)
records=[];quiet={}
for name,items in sorted(by_file.items()):
    payload=(R/name).read_bytes();digest=sha(payload)
    assert digest==report['files'][name] and all(row['file_sha256']==digest for row in items)
    transform=report['encoding_transforms'].get(name)
    text=payload.decode(transform['source_encoding'] if transform else 'utf-8')
    scan_bytes=text.encode('utf-8');lines=scan_bytes.split(b'\n')
    coordinates={}
    for row in items:
        n=row['line'];assert type(n)is int and 0<n<=len(lines)
        physical=sha(lines[n-1]);assert row['physical_line_sha256']==physical
        coordinates[n,row['rule']]=physical
    groups=defaultdict(list)
    for (n,rule),digest_line in coordinates.items():groups[n,digest_line].append(rule)
    records.append({'path':name,'source_digest':digest,'scanner_digest':sha(scan_bytes),'lines':[{'number':n,'digest':d,'rules':sorted(rules)} for (n,d),rules in sorted(groups.items())]})
    quiet[name]=digest
dataset={'schema':1,'version':'8.30.1','config_digest':'fade668c58cf3310a4bde299c32c051cd271bf2cf648634bf45e67d19a372099','files':records}
assert sha((R/'.gitleaks.toml').read_bytes())==dataset['config_digest']
ledger_bytes=enc(dataset)
assert len(ledger_bytes)<16*1024*1024
ledger=io.BytesIO()
with zipfile.ZipFile(ledger,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('reviewed-locations.json',ledger_bytes)
raw['candidate-reviewed-locations.json']=ledger_bytes
raw['candidate-rows.json']=enc(rows)
drivers=['metodobase-r05-current-triage-prepare-20261019.py','metodobase-r05-current-evidence-triage-20261019.py','metodobase-r05-current-evidence-triage-v2-20261019.py','metodobase-r05-current-sha1-and-shape-20261019.py','metodobase-r05-last15-public-lookup-20261019.py','metodobase-r05-last15-public-lookup-v2-20261019.py','metodobase-r05-last15-classify-20261019.py','metodobase-r05-last15-classify-v2-20261019.py']
for name in drivers:
    path=T/name
    if path.is_file():raw['drivers/'+name]=path.read_bytes()
raw['drivers/seal.py']=Path(__file__).read_bytes()
raw['limits-and-attempts.json']=enc({'original_failed_driver_attempts':'First evidence v1 rejected absolute Git pathspec; public lookup v1 did not decode UTF16; final15 v1 assumed distinct digests for optional settings. Their code/preimages are retained. Initial failures were tool output only, not captured RAW files; no retrospective RAW execution claim. V2 drivers make explicit reversible framing changes.','historical_checksums':'Derived LF-to-CRLF checksums are not reconstructed execution RAW.','public_header':'Only fixed primary URL and checksum witness retained; full CPython header not republished.','configuration_hashes':'Producer AST/source receipt and seven equal copied digest entries proven; nine setting-digest locations. Original private configuration values not reconstructed.','installed_registry_changed':False,'independent_review_complete':False})
definition=next(n for n in ast.parse((T/'metodobase-checkpoint119-prepare.py').read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='scan')
exec(compile(ast.Module(body=[definition],type_ignores=[]),'scanner119','exec'))
for name,blob in raw.items():scan(blob,name)
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
    for name,blob in raw.items():z.writestr(name,blob)
unique=sum(len(line['rules']) for record in records for line in record['lines'])
summary={'source':BASE,'report_source':'17c9b836776d8ebe51b619ab2b552fafab51f4de','report_digest':sha(report_raw),'raw_report_findings':42830,'previously_classified':28273,'new_candidate_occurrences':len(rows),'new_candidate_unique_pins':unique,'new_candidate_files':len(records),'candidate_unresolved':0,'phases':phases,'installed_registry_v1_changed':False,'independent_review_complete':False,'global_R05_acceptance':False,'new_full_current33_scan_executed':False}
source={'source':BASE,'candidate_dataset_digest':sha(ledger.getvalue()),'candidate_dataset_bytes':len(ledger.getvalue()),'candidate_data_schema':1,'candidate_data_member':'reviewed-locations.json','manifest_of_original_members':[{'path':n,'bytes':len(b),'digest':sha(b)} for n,b in raw.items()],'source_files_quiet':quiet,'limits':'See limits-and-attempts.json inside candidate-evidence.zip. All eight phase classification rows preserve original bytes; cumulative candidate-rows.json only adds phase labels. No scanner suppression installed.','strong_scanner':'scanner119 recursively checked public members; not a fresh gitleaks run.'}
review='''# Candidatos finitos para el informe R05 de17c9

Los14.557 bloqueantes del informe fijado tienen ahora testigo candidato: archivo
público actual, blob histórico, derivación CRLF explícita, miembro de ZIP público,
objeto Git, material público de firma, mapa de fuentes íntegro o productor puro
de SHA256. Los pins conservan archivo RAW, línea física (incluido CR), regla y
digest de la línea. Se comprobaron todas las ocurrencias contra el mismo informe.

Las últimas15 incluyen nueve digests de configuración. Se verifica el AST exacto
del productor y su hash en tres recibos originales; sólo se ejecuta esa función
pura con dependencias sintéticas. Los siete valores digest copiados concuerdan.
No se reconstruyen ni revelan valores privados. Cuatro ubicaciones son hashes
de informes VM retenidos byte a byte; otra es checksum de clave pública y otra
contiene dos checksums de recibos públicos. Nunca se ejecutan drivers históricos.

La clasificación es candidata, fuera del registro instalado v1. Falta revisión
independiente; no es escaneo nuevo ni aceptación global deR05. El árbol actual33
y las fuentes posteriores requieren su propio escaneo completo. Las limitaciones
de preimágenes históricas y los intentos iniciales se conservan explícitamente.
'''
public={'.gitattributes':b'* -text\n','candidate-evidence.zip':buffer.getvalue(),'candidate-reviewed-locations.zip':ledger.getvalue(),'summary.json':enc(summary),'source.json':enc(source),'review.md':review.encode()}
for name,blob in public.items():scan(blob,name)
assert all(sha((R/name).read_bytes())==digest for name,digest in quiet.items())
P.mkdir();(P/'.gitattributes').write_bytes(public.pop('.gitattributes'))
for name,blob in public.items():(P/name).write_bytes(blob)
manifest={p.name:{'bytes':p.stat().st_size,'digest':sha(p.read_bytes())} for p in P.iterdir() if p.is_file()}
(P/'manifest.json').write_bytes(enc(manifest))
prefix=P.relative_to(R).as_posix();git('-c','core.autocrlf=false','add','-f','--',prefix)
git('diff','--cached','--check')
for path in P.iterdir():assert git('show',':'+path.relative_to(R).as_posix()).stdout==path.read_bytes()
git('commit','-m','Seal finite candidate proof for remaining scan metadata locations')
result={'head':git('rev-parse','HEAD').stdout.decode().strip(),'files':len(manifest)+1,'source_digest':sha((P/'source.json').read_bytes()),'manifest_digest':sha((P/'manifest.json').read_bytes()),**summary}
(C/'result.json').write_bytes(enc(result));print(json.dumps(result))
