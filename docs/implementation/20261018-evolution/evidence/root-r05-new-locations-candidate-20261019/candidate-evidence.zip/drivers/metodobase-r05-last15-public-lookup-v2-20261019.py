from pathlib import Path

prior=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r05-last15-public-lookup-20261019.py')
source=prior.read_text()
old="    decoded=payload.decode('utf-8-sig')\n"
new="    decoded=payload.decode('utf-16' if payload.startswith((b'\\xff\\xfe',b'\\xfe\\xff')) else 'utf-8-sig')\n"
assert source.count(old)==1
revised=source.replace(old,new,1)
assert revised.replace(new,old,1)==source
scope={'__name__':'__main__','__file__':str(prior)}
exec(compile(revised,str(prior)+':v2_utf16_bom_framing','exec'),scope)
