from pathlib import Path

prior=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r05-last15-classify-20261019.py')
source=prior.read_text()
replacements=[
    ("assert len(set(configs.values()))==len(configs)\n", "# Different empty optional settings legitimately have the same digest.\n"),
    ("    sensitive={configs[k].encode() for k in ['SECRET_KEY','MFA_ENCRYPTION_KEY','STRIPE_SECRET_KEY']}\n", "    sensitive={configs[k].encode() for k in (names if name=='server.stdout.raw.log' else ['SECRET_KEY','MFA_ENCRYPTION_KEY','STRIPE_SECRET_KEY'])}\n"),
]
revised=source
for old,new in replacements:
    assert revised.count(old)==1;revised=revised.replace(old,new,1)
inverse=revised
for old,new in reversed(replacements):inverse=inverse.replace(new,old,1)
assert inverse==source
exec(compile(revised,str(prior)+':v2_no_digest_uniqueness_assumption','exec'),{'__name__':'__main__','__file__':str(prior)})
