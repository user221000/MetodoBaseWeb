"""Prove each remaining candidate by payload or the pinned pure digest producer."""
from pathlib import Path
import ast
import hashlib
import json
import re
from types import SimpleNamespace

R=Path('F:/MetodoBaseWeb-execution-20261018')
T=Path('C:/Users/Consu/AppData/Local/Temp')
O=T/'metodobase-r05-current-final15-triage-20261019'
P=R/'docs/implementation/20261018-evolution/evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=json.loads((T/'metodobase-r05-current-runtime-map-triage-20261019/unclassified-locations.json').read_bytes())
lookup=json.loads((O/'public-lookup.json').read_bytes())
proofs={}

# The historical line is a for-header. Parse its exact expression plus inert
# pass, never run the driver or materialize the old working directories.
f='docs/implementation/20261018-evolution/evidence/checkpoint117-driver.py'
raw=(R/f).read_bytes();line=raw.decode().split('\n')[32]
header=ast.parse(line+'\n    pass\n').body[0]
assert isinstance(header,ast.For) and isinstance(header.iter,ast.List)
expected=['backend-mfa31-alias-key-fix','backend-mfa31-primary-privacy']
witness=[]
for entry,prefix in zip(header.iter.elts,expected,strict=True):
    assert isinstance(entry,ast.Tuple) and len(entry.elts)==3
    assert ast.literal_eval(entry.elts[1])==prefix
    digest=ast.literal_eval(entry.elts[2]);assert re.fullmatch('[a-f0-9]{64}',digest)
    source=P/'prepared-wave117-20261019'/(prefix+'-freeze.json')
    assert sha(source.read_bytes())==digest
    witness.append({'path':source.relative_to(R).as_posix(),'digest':digest,'bytes':source.stat().st_size})
proofs[f,33]={'kind':'two literal SHA256 digests of retained public freeze receipts','witnesses':witness,'old_driver_executed':False}

f='docs/implementation/20261018-evolution/evidence/expat-sec10-d60-native-failed-20261019/reused-prior-psf-signature-result.json'
entry=json.loads((R/f).read_bytes())
public=P/'linux-expat-sec10-m2-prepared-20261019/author-evidence/primary/python-release-key.asc'
digest=sha(public.read_bytes())
assert digest=='1de2bbd31e2dd10aab4098c3ab2f937c530d924ddbfa2dd091f0c7cfb2ee182a'
keys=[k for k in entry['hashes'] if k.endswith('python-release-key.asc')]
assert len(keys)==1 and entry['hashes'][keys[0]]==digest
assert digest in (R/f).read_bytes().split(b'\n')[6].decode()
proofs[f,7]={'kind':'SHA256 of retained public PSF signing key material','witness':public.relative_to(R).as_posix(),'digest':digest,'new_signature_or_key_import_claim':False}

f='docs/implementation/20261018-evolution/evidence/prepared-wave118-20261019/ui-author-vm-source.json'
vm=json.loads((R/f).read_bytes())
assert isinstance(vm['proof_raw_sha256'],dict)
for number,name in [(180,'api-expanded.json'),(181,'api-first.json'),(194,'final-mfa_api.json'),(215,'before/api-wire.json')]:
    digest=vm['proof_raw_sha256'][name]
    assert digest in (R/f).read_bytes().split(b'\n')[number-1].decode()
    hits=[h for h in lookup['hits'][digest] if h['derivation']=='Git_blob_bytes']
    assert hits
    proofs[f,number]={'kind':'exact SHA256 of retained public VM report Git blob','reported_basename':name,'digest':digest,'witnesses':hits,'execution_reattested':False}

adapter=T/'metodobase-mfa31-browser-v2-independent-20261019/server_adapter.py'
adapter_raw=adapter.read_bytes();adapter_digest=sha(adapter_raw)
assert adapter_digest=='db2749e19ca871d3e1df3e1b113085c8f6d8c115f9c4b155434f8535d65ab9ee'
tree=ast.parse(adapter_raw)
functions=[n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='config_hashes']
assert len(functions)==1
function=functions[0]
expected='''def config_hashes():
    settings = get_settings()
    return {name: hashlib.sha256(str(os.environ.get(name, '') if name == 'DATABASE_URL' else getattr(settings, name)).encode()).hexdigest() for name in ['SECRET_KEY', 'MFA_ENCRYPTION_KEY', 'DATABASE_URL', 'BASE_URL', 'GOOGLE_CLIENT_ID', 'STRIPE_SECRET_KEY', 'REDIS_URL']}
'''
assert ast.dump(function,include_attributes=False)==ast.dump(ast.parse(expected).body[0],include_attributes=False)
names=['SECRET_KEY','MFA_ENCRYPTION_KEY','DATABASE_URL','BASE_URL','GOOGLE_CLIENT_ID','STRIPE_SECRET_KEY','REDIS_URL']
synthetic={name:'Synthetic digest verification only '+name for name in names}
scope={'hashlib':hashlib,'get_settings':lambda:SimpleNamespace(**synthetic),'os':SimpleNamespace(environ={'DATABASE_URL':synthetic['DATABASE_URL']})}
# Compile only the proven pure producer against synthetic dependencies. No
# historical adapter import, settings/environment read, server, SQL or cleanup.
exec(compile(ast.Module(body=[function],type_ignores=[]),'pinned-pure-config-hashes','exec'),scope)
assert scope['config_hashes']()=={name:sha(value.encode()) for name,value in synthetic.items()}
Q=P/'qa-mfa31-browser-v2-independent-20261019'
source_receipts=[]
for name in ['before.json','after.json','preflight-frozen.json']:
    receipt=json.loads((Q/name).read_bytes())
    assert receipt['helpers']['server_adapter.py']==adapter_digest
    source_receipts.append({'path':(Q/name).relative_to(R).as_posix(),'digest':sha((Q/name).read_bytes())})
ready=json.loads((Q/'owned-ready.json').read_bytes())
closure=json.loads((Q/'resource-closure.json').read_bytes())
log=json.loads((Q/'server.stdout.raw.log').read_bytes().split(b'\n')[1])
assert ready==closure['actual_server_ready']==log
configs=ready['config_hashes']
assert set(configs)==set(names) and all(isinstance(v,str) and re.fullmatch('[a-f0-9]{64}',v) for v in configs.values())
assert len(set(configs.values()))==len(configs)
config_proof={'kind':'pinned pure SHA256 producer plus identical typed ready receipt in all three outputs','producer_sha256':adapter_digest,'producer_AST_exact':True,'synthetic_pure_function_check':True,'producer_source_receipts':source_receipts,'all_seven_config_entries_identical':True,'private_original_configuration_preimages_recomputed':False,'limitation':'Digest producer and copied typed output are proven; original private configuration values are not reconstructed or disclosed.'}
for name,number in [('server.stdout.raw.log',2),('owned-ready.json',7),('owned-ready.json',8),('owned-ready.json',12),('resource-closure.json',10),('resource-closure.json',11),('resource-closure.json',15)]:
    f=(Q/name).relative_to(R).as_posix()
    physical=(R/f).read_bytes().split(b'\n')[number-1]
    # Only three explicitly reviewed sensitive-setting DIGEST entries, never
    # classify a field name alone or accept future output from this producer.
    hashes=set(re.findall(rb'[a-f0-9]{64}',physical))
    sensitive={configs[k].encode() for k in ['SECRET_KEY','MFA_ENCRYPTION_KEY','STRIPE_SECRET_KEY']}
    assert hashes and hashes <= sensitive
    proofs[f,number]=config_proof

classified=[];remaining=[]
for row in rows:
    raw=(R/row['file']).read_bytes();assert sha(raw)==row['file_sha256']
    coordinate=row['file'],row['line']
    if coordinate in proofs:
        classified.append({**row,'physical_line_sha256':sha(raw.split(b'\n')[row['line']-1]),'proof':proofs[coordinate]})
    else:remaining.append(row)
assert len(classified)==15 and not remaining
for name,value in [('classified.json',classified),('unclassified-locations.json',remaining),('witnesses.json',[{'file':f,'line':n,'proof':v} for (f,n),v in proofs.items()])]:
    target=O/name;assert not target.exists();target.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
(O/'driver.py').write_bytes(Path(__file__).read_bytes())
summary={'input':len(rows),'candidate_classified':len(classified),'remaining':len(remaining),'cumulative_candidates':14557,'all_raw_physical_pins_checked':True,'config_locations':9,'original_private_configuration_values_recomputed':False,'independent_new_review':False,'registry_v1_changed':False,'global_R05_acceptance':False}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
