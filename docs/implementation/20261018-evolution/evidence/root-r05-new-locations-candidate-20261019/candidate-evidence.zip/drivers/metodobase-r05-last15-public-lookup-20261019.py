"""Read only public Git blobs; compare digests without disclosing their contents."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

R=Path('F:/MetodoBaseWeb-execution-20261018')
O=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r05-current-final15-triage-20261019')
O.mkdir(exist_ok=True)
P='docs/implementation/20261018-evolution/evidence/'
paths=['web/static/js/api.js']+[P+'mfa-ui/'+p for p in ['api-expanded.json','api-first.json','final-mfa_api.json','before/api-wire.json']]
targets={'00d19c33f6febaa231bd5f4dda892d5839aad88af045b0d0a367076050578810','6d9c03dccfcd644de2c0e15c30718a0e6a56d55a24a166b83adcc978739114bf','2b43a22d108a710e56b73e243c26aa21c31d0b1290fcbbb4fe99f1162da744b3','67436b3021e15e62099aa4a7f4ee45397dd7e4396aeb8a3284e830266d23042c','beae3da9cd12d0ef7c830533dda5262807cd4aafb5f897777779d6cfe87f6b8f'}
result=subprocess.run(['git','rev-list','--objects','--all','--',*paths],cwd=R,capture_output=True,check=True)
blobs={}
for line in result.stdout.decode().splitlines():
    oid,_,path=line.partition(' ')
    if path in paths:
        assert re.fullmatch(r'[0-9a-f]{40}',oid)
        blobs.setdefault(oid,set()).add(path)
hits={}
for oid, names in blobs.items():
    payload=subprocess.check_output(['git','cat-file','blob',oid],cwd=R)
    decoded=payload.decode('utf-8-sig')
    lf=decoded.replace('\r\n','\n')
    variants={'Git_blob_bytes':payload,'DERIVED_LF':lf.encode(),'DERIVED_CRLF':lf.replace('\n','\r\n').encode(),'DERIVED_UTF8_BOM_LF':b'\xef\xbb\xbf'+lf.encode(),'DERIVED_UTF8_BOM_CRLF':b'\xef\xbb\xbf'+lf.replace('\n','\r\n').encode(),'DERIVED_UTF16LE_BOM_LF':b'\xff\xfe'+lf.encode('utf-16-le'),'DERIVED_UTF16LE_BOM_CRLF':b'\xff\xfe'+lf.replace('\n','\r\n').encode('utf-16-le')}
    for variant,data in variants.items():
        digest=hashlib.sha256(data).hexdigest()
        if digest in targets:
            hits.setdefault(digest,[]).append({'Git_blob_oid':oid,'paths':sorted(names),'derivation':variant,'not_execution_RAW':variant!='Git_blob_bytes','bytes':len(data)})
out={'paths':paths,'objects_examined':len(blobs),'hits':hits,'missing':sorted(targets-set(hits))}
target=O/'public-lookup.json'
assert not target.exists()
target.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out))
