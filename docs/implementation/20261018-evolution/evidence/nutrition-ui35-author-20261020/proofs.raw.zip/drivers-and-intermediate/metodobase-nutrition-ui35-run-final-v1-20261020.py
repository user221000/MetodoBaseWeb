from pathlib import Path
import hashlib,importlib.metadata,json,os,subprocess,sys,time
root=Path('F:/mb-followup-actions-ui-20261019');out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-nutrition-ui35-runtime-final-v1-20261020');out.mkdir(exist_ok=False)
os.chdir(root);sys.path.insert(0,str(root));sys.dont_write_bytecode=True
from tests.isolation import prepare_environment,block_external_sockets
prepare_environment(discard_inherited=True);block_external_sockets()
def save(name,value):
    with (out/name).open('x',encoding='utf8') as f:json.dump(value,f,indent=2,sort_keys=True)
def snapshot():
    paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')
    source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if p and not p.startswith('docs/') and (root/p).is_file()}
    packages={d.metadata['Name']:{'version':d.version,'metadata_sha256':hashlib.sha256((d.read_text('METADATA')or'').encode()).hexdigest()} for d in importlib.metadata.distributions()}
    binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(sys.executable),Path(sys._base_executable),Path('C:/Program Files/nodejs/node.exe'))}
    return {'source':source,'packages':packages,'binaries':binaries}
before=snapshot();save('before.json',before)
p1=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-before.json',{'exit':p1.returncode,'output':p1.stdout})
started=time.monotonic();results=[]
files=['nutrition35_api','nutrition35_state','nutrition35_dom','nutrition35_personal_generation','followup_tasks_api','followup_tasks_state','followup_tasks_dom','dashboard_followup34','dashboard_followup','dashboard_followup_focus','google_link_api','google_link_state','google_link_dom','google_link_login_review','auth_refresh','auth_refresh_storage','auth_refresh_race_review','auth_refresh_security_review','session_revision_events','session_expiry_security','session_expiry_fences','mfa_api','mfa_consumers','mfa_state','mfa_prompt','personal_operation','personal_operation_ambiguity_review']
for stem in files:
    env=os.environ.copy()
    for key in list(env):
        if key.endswith('_OUTPUT'):del env[key]
    r=subprocess.run(['C:/Program Files/nodejs/node.exe','tests/e2e/'+stem+'.cjs'],env=env,capture_output=True,text=True,timeout=60)
    (out/(stem+'.stdout')).write_bytes(r.stdout.encode());(out/(stem+'.stderr')).write_bytes(r.stderr.encode())
    try:report=json.loads(r.stdout)
    except ValueError:report={'unparsed':True}
    results.append({'file':'tests/e2e/'+stem+'.cjs','exit':r.returncode,'report':report})
save('node-results.json',results)
ruff=subprocess.run(['C:/Users/Consu/AppData/Local/Temp/metodobase-qa-20261018/Scripts/python.exe','-m','ruff','check','tests/test_nutrition35_ui.py'],capture_output=True,text=True);save('ruff.json',{'exit':ruff.returncode,'stdout':ruff.stdout,'stderr':ruff.stderr})
import pytest
code=pytest.main(['tests/test_nutrition35_ui.py','-q','--tb=short','--junitxml='+str(out/'ui.xml'),'-o','cache_dir='+str(out/'cache')])
after=snapshot();save('after.json',after)
p2=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-after.json',{'exit':p2.returncode,'output':p2.stdout})
save('receipt.json',{'pytest_exit':code,'node_exit_codes':[r['exit'] for r in results],'quiet':before==after,'source_count':len(before['source']),'packages':len(before['packages']),'pip_before':p1.returncode,'pip_after':p2.returncode,'ruff_exit':ruff.returncode,'duration_seconds':time.monotonic()-started,'scope':'Author nutrition35 UI; synthetic VM/minimalDOM, actual SSR script syntax and isolated SQLite HTTP DTO→current JS-controller→HTTP body bridge. No Chrome/layout/axe/PG/provider/desktop acceptance.'})
raise SystemExit(code or ruff.returncode or any(r['exit'] for r in results))
