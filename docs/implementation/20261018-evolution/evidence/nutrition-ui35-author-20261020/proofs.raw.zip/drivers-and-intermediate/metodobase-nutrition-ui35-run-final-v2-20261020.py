"""Close only the corrected SSR/SQLite framing, preserving the closed VM phase."""
from pathlib import Path
import hashlib,importlib.metadata,json,os,subprocess,sys,time
root=Path('F:/mb-followup-actions-ui-20261019')
temp=Path('C:/Users/Consu/AppData/Local/Temp')
out=temp/'metodobase-nutrition-ui35-runtime-final-v2-20261020'
out.mkdir(exist_ok=False)
os.chdir(root);sys.path.insert(0,str(root));sys.dont_write_bytecode=True
from tests.isolation import prepare_environment,block_external_sockets
prepare_environment(discard_inherited=True);block_external_sockets()
def save(name,value):
    with (out/name).open('x',encoding='utf8') as f:json.dump(value,f,indent=2,sort_keys=True)
def snapshot():
    paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')
    source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if p and not p.startswith('docs/') and (root/p).is_file()}
    packages={d.metadata['Name']:{'version':d.version,'metadata_sha256':hashlib.sha256((d.read_text('METADATA')or'').encode()).hexdigest()} for d in importlib.metadata.distributions()}
    binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(sys.executable),Path(sys._base_executable),Path('C:/Program Files/nodejs/node.exe'))}
    return {'source':source,'packages':packages,'binaries':binaries}
before=snapshot();save('before.json',before)
previous=json.loads((temp/'metodobase-nutrition-ui35-runtime-final-v1-20261020/after.json').read_text())
changed=sorted(p for p in set(previous['source'])|set(before['source']) if previous['source'].get(p)!=before['source'].get(p))
assert changed==['tests/test_nutrition35_ui.py'],changed
assert previous['packages']==before['packages'] and previous['binaries']==before['binaries']
old=(temp/'metodobase-nutrition-ui35-pytest-framing-before-20261020.py').read_bytes()
expected=old.replace('"no autoriza clínicamente"'.encode(),'"ni autoriza clínicamente"'.encode())
needle=b'    raw = c["raw"]\n    profile = raw.get("/api/clientes/" + c["profile"])'
replacement=b'    raw = c["raw"]\n    assert raw.put("/api/clientes/" + c["profile"], json=fixtures.VALID).status_code == 200\n    profile = raw.get("/api/clientes/" + c["profile"])'
assert expected.count(needle)==2
expected=expected.replace(needle,replacement,1)
needle=b'    raw.headers["Authorization"] = "Bearer " + login.json()["token"]\n    profile = raw.get("/api/usuario/perfil")'
replacement=b'    raw.headers["Authorization"] = "Bearer " + login.json()["token"]\n    assert raw.put("/api/usuario/perfil", json=fixtures.VALID).status_code == 200\n    profile = raw.get("/api/usuario/perfil")'
assert expected.count(needle)==1
expected=expected.replace(needle,replacement)
assert expected==(root/'tests/test_nutrition35_ui.py').read_bytes()
save('framing.json',{'changed_paths':changed,'exact_three_changes_verified':True,'product_change':False,'closed_27_node_sources_preserved':True,'partial_empty_original_independent_regression':'metodobase-nutrition-ui35-partial-empty-repro-20261020','changes':['Match actual nonclinical SSR phrase ni autoriza clínicamente','Complete synthetic anthropometric prestate for weight-only declaration preservation scenario','Complete synthetic personal anthropometric prestate before testing nutrition generation guard']})
p1=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-before.json',{'exit':p1.returncode,'output':p1.stdout})
started=time.monotonic()
ruff=subprocess.run(['C:/Users/Consu/AppData/Local/Temp/metodobase-qa-20261018/Scripts/python.exe','-m','ruff','check','tests/test_nutrition35_ui.py'],capture_output=True,text=True);save('ruff.json',{'exit':ruff.returncode,'stdout':ruff.stdout,'stderr':ruff.stderr})
import pytest
code=pytest.main(['tests/test_nutrition35_ui.py','-q','--tb=short','--junitxml='+str(out/'ui.xml'),'-o','cache_dir='+str(out/'cache')])
after=snapshot();save('after.json',after)
p2=subprocess.run([sys.executable,'-m','pip','check'],capture_output=True,text=True);save('pip-after.json',{'exit':p2.returncode,'output':p2.stdout})
save('receipt.json',{'pytest_exit':code,'quiet':before==after,'source_count':len(before['source']),'packages':len(before['packages']),'pip_before':p1.returncode,'pip_after':p2.returncode,'ruff_exit':ruff.returncode,'duration_seconds':time.monotonic()-started,'scope':'Author nutrition35 UI corrected SSR/SQLite framing only; 27 Node source/execution phase preserved separately. No browser/PG/live provider acceptance; desktop excluded by user.'})
raise SystemExit(code or ruff.returncode or int(before!=after) or p1.returncode or p2.returncode)
