from pathlib import Path
p=Path('F:/mb-followup-actions-ui-20261019/tests/e2e/nutrition35_personal_generation.cjs')
s=p.read_text(encoding='utf8');old='beforeGenerate:()=>s.Nutrition35.assertAutomated(value)';new='beforeGenerate:()=>s.window.Nutrition35.assertAutomated(value)'
assert s.count(old)==1;p.write_text(s.replace(old,new),encoding='utf8',newline='')
