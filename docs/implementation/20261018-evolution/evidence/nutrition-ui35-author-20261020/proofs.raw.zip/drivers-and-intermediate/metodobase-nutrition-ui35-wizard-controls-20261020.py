from pathlib import Path
import json,hashlib
p=Path('F:/mb-followup-actions-ui-20261019/web/templates/generar-plan.html')
raw=p.read_bytes();s=raw.decode('utf8')
old="modalNuevo.querySelectorAll('input, select').forEach(field => {"
new="modalNuevo.querySelectorAll('input, select').forEach(field => { if (field.id && field.id.startsWith('nutrition35-')) return;"
assert s.count(old)==4,s.count(old)
s=s.replace(old,new)
old="document.getElementById('s2-generar').disabled = false;"
new="try { nutritionGeneration.requireAutomation(); document.getElementById('s2-generar').disabled=false; } catch { document.getElementById('s2-generar').disabled=true; }"
assert s.count(old)==2,s.count(old)
s=s.replace(old,new)
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-nutrition-ui35-wizard-controls-20261020');out.mkdir(exist_ok=False)
(out/'before.raw.html').write_bytes(raw);p.write_text(s,encoding='utf8',newline='')
(out/'receipt.json').write_text(json.dumps({'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'nutrition_fields_owned_by_component_excluded_from_legacy_reset_disable':4,'generation_reenable_rechecks':2,'preflight_erratum':'First driver expected3 literal matches; observed2 and failed before source mutation or output-directory creation. Corrected literal count only.'},indent=2),encoding='utf8')
