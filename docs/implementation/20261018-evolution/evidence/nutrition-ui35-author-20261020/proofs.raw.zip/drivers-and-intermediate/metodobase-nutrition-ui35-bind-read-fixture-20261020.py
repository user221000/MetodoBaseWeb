from pathlib import Path
p=Path('F:/mb-followup-actions-ui-20261019/tests/e2e/nutrition35_state.cjs');s=p.read_text(encoding='utf8')
old="next||{restricciones_nutricionales:clone(server.value)};"
new="next||{...(name==='client'?{id_cliente:args[0]}:{}),restricciones_nutricionales:clone(server.value)};"
assert s.count(old)==1;p.write_text(s.replace(old,new),encoding='utf8',newline='')
