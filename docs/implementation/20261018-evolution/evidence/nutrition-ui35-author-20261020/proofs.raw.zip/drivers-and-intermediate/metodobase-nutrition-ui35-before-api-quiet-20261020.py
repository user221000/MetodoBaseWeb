from pathlib import Path
import hashlib,json,os,subprocess
root=Path('F:/mb-followup-actions-ui-20261019');out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-nutrition-ui35-before-api-quiet-20261020');out.mkdir(exist_ok=False)
paths=['web/static/js/api.js','tests/e2e/nutrition35_api.cjs']
def snap():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snap()
for p in paths:
    target=out/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/p).read_bytes())
env=os.environ.copy();env['NUTRITION_API_OUTPUT']=str(out/'report.json')
result=subprocess.run(['C:/Program Files/nodejs/node.exe','tests/e2e/nutrition35_api.cjs'],cwd=root,env=env,capture_output=True)
(out/'stdout.raw').write_bytes(result.stdout);(out/'stderr.raw').write_bytes(result.stderr)
(out/'receipt.json').write_text(json.dumps({'before':before,'after':snap(),'quiet':before==snap(),'exit':result.returncode,'node_sha256':hashlib.sha256(Path('C:/Program Files/nodejs/node.exe').read_bytes()).hexdigest(),'scope':'Missing namespace12RED:1absence canary11dependent blocked; no backend/generation acceptance'},indent=2),encoding='utf8')
assert result.returncode==1 and before==snap()
