from pathlib import Path
import hashlib
import json
import subprocess
root=Path('F:/mb-followup-actions-ui-20261019')
producer='55a3f4f9b1c1d03937bae78a5cee4f1d1b6379af'
git=lambda *args:subprocess.check_output(['git','-c','core.autocrlf=false',*args],cwd=root)
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-nutrition-ui35-composition-20261020');out.mkdir(exist_ok=False)
name='web/database/schema_control.py';path=root/name
(out/'schema_control-conflict.raw.py').write_bytes(path.read_bytes())
blob=git('show',producer+':'+name);path.write_bytes(blob)
assert git('diff',producer,'--','web/database/models.py')==b''
git('add','--',name)
assert not git('diff','--name-only','--diff-filter=U')
check=subprocess.run(['git','-c','core.autocrlf=false','diff','--cached','--check'],cwd=root,capture_output=True,text=True)
(out/'diff-check.stdout').write_text(check.stdout,encoding='utf8');(out/'diff-check.stderr').write_text(check.stderr,encoding='utf8')
assert check.returncode==0
git('commit','-m','Compose frozen nutrition35 backend with preserved task UI34')
assert not git('status','--porcelain')
receipt={'head':git('rev-parse','HEAD').decode().strip(),'parents':['1ebfb98f205d6be25a088b9fd70c2fa2633d87ba',producer],'conflict_resolution':'Only incoming nutrition35 SCHEMA_CONTRACTS addition; resolved with producer exact blob. Models auto-merge equals producer Git blob.','schema_control_sha256':hashlib.sha256(blob).hexdigest(),'diff_check':0,'clean':True}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps(receipt))
