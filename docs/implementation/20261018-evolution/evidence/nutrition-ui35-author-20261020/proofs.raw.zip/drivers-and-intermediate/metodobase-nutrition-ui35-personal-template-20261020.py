from pathlib import Path
import hashlib,json
root=Path('F:/mb-followup-actions-ui-20261019');p=root/'web/templates/usuario_perfil.html'
raw=p.read_bytes();text=raw.decode('utf8')
changes=[("""      var res = await fetch('/api/usuario/catalogo-alimentos', {
        headers: { 'Authorization': 'Bearer ' + localStorage.getItem('mb_token') }
      });
      if (!res.ok) throw new Error('Error cargando catálogo');
      var catalogo = await res.json();""", """      var catalogo = await nutritionPersonal.readCatalog();
      nutritionPersonal.check();"""),
("""    var res = await fetch('/api/usuario/perfil', {
      headers: { 'Authorization': 'Bearer ' + localStorage.getItem('mb_token') }
    });
    if (res.ok) {
      var p = await res.json();""", """    var p = await nutritionPersonal.load();
    if (p) {"""),
("""      var res = await fetch('/api/usuario/perfil', {
        method: 'PUT',
        headers: {
          'Authorization': 'Bearer ' + localStorage.getItem('mb_token'),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        var err = await res.json().catch(function() { return {}; });
        throw new Error(err.detail || 'Error guardando perfil');
      }
      var isComplete = computeCompleteness() >= 80;
      showToast(isComplete
        ? '✅ Plan actualizado · Ve a Mi Plan para regenerarlo'
        : '✅ Datos guardados · Completa tu perfil para un plan más preciso');""", """      await nutritionPersonal.save(payload);
      showToast('Perfil guardado. No se generó ningún plan.');"""),
("showToast('❌ ' + e.message, 'error');", "showToast(nutritionPersonal.view().message || 'No se pudo confirmar el guardado. Consulta el estado antes de continuar.', 'error');"),
("      btn.disabled = false;", "      btn.disabled = nutritionPersonal.view().busy || nutritionPersonal.view().phase !== 'ready';")]
for old,new in changes:
    assert text.count(old)==1,(old[:70],text.count(old))
    text=text.replace(old,new)
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-nutrition-ui35-personal-template-20261020');out.mkdir(exist_ok=False)
(out/'before.raw.html').write_bytes(raw)
p.write_text(text,encoding='utf8',newline='')
(out/'receipt.json').write_text(json.dumps({'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'replacements':len(changes),'purpose':'Existing personal form reads/writes use exact-access nutrition handle; omit unchanged declaration; no Storage for new flow; no plan-generation success claim'},indent=2),encoding='utf8')
