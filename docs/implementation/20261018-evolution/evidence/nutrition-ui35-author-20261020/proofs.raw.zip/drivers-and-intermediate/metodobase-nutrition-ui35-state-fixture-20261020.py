from pathlib import Path
import json,hashlib
root=Path('F:/mb-followup-actions-ui-20261019');out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-nutrition-ui35-state-fixture-20261020');out.mkdir(exist_ok=False)
p=root/'tests/e2e/nutrition35_state.cjs';raw=p.read_bytes();s=raw.decode('utf8')
old="if(next)return typeof next==='function'?next():Promise.resolve(next);"
new="if(next)return typeof next==='function'?Promise.resolve().then(next):Promise.resolve(next);"
assert s.count(old)==1;s=s.replace(old,new)
old="await Promise.resolve();await Promise.resolve();await Promise.resolve();await Promise.resolve();const newer=f.page.load('client-new');"
new="for(let step=0;step<20&&!f.calls.some(c=>c.name==='client');step++)await Promise.resolve();assert.equal(f.calls.some(c=>c.name==='client'),true);const newer=f.page.load('client-new');"
assert s.count(old)==1;s=s.replace(old,new)
(out/'test-before.raw.cjs').write_bytes(raw);(out/'model-before.raw.js').write_bytes((root/'web/static/js/nutrition35.js').read_bytes());p.write_text(s,encoding='utf8',newline='')
(out/'receipt.json').write_text(json.dumps({'test_before_sha256':hashlib.sha256(raw).hexdigest(),'test_after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'business_assertions_changed':False,'changes':['Network double now rejects a Promise after dispatch, matching actual async API helper; initial synchronous throw modeled pre-dispatch body validation instead.','Second read begins only after the controlled first client request actually started; bounded microtask barrier replaces a guessed tick count.'],'original_run':'31 total27PASS4RED; two dispatch-double mismatches, one request-start barrier mismatch and one unknown-create product guard'},indent=2),encoding='utf8')
