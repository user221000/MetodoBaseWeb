/* Explicit profile declarations; no inferred allergy taxonomy, clinical approval or persistence. */
(function(root){
  'use strict';
  const labels=Object.freeze({not_reported:'Sin declaración registrada sobre alergias',none_reported:'La persona declara no tener alergias',reported:'La persona reporta alergias'});
  const messages=Object.freeze({nutrition_professional_review_required:'Este perfil requiere revisión profesional. La generación automática está bloqueada en todos los planes, incluido Pro.',nutrition_profile_invalid_input:'No se pudo validar la declaración. Revisa el perfil antes de continuar.',nutrition_restrictions_invalid:'La declaración guardada no es válida. No se puede tratar como ausencia de restricciones.',nutrition_restrictions_changed:'Las restricciones cambiaron. Consulta el perfil antes de preparar otra generación; este error no confirma una devolución de cupo.',nutrition_unsaved_changes:'Guarda explícitamente los cambios de la declaración y consulta el perfil antes de generar.',nutrition_state_unavailable:'No se pudo consultar el estado actual. No se ha confirmado que el perfil permita generación automática.',nutrition_confirmation_required:'Confirma el cambio de declaración antes de guardarlo.'});
  const error=(code='nutrition_profile_invalid_input')=>Object.assign(Error(messages[code]||messages.nutrition_state_unavailable),{code});
  const shape=(value,keys)=>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==keys.length||keys.some(k=>!Object.hasOwn(value,k)))throw error();};
  const food=value=>typeof value==='string'&&value.length>0&&value.length<=128&&!/[\p{C}]/u.test(value);
  const clone=value=>JSON.parse(JSON.stringify(value));
  const fresh=()=>({version:1,allergies:{version:1,status:'not_reported',foods:[],other_reported:false},professional_review_requested:false});
  function declaration(value,known=null){
    shape(value,['version','allergies','professional_review_requested']);const a=value.allergies;
    shape(a,['version','status','foods','other_reported']);
    if(value.version!==1||a.version!==1||!Object.hasOwn(labels,a.status)||typeof a.other_reported!=='boolean'||typeof value.professional_review_requested!=='boolean'||!Array.isArray(a.foods)||a.foods.length>250||new Set(a.foods).size!==a.foods.length||a.foods.some(v=>!food(v)||(known&&!known.has(v)))||(a.status==='reported')!==!!(a.foods.length||a.other_reported))throw error();
    return {version:1,allergies:{version:1,status:a.status,foods:[...a.foods].sort(),other_reported:a.other_reported},professional_review_requested:value.professional_review_requested};
  }
  function catalog(value,personal=false){
    const groups=personal?value:value?.categorias;if(!groups||typeof groups!=='object'||Array.isArray(groups)||Object.keys(groups).length>30)throw error('nutrition_state_unavailable');
    const ids=new Set();for(const [key,values]of Object.entries(groups)){if(typeof key!=='string'||key.length>64||!Array.isArray(values)||values.length>2000||values.some(v=>!food(v)))throw error('nutrition_state_unavailable');for(const value of values)ids.add(value);}
    if(!ids.size||ids.size>2000)throw error('nutrition_state_unavailable');return [...ids].sort();
  }
  function canonical(value){return JSON.stringify({version:value.version,allergies:{version:value.allergies.version,status:value.allergies.status,foods:[...value.allergies.foods].sort(),other_reported:value.allergies.other_reported},professional_review_requested:value.professional_review_requested});}
  function assertAutomated(value){const parsed=declaration(value);if(parsed.allergies.status==='reported'||parsed.professional_review_requested)throw error('nutrition_professional_review_required');return parsed;}
  function description(value){const parsed=declaration(value);return labels[parsed.allergies.status]+'. '+(parsed.professional_review_requested?'Se solicitó revisión profesional. ':'')+(parsed.allergies.status==='reported'||parsed.professional_review_requested?messages.nutrition_professional_review_required:'Esta declaración no acredita ausencia de alérgenos, ingredientes ni contaminación cruzada.');}
  function create({api,kind='client',onView=()=>{},onInvalidated=()=>{}}){
    let handle=null,epoch=0,dead=false,target=null,persisted=null,draft=null,known=new Set();
    const state={phase:'idle',busy:false,editing:false,dirty:false,catalog:[],declaration:null,message:'Consulta la declaración actual. Un dato no disponible no significa ausencia de alergias.'};
    function view(){return {...state,catalog:[...state.catalog],declaration:draft?clone(draft):null,target};}
    function emit(){if(handle&&!dead)check();onView(view());if(handle&&!dead)check();}
    function invalidate(){if(dead)return;dead=true;epoch++;handle=null;target=null;persisted=null;draft=null;known.clear();state.catalog=[];state.declaration=null;state.dirty=false;state.editing=false;state.busy=false;state.phase='invalidated';state.message='La sesión cambió. Los datos de esta declaración se descartaron. Abre el perfil desde tu cuenta.';onView(view());onInvalidated();}
    function check(ticket=epoch){if(dead||ticket!==epoch||!handle)throw Object.assign(Error('Changed'),{code:'session_changed'});try{api.check(handle);}catch(e){invalidate();throw e;}}
    async function verify(ticket){check(ticket);await api.verify(handle);check(ticket);}
    function fail(e,ticket,writing=false){if(dead||ticket!==epoch)return false;if(['session_changed','session_expired','session_storage_error'].includes(e.code)||e.status===401){invalidate();return false;}
      state.phase=writing?'uncertain':'error';state.editing=false;if(!writing){draft=null;persisted=null;state.dirty=false;}
      state.message=writing?'No pudimos confirmar el guardado. Puede haberse aplicado. No repetiremos ni consultaremos automáticamente; usa Consultar declaración actual.':messages[e.code]||messages.nutrition_state_unavailable;return false;}
    async function load(identifier=null){if(dead||(state.busy&&state.phase==='saving'))return null;const ticket=++epoch;target=identifier;state.busy=true;state.editing=false;state.phase='loading';persisted=null;draft=null;state.dirty=false;state.message='Consultando la declaración y el catálogo autorizados…';
      try{emit();if(!handle){const session=await api.session();if(dead||ticket!==epoch)return null;handle=session.handle;}await verify(ticket);
        const items=catalog(await(kind==='personal'?api.personalCatalog(handle):api.catalog(handle)),kind==='personal');check(ticket);
        const response=kind==='personal'?await api.personal(handle):identifier===null?null:await api.client(identifier,handle);check(ticket);await verify(ticket);
        if(response!==null&&(!response||!Object.hasOwn(response,'restricciones_nutricionales')))throw error('nutrition_state_unavailable');
        known=new Set(items);persisted=response===null?fresh():declaration(response.restricciones_nutricionales,known);draft=clone(persisted);state.catalog=items;state.phase='ready';state.message=response===null?'Nueva ficha: si no modificas esta declaración, no se enviará un valor por defecto.':description(persisted);return response;
      }catch(e){fail(e,ticket);return null;}finally{if(!dead&&ticket===epoch){state.busy=false;try{emit();}catch{/* invalidated */}}}}
    function edit(enabled){if(dead||state.busy||state.phase!=='ready'||!draft)return false;check();state.editing=enabled===true;if(!state.editing){draft=clone(persisted);state.dirty=false;}emit();return true;}
    function change(part,value){if(dead||state.busy||state.phase!=='ready'||!state.editing||!draft)return false;check();
      if(part==='status'){if(!Object.hasOwn(labels,value))throw error();draft.allergies.status=value;if(value!=='reported'){draft.allergies.foods=[];draft.allergies.other_reported=false;}}
      else if(part==='review'){if(typeof value!=='boolean')throw error();draft.professional_review_requested=value;}
      else if(part==='other'){if(typeof value!=='boolean'||draft.allergies.status!=='reported')throw error();draft.allergies.other_reported=value;}
      else if(part==='foods'){if(!Array.isArray(value)||value.length>250||new Set(value).size!==value.length||value.some(v=>!known.has(v))||draft.allergies.status!=='reported')throw error();draft.allergies.foods=[...value].sort();}
      else throw error();state.dirty=canonical(draft)!==canonical(persisted);state.message=state.dirty?'Hay cambios de declaración sin guardar. No se puede iniciar generación desde este formulario.':description(persisted);emit();return true;}
    function payload(confirmed=false){if(dead||state.phase!=='ready'||!draft)throw error('nutrition_state_unavailable');check();if(!state.dirty)return undefined;if(confirmed!==true)throw error('nutrition_confirmation_required');return declaration(draft,known);}
    async function save(values,confirmed=false){if(dead||state.busy||state.phase!=='ready')throw error('nutrition_state_unavailable');const ticket=epoch;const outgoing=payload(confirmed);
      const body=JSON.parse(JSON.stringify(values,(_k,v)=>{if((typeof v==='number'&&!Number.isFinite(v))||['undefined','function','symbol','bigint'].includes(typeof v))throw error();return v;}));
      delete body.restricciones_nutricionales;if(outgoing!==undefined)body.restricciones_nutricionales=outgoing;
      let dispatched=false;state.busy=true;state.message='Verificando antes de guardar esta intención…';
      try{emit();await verify(ticket);state.phase='saving';state.message='Enviando esta intención de guardado una sola vez…';emit();check(ticket);
        const pending=kind==='personal'?api.savePersonal(body,handle):target===null?api.create(body,handle):api.update(target,body,handle);dispatched=true;
        const response=await pending;check(ticket);
        if(kind==='personal'?response?.message!=='Perfil actualizado correctamente':response?.success!==true)throw error('nutrition_state_unavailable');
        if(kind!=='personal'&&target===null){if(typeof response.id_cliente!=='string'||!response.id_cliente||response.id_cliente.length>36)throw error('nutrition_state_unavailable');target=response.id_cliente;}
        if(outgoing!==undefined){persisted=clone(outgoing);draft=clone(outgoing);}state.dirty=false;state.editing=false;state.phase='ready';state.message='El servidor confirmó este guardado. No se generó ningún plan. Esta respuesta no impide cambios posteriores de otro editor.';return response;
      }catch(e){if(!dispatched&&e.code==='nutrition_profile_invalid_input'&&!dead&&ticket===epoch){state.phase='ready';state.message='La intención no se envió. Revisa los campos antes de guardar.';}else fail(e,ticket,dispatched);throw e;}finally{if(!dead&&ticket===epoch){state.busy=false;try{emit();}catch{/* invalidated */}}}}
    function requireAutomation(){if(dead||state.phase!=='ready'||!draft)throw error('nutrition_state_unavailable');check();if(state.dirty)throw error('nutrition_unsaved_changes');return assertAutomated(persisted);}
    function reset(){if(dead||(state.busy&&state.phase==='saving'))return false;epoch++;target=null;persisted=null;draft=null;known=new Set();state.catalog=[];state.dirty=false;state.editing=false;state.busy=false;state.phase='idle';state.message='Consulta la declaración actual. No se presume ausencia de alergias.';emit();return true;}
    async function readCatalog(){const ticket=epoch;await verify(ticket);const result=await(kind==='personal'?api.personalCatalog(handle):api.catalog(handle));await verify(ticket);return result;}
    return Object.freeze({view,load,edit,change,payload,save,requireAutomation,invalidate,check,reset,readCatalog});
  }
  function mount(element,{api,kind='client',onInvalidated=()=>{},onView=()=>{}}){
    const key=element.dataset.nutritionKey,get=suffix=>document.getElementById('nutrition35-'+key+'-'+suffix);let controller,catalogKey='',boxes=[];
    const pretty=value=>value.replace(/_/g,' ');
    function render(state){const disabled=state.busy||state.phase!=='ready';get('message').textContent=state.message;get('message').setAttribute('role',['error','uncertain','invalidated'].includes(state.phase)?'alert':'status');get('refresh').disabled=state.busy||state.phase==='invalidated';get('edit').disabled=disabled;get('edit').checked=state.editing;get('status').disabled=disabled||!state.editing;get('review').disabled=disabled||!state.editing;get('status').value=state.declaration?.allergies.status||'';get('review').checked=state.declaration?.professional_review_requested===true;get('other').checked=state.declaration?.allergies.other_reported===true;get('other').disabled=disabled||!state.editing||state.declaration?.allergies.status!=='reported';get('foods-field').hidden=state.declaration?.allergies.status!=='reported';get('search').disabled=disabled||!state.editing;get('confirm').disabled=disabled||!state.dirty;if(!state.dirty)get('confirm').checked=false;
      const signature=JSON.stringify(state.catalog);if(signature!==catalogKey){catalogKey=signature;boxes=[];get('foods').replaceChildren();for(const [index,value]of state.catalog.entries()){const label=document.createElement('label'),input=document.createElement('input'),caption=document.createElement('span');input.type='checkbox';input.id='nutrition35-'+key+'-food-'+index;input.autocomplete='off';label.htmlFor=input.id;caption.textContent=pretty(value);label.append(input,caption);get('foods').append(label);input.addEventListener('change',()=>{const foods=controller.view().declaration.allergies.foods.filter(v=>v!==value);if(input.checked)foods.push(value);controller.change('foods',foods);});boxes.push({label,input,value});}}
      const search=get('search').value.trim().toLocaleLowerCase('es');for(const box of boxes){box.input.checked=state.declaration?.allergies.foods.includes(box.value)===true;box.input.disabled=disabled||!state.editing;box.label.hidden=search.length>0&&!pretty(box.value).toLocaleLowerCase('es').includes(search);}
      if(state.phase==='invalidated'){get('search').value='';get('confirm').checked=false;get('foods').replaceChildren();boxes=[];catalogKey='';}onView(state);
    }
    controller=create({api,kind,onView:render,onInvalidated});get('refresh').addEventListener('click',()=>controller.load(controller.view().target));get('edit').addEventListener('change',()=>controller.edit(get('edit').checked));get('status').addEventListener('change',()=>controller.change('status',get('status').value));get('review').addEventListener('change',()=>controller.change('review',get('review').checked));get('other').addEventListener('change',()=>controller.change('other',get('other').checked));get('search').addEventListener('input',()=>render(controller.view()));
    const invalidate=()=>controller.invalidate();root.addEventListener('metodobase-session-changed',invalidate);root.addEventListener('pagehide',invalidate);root.addEventListener('pageshow',event=>{if(event.persisted)invalidate();});root.addEventListener('storage',event=>{if(event.key===null||['mb_token','mb_refresh_token'].includes(event.key))invalidate();});render(controller.view());
    return Object.freeze({...controller,save:values=>controller.save(values,get('confirm').checked)});
  }
  function renderSummary(element,value){try{element.textContent=description(value);element.setAttribute('role','status');return assertAutomated(value);}catch(e){element.textContent=messages[e.code]||messages.nutrition_state_unavailable;element.setAttribute('role','alert');throw e;}}
  root.Nutrition35=Object.freeze({create,mount,declaration,catalog,canonical,fresh,assertAutomated,description,renderSummary,messages,error});
})(typeof window==='undefined'?globalThis:window);
