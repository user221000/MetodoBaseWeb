OUT='C:\\Users\\Consu\\AppData\\Local\\Temp\\metodobase-nutrition-ui35-partial-empty-repro-20261020'
import json
from pathlib import Path
import traceback
from tests import test_nutrition35_http as fixtures
followup_db=fixtures.followup_db
followup_http=fixtures.followup_http

def test_partial_update_empty_profile_real_contract(followup_http,monkeypatch):
    c=followup_http;raw=c["raw"];observed={}
    initial=raw.get("/api/clientes/"+c["profile"])
    assert initial.status_code==200
    profile=initial.json()
    if c["factory_name"]=="api.app":
        import api.routes.clientes as module
        original=module.build_cliente_from_dict
        def trace_attribute(*args,**kwargs):
            try:return original(*args,**kwargs)
            except AttributeError as error:
                observed["exception_class"]=type(error).__name__
                observed["attribute_name"]=error.name
                observed["receiver_type"]=type(error.obj).__name__
                observed["frames"]=[{"file":Path(frame.filename).name,"line":frame.lineno,"function":frame.name} for frame in traceback.extract_tb(error.__traceback__)]
                raise
        monkeypatch.setattr(module,"build_cliente_from_dict",trace_attribute)
    result=raw.put("/api/clientes/"+c["profile"],json={"peso_kg":76})
    after=raw.get("/api/clientes/"+c["profile"])
    fields=["edad","peso_kg","estatura_cm","sexo","grasa_corporal_pct","nivel_actividad","objetivo"]
    receipt={"factory":c["factory_name"],"route":"PUT /api/clientes/{id_cliente}","body_shape":{"peso_kg":"synthetic integer76"},"prestate_null_fields":[name for name in fields if profile[name] is None],"status":result.status_code,"public_error":result.json().get("detail"),"attribute_observation":observed,"read_after_status":after.status_code,"weight_applied":after.status_code==200 and after.json()["peso_kg"]==76,"instrumentation":"Only captures AttributeError.name/receiver class/stack locations; reraises original; no str(exc), values or auth material"}
    path=Path(OUT)/(c["factory_name"].replace(".","-")+".json")
    with path.open("x",encoding="utf8") as stream:json.dump(receipt,stream,indent=2)
    assert result.status_code==200,"Partial update of one field in the current progressive profile contract"
