import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

root=Path('F:/MetodoBaseWeb-execution-20261018')
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-landing-retirement-test-fix-20261019')
assert (out/'summary.json').is_file() and not (out/'after20.xml').exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
source=root/'docs/implementation/20261018-evolution/evidence/r29-main-composition-20261019'
names=['tests/test_landing_commercial.py','web/routes/pages.py','web/templates/landing.html',
       'web/static/css/landing.css','web/templates/registro.html','web/static/data/landing-example.json',
       'web/main_web.py','api/app.py','core/plan_catalog.py']
before={name:sha((root/name).read_bytes()) for name in names}
for name in ['test_landing_dynamic_review.py','test_retired_page_urls.py']:
 shutil.copyfile(source/name,out/name)
 assert sha((source/name).read_bytes())==sha((out/name).read_bytes())
command=[sys.executable,'-X','utf8','tests/run_isolated.py','-p','conftest',
         'tests/test_landing_commercial.py',str(out/'test_landing_dynamic_review.py'),str(out/'test_retired_page_urls.py'),
         '-q','--tb=short','--junitxml='+str(out/'after20.xml')]
with (out/'after20.log').open('xb') as log:
 result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=90)
counts={key:len(ET.parse(out/'after20.xml').findall('.//'+key)) for key in ['testcase','failure','error','skipped']}
assert before=={name:sha((root/name).read_bytes()) for name in names}
receipt={'exit':result.returncode,'counts':counts,'source_count':len(before),'sources_stable':True,
 'source_aggregate_sha256':sha(json.dumps(before,sort_keys=True).encode()),
 'preserved_original_independent_driver_sha256':{name:sha((out/name).read_bytes()) for name in ['test_landing_dynamic_review.py','test_retired_page_urls.py']},
 'scope':'Updated12 maintained landing cases plus2 original dynamic QA and6 original retired-route cases; no runtime change or broad replay.'}
(out/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
assert result.returncode==0 and counts=={'testcase':20,'failure':0,'error':0,'skipped':0}
