import ast
import hashlib
import json
from pathlib import Path
import subprocess

root=Path('F:/MetodoBaseWeb-execution-20261018')
target=root/'tests/test_landing_commercial.py'
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-landing-retirement-test-fix-20261019')
out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='dd9877350aad3f483299c990a1e97aab63c83f5d'
raw=target.read_bytes()
old=subprocess.check_output(['git','show',head+':tests/test_landing_commercial.py'],cwd=root)
assert raw.replace(b'\r\n',b'\n')==old
(out/'test_landing_commercial-before.py').write_bytes(raw)
(out/'test_landing_commercial-Git-before.py').write_bytes(old)
text=raw.decode('utf-8')
needle="    assert Path('web/pages/checkout.html').is_file()"
assert text.count(needle)==1
replacement="""    # R29 retires the remaining unmounted commercial duplicate as well.
    assert not Path('web/pages/checkout.html').exists()
    for path in ['/checkout.html', '/pages/checkout.html', '/web/pages/checkout.html',
                 '/pages/landing.html', '/web/pages/landing.html']:
        assert landing[0].get(path).status_code == 404"""
eol='\r\n' if b'\r\n' in raw else '\n'
text=text.replace(needle,replacement.replace('\n',eol))
before=ast.parse(raw)
after=ast.parse(text)
old_function=before.body[-1]
new_function=after.body[-1]
assert isinstance(old_function,ast.FunctionDef) and old_function.name==new_function.name
assert ast.dump(ast.Module(body=before.body[:-1],type_ignores=[]))==ast.dump(ast.Module(body=after.body[:-1],type_ignores=[]))
assert [ast.dump(n) for n in old_function.body[:-1]]==[ast.dump(n) for n in new_function.body[:-2]]
target.write_text(text,encoding='utf-8',newline='')
(out/'test_landing_commercial-after.py').write_bytes(target.read_bytes())
receipt={'base':head,'original_raw_sha256':sha(raw),'original_Git_sha256':sha(old),
 'after_raw_sha256':sha(target.read_bytes()),'scope':'One superseded neighboring-file preservation assertion replaced by explicit absence and5 additional404 routes per factory. All prior public no-writes/credentials/network/CSS/data assertions remain AST-identical; runtime unchanged.',
 'original_removed_checkout_commit':'6270658d76480cb960c637ea1457f400ec440347',
 'prior_assertions_unchanged':len(old_function.body)-1,
 'before_artifacts':{p.name:sha(p.read_bytes()) for p in out.iterdir() if p.is_file()}}
(out/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
