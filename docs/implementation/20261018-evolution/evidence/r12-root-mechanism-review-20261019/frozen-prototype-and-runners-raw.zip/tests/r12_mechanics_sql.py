"""Experimental R12 SQL, installed only in a UUID-owned PostgreSQL test DB.

This is not revision29 or a runtime migration. The prototype exercises the
reviewed predicates and guards against the real migrated28 source tables.
No caller may execute it against the shared database or a deployed database.
"""

SCHEMA = "r12_probe"


def statements():
    return r"""
CREATE SCHEMA r12_probe;
ALTER TABLE public.clientes ADD CONSTRAINT r12_probe_client_owner UNIQUE(gym_id,id_cliente);
ALTER TABLE public.planes_generados ADD CONSTRAINT r12_probe_plan_owner UNIQUE(gym_id,id_cliente,id);
CREATE TABLE r12_probe.links (
 id varchar(36) PRIMARY KEY, gym_id varchar(36) NOT NULL REFERENCES public.usuarios(id) ON DELETE RESTRICT,
 client_id varchar(36) NOT NULL, user_id varchar(36) REFERENCES public.usuarios(id) ON DELETE RESTRICT,
 status text NOT NULL CHECK(status IN ('pending','active','revoked')), version integer NOT NULL DEFAULT 1,
 accepted_at timestamp, revoked_at timestamp,
 UNIQUE(gym_id,client_id,id), UNIQUE(id,gym_id,client_id,user_id),
 FOREIGN KEY(gym_id,client_id) REFERENCES public.clientes(gym_id,id_cliente) ON DELETE RESTRICT,
 CHECK(version BETWEEN 1 AND 2147483647),
 CHECK((status='pending' AND user_id IS NULL AND accepted_at IS NULL) OR
       (status='active' AND user_id IS NOT NULL AND accepted_at IS NOT NULL) OR status='revoked')
);
CREATE UNIQUE INDEX r12_probe_link_current ON r12_probe.links(gym_id,client_id) WHERE status IN ('pending','active');
CREATE UNIQUE INDEX r12_probe_link_recipient ON r12_probe.links(gym_id,user_id) WHERE status='active';
CREATE TABLE r12_probe.invitations (
 id varchar(36) PRIMARY KEY, link_id varchar(36) NOT NULL UNIQUE, gym_id varchar(36) NOT NULL,
 client_id varchar(36) NOT NULL, recipient_email varchar(255) NOT NULL,
 token_hash varchar(64) NOT NULL UNIQUE CHECK(token_hash ~ '^[a-f0-9]{64}$'),
 expires_at timestamp NOT NULL, status text NOT NULL CHECK(status IN ('pending','consumed','revoked')),
 consumed_by varchar(36) REFERENCES public.usuarios(id) ON DELETE RESTRICT,
 consumed_at timestamp, version integer NOT NULL DEFAULT 1 CHECK(version BETWEEN 1 AND 2147483647),
 FOREIGN KEY(gym_id,client_id,link_id) REFERENCES r12_probe.links(gym_id,client_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(link_id,gym_id,client_id,consumed_by) REFERENCES r12_probe.links(id,gym_id,client_id,user_id)
    ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED,
 CHECK(recipient_email=lower(btrim(recipient_email))),
 CHECK((status='consumed' AND consumed_by IS NOT NULL AND consumed_at IS NOT NULL AND consumed_at<expires_at)
    OR (status IN ('pending','revoked') AND consumed_by IS NULL AND consumed_at IS NULL))
);
CREATE TABLE r12_probe.publications (
 id varchar(36) PRIMARY KEY, gym_id varchar(36) NOT NULL, client_id varchar(36) NOT NULL,
 link_id varchar(36) NOT NULL, source_plan_id integer NOT NULL,
 source_object_id varchar(32), object_key varchar(512), content_type varchar(128),
 byte_size integer, sha256 varchar(64), storage_backend text,
 plan_json text NOT NULL, status text NOT NULL CHECK(status IN ('published','withdrawn')),
 version integer NOT NULL DEFAULT 1 CHECK(version BETWEEN 1 AND 2147483647),
 FOREIGN KEY(gym_id,client_id,link_id) REFERENCES r12_probe.links(gym_id,client_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(gym_id,client_id,source_plan_id) REFERENCES public.planes_generados(gym_id,id_cliente,id) ON DELETE RESTRICT,
 FOREIGN KEY(gym_id,source_object_id) REFERENCES public.stored_objects(gym_id,id) ON DELETE RESTRICT,
 CHECK((source_object_id IS NULL AND object_key IS NULL AND content_type IS NULL AND byte_size IS NULL AND sha256 IS NULL AND storage_backend IS NULL)
    OR (source_object_id IS NOT NULL AND object_key IS NOT NULL AND content_type='application/pdf' AND byte_size BETWEEN 1 AND 67108864
        AND sha256 ~ '^[a-f0-9]{64}$' AND storage_backend IN ('local','s3')))
);
CREATE UNIQUE INDEX r12_probe_publication_current ON r12_probe.publications(link_id) WHERE status='published';

CREATE FUNCTION r12_probe.actor_valid() RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER
 SET search_path=pg_catalog AS $$
 SELECT EXISTS(SELECT 1 FROM public.usuarios u WHERE u.id=NULLIF(current_setting('app.current_tenant',true),'')
   AND u.activo AND u.deleted_at IS NULL AND u.invitation_token IS NULL
   AND ((u.tipo='gym' AND u.role='OWNER' AND u.team_gym_id IS NULL)
     OR (u.role IN ('ADMIN','NUTRIOLOGO','VIEWER') AND (u.tipo='usuario' OR u.team_gym_id IS NOT NULL)
       AND (u.team_gym_id IS NULL OR EXISTS(SELECT 1 FROM public.usuarios parent WHERE parent.id=u.team_gym_id
         AND parent.tipo='gym' AND parent.role='OWNER' AND parent.activo AND parent.deleted_at IS NULL)))))
 $$;
CREATE FUNCTION r12_probe.gym_scope(identity text) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER
 SET search_path=pg_catalog AS $$
 SELECT identity=NULLIF(current_setting('app.current_tenant',true),'')
 $$;
CREATE FUNCTION r12_probe.canonical_gym(identity text) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER
 SET search_path=pg_catalog AS $$
 SELECT EXISTS(SELECT 1 FROM public.usuarios u
  WHERE u.id=identity AND u.tipo='gym' AND u.role='OWNER' AND u.team_gym_id IS NULL AND u.activo AND u.deleted_at IS NULL)
 $$;
CREATE FUNCTION r12_probe.proof(i r12_probe.invitations) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER
 SET search_path=pg_catalog AS $$
 SELECT r12_probe.actor_valid() AND i.token_hash=NULLIF(current_setting('app.client_invitation_digest',true),'')
 AND EXISTS(SELECT 1 FROM public.usuarios u WHERE u.id=NULLIF(current_setting('app.current_tenant',true),'')
   AND u.email=i.recipient_email AND u.email=lower(btrim(u.email)))
 AND (i.status<>'consumed' OR i.consumed_by=NULLIF(current_setting('app.current_tenant',true),''))
 $$;
CREATE FUNCTION r12_probe.pending_proof(l r12_probe.links) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER
 SET search_path=pg_catalog AS $$
 SELECT l.status='pending' AND EXISTS(SELECT 1 FROM r12_probe.invitations i WHERE i.link_id=l.id
  AND i.gym_id=l.gym_id AND i.client_id=l.client_id AND i.status IN ('pending','consumed') AND r12_probe.proof(i))
 $$;
CREATE FUNCTION r12_probe.consumed_proof(l r12_probe.links) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER
 SET search_path=pg_catalog AS $$
 SELECT l.user_id=NULLIF(current_setting('app.current_tenant',true),'') AND EXISTS(
 SELECT 1 FROM r12_probe.invitations i WHERE i.link_id=l.id AND i.gym_id=l.gym_id AND i.client_id=l.client_id
 AND i.status='consumed' AND i.consumed_by=l.user_id AND i.consumed_at=l.accepted_at AND r12_probe.proof(i))
 $$;
CREATE FUNCTION r12_probe.recipient(p r12_probe.publications) RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER
 SET search_path=pg_catalog AS $$
 SELECT p.status='published' AND r12_probe.actor_valid() AND EXISTS(
 SELECT 1 FROM r12_probe.links l WHERE l.id=p.link_id AND l.gym_id=p.gym_id AND l.client_id=p.client_id
  AND l.user_id=NULLIF(current_setting('app.current_tenant',true),'') AND l.status='active'
  AND EXISTS(SELECT 1 FROM public.usuarios g WHERE g.id=l.gym_id AND g.tipo='gym' AND g.role='OWNER'
    AND g.activo AND g.deleted_at IS NULL))
 $$;
ALTER TABLE r12_probe.links ENABLE ROW LEVEL SECURITY;
ALTER TABLE r12_probe.links FORCE ROW LEVEL SECURITY;
ALTER TABLE r12_probe.invitations ENABLE ROW LEVEL SECURITY;
ALTER TABLE r12_probe.invitations FORCE ROW LEVEL SECURITY;
ALTER TABLE r12_probe.publications ENABLE ROW LEVEL SECURITY;
ALTER TABLE r12_probe.publications FORCE ROW LEVEL SECURITY;
CREATE POLICY r12_link_select ON r12_probe.links FOR SELECT USING(r12_probe.gym_scope(gym_id)
 OR (user_id=NULLIF(current_setting('app.current_tenant',true),'') AND r12_probe.actor_valid()) OR r12_probe.pending_proof(links));
CREATE POLICY r12_link_insert ON r12_probe.links FOR INSERT WITH CHECK(r12_probe.gym_scope(gym_id) AND status='pending' AND user_id IS NULL);
CREATE POLICY r12_link_update ON r12_probe.links FOR UPDATE USING(r12_probe.gym_scope(gym_id)
 OR (user_id=NULLIF(current_setting('app.current_tenant',true),'') AND r12_probe.actor_valid()) OR r12_probe.pending_proof(links))
 WITH CHECK((r12_probe.gym_scope(gym_id) AND status IN ('pending','revoked'))
 OR (status='active' AND r12_probe.consumed_proof(links))
 OR (status='revoked' AND user_id=NULLIF(current_setting('app.current_tenant',true),'') AND r12_probe.actor_valid()));
CREATE POLICY r12_invitation_select ON r12_probe.invitations FOR SELECT USING(r12_probe.gym_scope(gym_id) OR r12_probe.proof(invitations));
CREATE POLICY r12_invitation_insert ON r12_probe.invitations FOR INSERT WITH CHECK(r12_probe.gym_scope(gym_id) AND status='pending' AND consumed_by IS NULL AND consumed_at IS NULL);
CREATE POLICY r12_invitation_update ON r12_probe.invitations FOR UPDATE USING(r12_probe.gym_scope(gym_id) OR r12_probe.proof(invitations))
 WITH CHECK((r12_probe.gym_scope(gym_id) AND status IN ('pending','revoked') AND consumed_by IS NULL AND consumed_at IS NULL)
 OR (r12_probe.proof(invitations) AND status='consumed' AND consumed_by=NULLIF(current_setting('app.current_tenant',true),'') AND consumed_at<expires_at));
CREATE POLICY r12_publication_select ON r12_probe.publications FOR SELECT USING(r12_probe.gym_scope(gym_id) OR r12_probe.recipient(publications));
CREATE POLICY r12_publication_insert ON r12_probe.publications FOR INSERT WITH CHECK(r12_probe.gym_scope(gym_id));
CREATE POLICY r12_publication_gym_update ON r12_probe.publications FOR UPDATE USING(r12_probe.gym_scope(gym_id)) WITH CHECK(r12_probe.gym_scope(gym_id));
CREATE POLICY r12_publication_reader_lock ON r12_probe.publications FOR UPDATE USING(r12_probe.recipient(publications)) WITH CHECK(false);

CREATE FUNCTION r12_probe.require_rc() RETURNS void LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog AS $$
 BEGIN IF current_setting('transaction_isolation')<>'read committed' THEN RAISE EXCEPTION USING ERRCODE='25000',MESSAGE='R12 requires READ COMMITTED'; END IF; END $$;
CREATE FUNCTION r12_probe.guard_link() RETURNS trigger LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog AS $$
 BEGIN
  PERFORM r12_probe.require_rc();
  IF TG_OP='INSERT' THEN
   IF NEW.status<>'pending' OR NEW.user_id IS NOT NULL OR NOT r12_probe.gym_scope(NEW.gym_id) OR NOT r12_probe.canonical_gym(NEW.gym_id) THEN RAISE EXCEPTION USING ERRCODE='42501',MESSAGE='R12 link denied'; END IF;
   PERFORM 1 FROM public.clientes WHERE gym_id=NEW.gym_id AND id_cliente=NEW.client_id AND activo AND deleted_at IS NULL FOR SHARE;
   IF NOT FOUND THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 client unavailable'; END IF;
  ELSE
   IF (NEW.id,NEW.gym_id,NEW.client_id) IS DISTINCT FROM (OLD.id,OLD.gym_id,OLD.client_id) THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 immutable link'; END IF;
   IF OLD.status='pending' AND NEW.status='active' THEN
    IF NOT r12_probe.consumed_proof(NEW) OR NOT r12_probe.canonical_gym(NEW.gym_id) THEN RAISE EXCEPTION USING ERRCODE='42501',MESSAGE='R12 consumption proof required'; END IF;
   ELSIF OLD.status IN ('pending','active') AND NEW.status='revoked' THEN
    IF (NEW.user_id,NEW.accepted_at) IS DISTINCT FROM (OLD.user_id,OLD.accepted_at) THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 immutable recipient'; END IF;
   ELSE RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 link transition denied'; END IF;
   IF NEW.version<>OLD.version+1 THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 version denied'; END IF;
  END IF;
  RETURN NEW;
 END $$;
CREATE TRIGGER r12_guard_link BEFORE INSERT OR UPDATE ON r12_probe.links FOR EACH ROW EXECUTE FUNCTION r12_probe.guard_link();
CREATE FUNCTION r12_probe.guard_invitation() RETURNS trigger LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog AS $$
 DECLARE decision timestamp;
 BEGIN
  PERFORM r12_probe.require_rc();
  IF TG_OP='INSERT' THEN
   IF NEW.status<>'pending' OR NEW.consumed_by IS NOT NULL OR NOT r12_probe.canonical_gym(NEW.gym_id) THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 invitation denied'; END IF;
   RETURN NEW;
  END IF;
  IF (NEW.id,NEW.link_id,NEW.gym_id,NEW.client_id,NEW.recipient_email) IS DISTINCT FROM (OLD.id,OLD.link_id,OLD.gym_id,OLD.client_id,OLD.recipient_email)
   OR NEW.version<>OLD.version+1 OR OLD.status<>'pending' THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 immutable invitation'; END IF;
  IF NEW.status='consumed' THEN
   decision=clock_timestamp() AT TIME ZONE 'UTC';
   IF NOT r12_probe.proof(OLD) OR NOT r12_probe.canonical_gym(NEW.gym_id) OR NEW.consumed_by IS DISTINCT FROM NULLIF(current_setting('app.current_tenant',true),'')
    OR NEW.token_hash IS DISTINCT FROM OLD.token_hash OR NEW.expires_at IS DISTINCT FROM OLD.expires_at OR decision>=OLD.expires_at
    THEN RAISE EXCEPTION USING ERRCODE='42501',MESSAGE='R12 consumption denied'; END IF;
   NEW.consumed_at=decision;
  ELSIF NOT r12_probe.gym_scope(NEW.gym_id) OR NEW.status NOT IN ('pending','revoked')
   OR (NEW.status='pending' AND NOT r12_probe.canonical_gym(NEW.gym_id)) THEN RAISE EXCEPTION USING ERRCODE='42501',MESSAGE='R12 invitation transition denied'; END IF;
  RETURN NEW;
 END $$;
CREATE TRIGGER r12_guard_invitation BEFORE INSERT OR UPDATE ON r12_probe.invitations FOR EACH ROW EXECUTE FUNCTION r12_probe.guard_invitation();
CREATE FUNCTION r12_probe.check_pair() RETURNS trigger LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog AS $$
 DECLARE invitation r12_probe.invitations; linked r12_probe.links; target text;
 BEGIN
  IF TG_TABLE_NAME='invitations' THEN
   IF OLD.status<>'pending' OR NEW.status<>'consumed' THEN RETURN NEW; END IF;
   target=NEW.link_id;
  ELSE
   IF OLD.status<>'pending' OR NEW.status<>'active' THEN RETURN NEW; END IF;
   target=NEW.id;
  END IF;
  SELECT * INTO invitation FROM r12_probe.invitations WHERE link_id=target;
  IF NOT FOUND OR invitation.status<>'consumed' OR NOT r12_probe.proof(invitation) THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 commit proof unavailable'; END IF;
  SELECT * INTO linked FROM r12_probe.links WHERE id=target;
  IF NOT FOUND OR linked.status NOT IN ('active','revoked') OR linked.user_id IS DISTINCT FROM invitation.consumed_by OR linked.accepted_at IS DISTINCT FROM invitation.consumed_at
   THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 acceptance incomplete'; END IF;
  RETURN NEW;
 END $$;
CREATE CONSTRAINT TRIGGER r12_invitation_pair AFTER UPDATE ON r12_probe.invitations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION r12_probe.check_pair();
CREATE CONSTRAINT TRIGGER r12_link_pair AFTER UPDATE ON r12_probe.links DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION r12_probe.check_pair();

CREATE FUNCTION r12_probe.guard_publication() RETURNS trigger LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog AS $$
 DECLARE source public.planes_generados; object public.stored_objects;
 BEGIN
  PERFORM r12_probe.require_rc();
  IF TG_OP='UPDATE' THEN
   IF (NEW.id,NEW.gym_id,NEW.client_id,NEW.link_id,NEW.source_plan_id,NEW.source_object_id,NEW.object_key,NEW.content_type,NEW.byte_size,NEW.sha256,NEW.storage_backend,NEW.plan_json)
    IS DISTINCT FROM (OLD.id,OLD.gym_id,OLD.client_id,OLD.link_id,OLD.source_plan_id,OLD.source_object_id,OLD.object_key,OLD.content_type,OLD.byte_size,OLD.sha256,OLD.storage_backend,OLD.plan_json)
    OR OLD.status<>'published' OR NEW.status<>'withdrawn' OR NEW.version<>OLD.version+1
    THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 immutable publication'; END IF;
   RETURN NEW;
  END IF;
  IF NOT r12_probe.canonical_gym(NEW.gym_id) THEN RAISE EXCEPTION USING ERRCODE='42501',MESSAGE='R12 publication owner unavailable'; END IF;
  PERFORM 1 FROM public.clientes WHERE gym_id=NEW.gym_id AND id_cliente=NEW.client_id AND activo AND deleted_at IS NULL FOR SHARE;
  IF NOT FOUND THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 publication client unavailable'; END IF;
  PERFORM 1 FROM r12_probe.links WHERE id=NEW.link_id AND gym_id=NEW.gym_id AND client_id=NEW.client_id AND status IN ('pending','active') FOR SHARE;
  IF NOT FOUND THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 publication link unavailable'; END IF;
  SELECT * INTO source FROM public.planes_generados WHERE id=NEW.source_plan_id AND gym_id=NEW.gym_id AND id_cliente=NEW.client_id AND deleted_at IS NULL FOR SHARE;
  IF NOT FOUND OR NEW.source_object_id IS DISTINCT FROM source.pdf_object_id THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 publication source unavailable'; END IF;
  IF source.pdf_object_id IS NOT NULL THEN
   SELECT * INTO object FROM public.stored_objects WHERE id=source.pdf_object_id AND gym_id=NEW.gym_id FOR SHARE;
   IF NOT FOUND OR object.status<>'ready' OR object.kind<>'plan_pdf' OR object.storage_backend<>'local'
    OR (NEW.source_object_id,NEW.object_key,NEW.content_type,NEW.byte_size,NEW.sha256,NEW.storage_backend)
     IS DISTINCT FROM (object.id,object.key,object.content_type,object.byte_size,object.sha256,object.storage_backend)
    THEN RAISE EXCEPTION USING ERRCODE='23514',MESSAGE='R12 publication object unavailable'; END IF;
  END IF;
  RETURN NEW;
 END $$;
CREATE TRIGGER r12_guard_publication BEFORE INSERT OR UPDATE ON r12_probe.publications FOR EACH ROW EXECUTE FUNCTION r12_probe.guard_publication();
CREATE FUNCTION r12_probe.invalidate_source() RETURNS trigger LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog AS $$
 BEGIN
  IF TG_TABLE_NAME='clientes' THEN
   IF NOT ((NEW.activo IS FALSE AND OLD.activo IS DISTINCT FROM NEW.activo) OR (NEW.deleted_at IS NOT NULL AND OLD.deleted_at IS DISTINCT FROM NEW.deleted_at)
      OR (NEW.gym_id,NEW.id_cliente) IS DISTINCT FROM (OLD.gym_id,OLD.id_cliente)) THEN RETURN NEW; END IF;
   PERFORM r12_probe.require_rc();
   PERFORM 1 FROM r12_probe.links WHERE gym_id=OLD.gym_id AND client_id=OLD.id_cliente ORDER BY id FOR UPDATE;
   UPDATE r12_probe.links SET status='revoked',version=version+1,revoked_at=clock_timestamp() AT TIME ZONE 'UTC'
     WHERE gym_id=OLD.gym_id AND client_id=OLD.id_cliente AND status IN ('pending','active');
   UPDATE r12_probe.invitations SET status='revoked',version=version+1 WHERE gym_id=OLD.gym_id AND client_id=OLD.id_cliente AND status='pending';
   UPDATE r12_probe.publications SET status='withdrawn',version=version+1 WHERE gym_id=OLD.gym_id AND client_id=OLD.id_cliente AND status='published';
  ELSIF TG_TABLE_NAME='planes_generados' THEN
   IF NEW IS NOT DISTINCT FROM OLD THEN RETURN NEW; END IF;
   PERFORM r12_probe.require_rc();
   UPDATE r12_probe.publications SET status='withdrawn',version=version+1 WHERE source_plan_id=OLD.id AND gym_id=OLD.gym_id AND status='published';
  ELSE
   IF (NEW.id,NEW.gym_id,NEW.kind,NEW.key,NEW.content_type,NEW.byte_size,NEW.sha256,NEW.storage_backend,NEW.status)
    IS NOT DISTINCT FROM (OLD.id,OLD.gym_id,OLD.kind,OLD.key,OLD.content_type,OLD.byte_size,OLD.sha256,OLD.storage_backend,OLD.status) THEN RETURN NEW; END IF;
   PERFORM r12_probe.require_rc();
   UPDATE r12_probe.publications SET status='withdrawn',version=version+1 WHERE source_object_id=OLD.id AND gym_id=OLD.gym_id AND status='published';
  END IF;
  RETURN NEW;
 END $$;
CREATE TRIGGER r12_client_invalidation AFTER UPDATE ON public.clientes FOR EACH ROW EXECUTE FUNCTION r12_probe.invalidate_source();
CREATE TRIGGER r12_plan_invalidation AFTER UPDATE ON public.planes_generados FOR EACH ROW EXECUTE FUNCTION r12_probe.invalidate_source();
CREATE TRIGGER r12_object_invalidation AFTER UPDATE ON public.stored_objects FOR EACH ROW EXECUTE FUNCTION r12_probe.invalidate_source();
"""
