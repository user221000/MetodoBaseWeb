import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

root=Path('F:/MetodoBaseWeb-r12-root-review-20261019')
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r12-root-mechanism-review-20261019')
old=out/'test_r12_root_review.py'
target=out/'test_r12_root_noop_isolation.py'
assert not target.exists()
raw=old.read_bytes()
text=old.read_text(encoding='utf-8')
needle="    with tx(lab,GA) as db:\n        db.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ'))\n"
assert text.count(needle)==1
text=text.replace(needle,"    with tx(lab,GA,engine=lab['app'].execution_options(isolation_level='REPEATABLE READ')) as db:\n")
before=ast.parse(raw);after=ast.parse(text)
assert [ast.dump(n) for n in ast.walk(before) if isinstance(n,ast.Assert)]==[ast.dump(n) for n in ast.walk(after) if isinstance(n,ast.Assert)]
target.write_text(text,encoding='utf-8')
pg=json.loads(Path('C:/Users/Consu/AppData/Local/Temp/metodobase-qa-pg55483-private-ok6hrpyq/env.json').read_text(encoding='utf-8'))
environment=dict(os.environ,**pg)
environment.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',METODOBASE_TEST_EVIDENCE_DIR=str(out/'noop-owned-pg'))
with (out/'noop-corrected.log').open('xb') as log:
 result=subprocess.run([sys.executable,'-X','utf8','tests/run_isolated.py','-p','conftest',
    str(target)+'::test_source_noop_under_repeatable_read_preserves_publication','-q','--tb=short','--junitxml='+str(out/'noop-corrected.xml')],
    cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=90)
counts={key:len(ET.parse(out/'noop-corrected.xml').findall('.//'+key)) for key in ['testcase','failure','error','skipped']}
summary={'original_driver_sha256':hashlib.sha256(raw).hexdigest(),'corrected_driver_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
 'assertions_AST_unchanged':True,'scope':'Only fix independent harness to select isolation before the first query; rerun that one positive, not3 earlier positives or the real payload red',
 'original_harness_failure':'SET TRANSACTION after tx helper had already queried set_config',
 'exit':result.returncode,'counts':counts}
(out/'noop-corrected-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
assert result.returncode==0 and counts=={'testcase':1,'failure':0,'error':0,'skipped':0}
