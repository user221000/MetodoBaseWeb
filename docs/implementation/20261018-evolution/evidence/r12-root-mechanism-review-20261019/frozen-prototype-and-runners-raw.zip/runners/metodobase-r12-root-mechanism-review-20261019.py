import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

root=Path('F:/MetodoBaseWeb-r12-root-review-20261019')
author=Path('F:/MetodoBaseWeb-member-link-20261019')
out=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r12-root-mechanism-review-20261019')
out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
for name,expected in [('tests/r12_mechanics_sql.py','bd97e0b3d100a1fa1f889b33854e860e4f26fcb274d8c2630e8ec069135eb898'),
 ('tests/integration_client_link_mechanics_postgres.py','70b44460f286938ce430c1ab9bc13cd1cedf29e6db3e080c6d0e8d02b125e07c')]:
 raw=(author/name).read_bytes()
 assert sha(raw)==expected
 assert not (root/name).exists()
 (root/name).write_bytes(raw)
 shutil.copyfile(root/name,out/Path(name).name)
driver=out/'test_r12_root_review.py'
driver.write_text('''from datetime import datetime,timezone
import uuid
import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from tests.integration_client_link_mechanics_postgres import lab,clean_lab,tx,issue,accept,publish,GA,UA,CA

@pytest.mark.parametrize('table', ['planes_generados','stored_objects'])
def test_owner_reactivation_cannot_restore_invalidated_source(lab,table):
    issued=issue(lab);accept(lab,issued);publication=publish(lab,issued)
    with lab['admin'].begin() as db:
        db.execute(text('UPDATE public.usuarios SET activo=false WHERE id=:id'),{'id':GA})
    with tx(lab,GA) as db:
        if table=='planes_generados':
            db.execute(text('UPDATE public.planes_generados SET deleted_at=:at WHERE id=:id'),{'at':datetime.now(timezone.utc),'id':lab['plans'][CA]})
        else:
            db.execute(text("UPDATE public.stored_objects SET status='pending' WHERE id=:id"),{'id':lab['objects'][CA].id})
        db.commit()
    with lab['admin'].begin() as db:
        db.execute(text('UPDATE public.usuarios SET activo=true WHERE id=:id'),{'id':GA})
        assert db.scalar(text('SELECT status FROM r12_probe.publications WHERE id=:id'),{'id':publication})=='withdrawn'
    with tx(lab,UA) as db:
        assert db.scalar(text('SELECT count(*) FROM r12_probe.publications WHERE id=:id'),{'id':publication})==0

def test_inactive_recipient_cannot_use_previous_publication_or_lock(lab):
    issued=issue(lab);accept(lab,issued);publication=publish(lab,issued)
    with lab['admin'].begin() as db:
        db.execute(text('UPDATE public.usuarios SET activo=false WHERE id=:id'),{'id':UA})
    with tx(lab,UA) as db:
        assert db.execute(text('SELECT id FROM r12_probe.publications WHERE id=:id FOR SHARE'),{'id':publication}).all()==[]

def test_source_noop_under_repeatable_read_preserves_publication(lab):
    issued=issue(lab);accept(lab,issued);publication=publish(lab,issued)
    with tx(lab,GA) as db:
        db.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ'))
        db.execute(text('UPDATE public.planes_generados SET plan_json=plan_json WHERE id=:id'),{'id':lab['plans'][CA]})
        db.commit()
    with tx(lab,UA) as db:
        assert db.scalar(text('SELECT id FROM r12_probe.publications WHERE id=:id'),{'id':publication})==publication

def test_direct_publication_cannot_commit_payload_different_from_exact_source(lab):
    issued=issue(lab);accept(lab,issued)
    sql=text("""INSERT INTO r12_probe.publications(id,gym_id,client_id,link_id,source_plan_id,source_object_id,object_key,content_type,byte_size,sha256,storage_backend,plan_json,status)
      SELECT :id,l.gym_id,l.client_id,l.id,p.id,o.id,o.key,o.content_type,o.byte_size,o.sha256,o.storage_backend,:payload,'published'
      FROM r12_probe.links l JOIN public.planes_generados p ON p.gym_id=l.gym_id AND p.id_cliente=l.client_id
      JOIN public.stored_objects o ON o.gym_id=p.gym_id AND o.id=p.pdf_object_id WHERE l.id=:link""")
    with tx(lab,GA) as db:
        with pytest.raises(DBAPIError):
            db.execute(sql,{'id':str(uuid.uuid4()),'link':issued['link'],'payload':'{"desayuno":{"kcal_real":999999,"nota_privada":"synthetic-only"}}'})
            db.commit()
''',encoding='utf-8')
tracked=[name for name in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0') if name]
names=[name for name in tracked if (root/name).suffix in {'.py','.js','.cjs','.html','.css','.lock'} and not name.startswith('docs/')]
names+=['tests/r12_mechanics_sql.py','tests/integration_client_link_mechanics_postgres.py']
def photo():return {name:sha((root/name).read_bytes()) for name in names}
before=photo()
private=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-qa-pg55483-private-ok6hrpyq/env.json')
pg_env=json.loads(private.read_text(encoding='utf-8'))
assert isinstance(pg_env,dict) and all(isinstance(v,str) for v in pg_env.values())
assert all(k.startswith('METODOBASE_TEST_') for k in pg_env)
environment=dict(os.environ,**pg_env)
environment.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',METODOBASE_TEST_EVIDENCE_DIR=str(out/'pg-owned'))
command=[sys.executable,'-X','utf8','tests/run_isolated.py','-p','conftest',str(driver),'-q','--tb=short','--junitxml='+str(out/'review.xml')]
with (out/'review.log').open('xb') as log:
 result=subprocess.run(command,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=180)
after=photo()
counts={key:len(ET.parse(out/'review.xml').findall('.//'+key)) for key in ['testcase','failure','error','skipped']}
summary={'scope':'Independent five SQL probes on exact frozen experimental prototype; not head29/API or complete author35 replay',
 'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'sql_sha256':sha((root/'tests/r12_mechanics_sql.py').read_bytes()),'own_driver_sha256':sha(driver.read_bytes()),
 'sources_stable':before==after,'source_count':len(before),'source_aggregate_sha256':sha(json.dumps(before,sort_keys=True).encode()),
 'exit':result.returncode,'counts':counts}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
assert before==after
