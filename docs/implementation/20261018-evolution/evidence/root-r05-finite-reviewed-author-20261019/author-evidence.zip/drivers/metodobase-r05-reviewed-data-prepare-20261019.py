import hashlib
import io
import json
from pathlib import Path
import zipfile

ROOT = Path('F:/mb-r05-review-classifier-20261019')
PEER = Path('F:/mb-security-gitleaks-triage-peer-20261019/docs/implementation/20261018-evolution/evidence/security-gitleaks-triage-independent-20261019')
UI = Path('F:/mb-progress-retirement-ui-20261019')
OUT = Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r05-reviewed-author-20261019')
OUT.mkdir(exist_ok=True)
sha = lambda value: hashlib.sha256(value).hexdigest()
ledger_raw = (PEER/'finite-reviewed-location-ledger.json').read_bytes()
assert sha(ledger_raw) == '2b42fdd68d828f9a7d0971326dcb76f650cd83028464b897e546dec2508a3233'
ledger = json.loads(ledger_raw)
files = {}
count = 0
for item in ledger['locations']:
    name = item['file']
    assert item['start_line'] == item['end_line'] and type(item['start_line']) is int
    record = files.get(name)
    if record is None:
        original = (UI/name).read_bytes()
        assert sha(original) == item['file_sha256'], name
        copied = original
        if original.startswith((b'\xff\xfe\x00\x00', b'\x00\x00\xfe\xff')):
            copied = original.decode('utf-32').encode('utf-8')
        elif original.startswith((b'\xff\xfe', b'\xfe\xff')):
            copied = original.decode('utf-16').encode('utf-8')
        elif original.startswith(b'\xef\xbb\xbf'):
            copied = original.decode('utf-8-sig').encode('utf-8')
        assert sha(copied) == ledger['encodings'][name]['scanner_sha256']
        record = files[name] = {'path':name, 'source_digest':sha(original),
            'scanner_digest':sha(copied), 'lines':{}, '_physical':copied.split(b'\n')}
    assert record['source_digest'] == item['file_sha256']
    number = item['start_line']
    line_digest = sha(record['_physical'][number-1])
    assert line_digest == item['physical_line_sha256'], (name,number)
    line = record['lines'].setdefault(number, {'number':number,'digest':line_digest,'rules':set()})
    assert line['digest'] == line_digest
    count += item['rule_id'] not in line['rules']
    line['rules'].add(item['rule_id'])
records = []
for name in sorted(files):
    record = files[name]
    record.pop('_physical')
    record['lines'] = [dict(line, rules=sorted(line['rules'])) for _,line in sorted(record['lines'].items())]
    records.append(record)
assert len(ledger['locations']) == 31564 and count == 31394
config = (UI/'.gitleaks.toml').read_bytes()
assert sha(config) == ledger['config_sha256']
assert sha((ROOT/'.gitleaks.toml').read_bytes()) == sha(config)
data = {'schema':1, 'version':'8.30.1', 'config_digest':sha(config), 'files':records}
raw = json.dumps(data, ensure_ascii=False, separators=(',',':')).encode('utf-8')
assert len(raw) <= 16*1024*1024
buffer = io.BytesIO()
with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    member = zipfile.ZipInfo('reviewed-locations.json', date_time=(2026,10,19,0,0,0))
    member.compress_type = zipfile.ZIP_DEFLATED
    archive.writestr(member,raw)
payload = buffer.getvalue()
destination = ROOT/'scripts/data/reviewed_scan_locations_v1.zip'
destination.parent.mkdir(exist_ok=True)
destination.write_bytes(payload)
module = ROOT/'scripts/reviewed_scan_locations.py'
source = module.read_bytes()
assert source.count(b'PENDING_REVIEW_DATA') == 1
module.write_bytes(source.replace(b'PENDING_REVIEW_DATA',sha(payload).encode()))
receipt = {'input_ledger_digest':sha(ledger_raw),'input_occurrences':31564,'unique_location_rule_pins':count,
    'duplicate_input_occurrences':31564-count,'files':len(records),'json_bytes':len(raw),
    'archive_bytes':len(payload),'archive_digest':sha(payload),
    'config_digest':sha(config), 'variants':'only independently observed RAW encoding/newline bytes; no derived alternates',
    'scope':'old immutable report only; no claim of a current full-tree scan pass'}
(OUT/'data-generation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
