from pathlib import Path, PurePosixPath
import ast
import hashlib
import io
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile

TMP=Path('C:/Users/Consu/AppData/Local/Temp')
ROOT=Path('F:/mb-r05-review-classifier-20261019')
PHASE=TMP/'metodobase-r05-reviewed-author-20261019'
CONTROL=TMP/'metodobase-r05-reviewed-author-seal-20261019'
PRIVATE=TMP/'metodobase-r05-reviewed-author-private-20261019'
TARGET=ROOT/'docs/implementation/20261018-evolution/evidence/root-r05-finite-reviewed-author-20261019'
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda v:(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def git(*args):return subprocess.run(['git',*args],cwd=ROOT,capture_output=True,check=True)
assert git('rev-parse','HEAD').stdout.strip()==b'f7b12a71a89de2e35b0035ccef147a673ad50d29'
assert not git('status','--porcelain=v1','-uno').stdout.strip()
assert not CONTROL.exists() and not PRIVATE.exists() and not TARGET.exists()
summary=json.loads((PHASE/'frozen-focal-summary.json').read_bytes())
assert summary['source_package_python_exact'] and summary['packages']==89
assert all(summary[k]==0 for k in ['test_exit','ruff_exit','pip_before','pip_after'])
cases=ET.parse(PHASE/'frozen-focal.xml').findall('.//testcase')
assert len(cases)==110 and all(n.find('failure') is None and n.find('error') is None and n.find('skipped') is None for n in cases)
assert (PHASE/'frozen-before.json').read_bytes()==(PHASE/'frozen-after.json').read_bytes()
snapshot=json.loads((PHASE/'current-tree-scan.json').read_bytes())
assert snapshot['source_stable'] and not snapshot['changed_files']
assert (snapshot['raw_finding_count'],snapshot['classified_finding_count'],snapshot['remaining_finding_count'])==(42830,28273,14557)
assert snapshot['exit_code']==snapshot['effective_exit_code']==1
assert sha((PHASE/'current-tree-scan.json').read_bytes())=='f273556e34d1796de1f8a01e17d58842be82c7a6ab2173bdeabb1a2d91714f8d'
originals={p.name:p.read_bytes() for p in PHASE.iterdir() if p.is_file()}
assert all(Path(name).suffix.lower() not in {'.db','.env','.sqlite','.pem','.key'} for name in originals)
drivers=['metodobase-r05-reviewed-data-prepare-20261019.py','metodobase-r05-reviewed-author-replay-20261019.py',
    'metodobase-r05-reviewed-format-freeze-20261019.py','metodobase-r05-reviewed-focal-frozen-20261019.py']
for name in drivers:originals['drivers/'+name]=(TMP/name).read_bytes()
originals['drivers/seal.py']=Path(__file__).read_bytes()
CONTROL.mkdir()
acl_source=Path('F:/MetodoBaseWeb-execution-20261018/docs/implementation/20261018-evolution/evidence/root-mfa31-reviewed-serial-20261019/archive-acl.ps1')
acl=acl_source.read_text(encoding='utf-8')
assert acl.count("$names = @('serial-originals.zip')")==1
acl=acl.replace("$names = @('serial-originals.zip')","$names = @('r05-author-originals.zip')")
(CONTROL/'archive-acl.ps1').write_bytes(acl.encode())
def protect(mode):
    run=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(CONTROL/'archive-acl.ps1'),
        '-Mode',mode,'-PrivateRoot',str(PRIVATE)],capture_output=True,check=False)
    (CONTROL/('acl-'+mode+'.stdout')).write_bytes(run.stdout);(CONTROL/('acl-'+mode+'.stderr')).write_bytes(run.stderr)
    assert run.returncode==0,mode
    return json.loads(run.stdout.decode('utf-8-sig'))
created=protect('create');verified=protect('verify');assert verified['verified_before_payload']
archive=PRIVATE/'r05-author-originals.zip';assert archive.stat().st_size==0
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name,blob in originals.items():z.writestr(name,blob)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(originals) and all(z.read(name)==blob for name,blob in originals.items())
final=protect('final')
assert all((PHASE/name).read_bytes()==blob for name,blob in originals.items() if '/' not in name)
definition=next(n for n in ast.parse((TMP/'metodobase-checkpoint119-prepare.py').read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='scan')
exec(compile(ast.Module(body=[definition],type_ignores=[]),'preserved-scanner','exec'))
for name,blob in originals.items():scan(blob,name)
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
    for name,blob in originals.items():z.writestr(name,blob)
products=json.loads((PHASE/'frozen-before.json').read_bytes())['source_digests']
public={'.gitattributes':b'* -text\n','author-evidence.zip':buffer.getvalue(),
    'archive-acl.ps1':(CONTROL/'archive-acl.ps1').read_bytes(),
    'summary.json':enc({'head':summary['head'],'focused_cases':110,'new_cases':49,'prior_cases':61,
        'ruff_exit':0,'pip_before':0,'pip_after':0,'packages':89,'source_package_python_exact':True,
        'old_ledger_replay_occurrences':31564,'finite_unique_pins':31394,'finite_files':534,
        'full_scan_exit':1,'raw_findings':42830,'classified':28273,'remaining_blocking':14557,
        'global_R05_acceptance':False}),
    'source.json':enc({'source':summary['head'],'products':products,
        'independent_ledger_commit':'d536130a9b90c8f4a6f5c8f07f15341d2e07f88e',
        'ledger_digest':'2b42fdd68d828f9a7d0971326dcb76f650cd83028464b897e546dec2508a3233',
        'independent_product_review_commit':'a704f0706827d9e02392902737ed96ef4ce8d764',
        'independent_manifest_digest':'1833fd858ab209de8922d709e7d7e0f4b15b877e101a692a1ffef787726c0e5e',
        'original_files':{n:{'bytes':len(b),'digest':sha(b)} for n,b in originals.items()},
        'private_archive':{'basename':archive.name,'bytes':archive.stat().st_size,'digest':sha(archive.read_bytes()),'members':len(originals)},
        'private_ACL_before_payload':verified,'private_ACL_final':final,'original_directory_ACL_at_creation_attested':False,
        'original_phase_files_unchanged':True,'public_raw_members_exact':True,
        'global_R05_acceptance':False,'scanner119':'all public archive members scanned before publication'}),
    'review.md':('''# Clasificador finito de ubicaciones revisadas R05

Fuente f7b12a71a89de2e35b0035ccef147a673ad50d29. El registro v1 anclado
contiene 31.394 ubicaciones/reglas únicas de 31.564 ocurrencias revisadas de un
informe histórico. Exige SHA256 del archivo RAW y del snapshot, línea física
exacta conservando CR, regla, versión8.30.1 y configuración exacta. No usa
Match/Secret/Line, prefijos de directorio ni patrones genéricos de metadatos.
Registro ausente no clasifica; registro presente corrupto aborta. Los dos pins
anteriores se conservan. El informe mantiene exit bruto y añade exit efectivo.

110 pruebas focales actuales PASS (49 nuevas+61 anteriores), Ruff/pip0 y fuentes,
89 paquetes y ambos ejecutables Python exactos antes/después. Seguridad revisó
v1 por separado en a704f070. Los primeros intentos, su warning de dos EOF y la
corrección secuencial se retienen en author-evidence.zip. El directorio original
de ejecución no tiene atestación retroactiva de ACL al crearse; la copia privada
sí fue protegida y verificada antes del payload y tras readback.

El escaneo completo del predecesor17c9 sobre12.367archivos quedó estable y RED:
42.830 hallazgos brutos,28.273clasificados,14.557bloqueantes. Su informe sólo
contiene ubicaciones/hashes, sin secretos/matches. No es PASS de f7b ni del árbol
común33. El replay de31.564ubicaciones anteriores no es un escaneo nuevo. Las
16ubicaciones checksum con tres preimágenesWIP ausentes conservan la limitación
de procedencia descrita por el revisor; no se reconstruyeron ejecuciones RAW.

Las clasificaciones candidatas de las nuevas ubicaciones quedan fuera de este
registro hasta otra revisión independiente. R05 global sigue abierto. Sin
PostgreSQL,Chrome,Linux,desktop,proveedor real ni Actions en esta fase.
''').encode()}
for name,blob in public.items():scan(blob,name)
TARGET.mkdir();(TARGET/'.gitattributes').write_bytes(public.pop('.gitattributes'))
for name,blob in public.items():
    with (TARGET/name).open('xb') as f:f.write(blob)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in TARGET.iterdir() if p.is_file()}
(TARGET/'manifest.json').write_bytes(enc(manifest))
prefix=TARGET.relative_to(ROOT).as_posix()
git('-c','core.autocrlf=false','add','-f','--',prefix)
git('diff','--cached','--check')
git('commit','-m','Seal focused finite scan classifier and retain blocking full scan')
head=git('rev-parse','HEAD').stdout.decode().strip();assert not git('status','--porcelain=v1','-uno').stdout.strip()
result={'head':head,'files':len(manifest)+1,'source_digest':sha((TARGET/'source.json').read_bytes()),
    'manifest_digest':sha((TARGET/'manifest.json').read_bytes()),'private_members':len(originals),'global_R05_acceptance':False}
(CONTROL/'result.json').write_bytes(enc(result));print(json.dumps(result))
