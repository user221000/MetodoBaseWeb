import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path('F:/mb-r05-review-classifier-20261019')
OUT=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r05-reviewed-author-20261019')
UI=Path('F:/mb-progress-retirement-ui-20261019')
PEER=Path('F:/mb-security-gitleaks-triage-peer-20261019/docs/implementation/20261018-evolution/evidence/security-gitleaks-triage-independent-20261019')
sys.path.insert(0,str(ROOT))
from scripts.reviewed_scan_locations import load_reviewed_locations, _REVIEW_DATA_PATH
sha=lambda b:hashlib.sha256(b).hexdigest()
ledger_raw=(PEER/'finite-reviewed-location-ledger.json').read_bytes()
assert sha(ledger_raw)=='2b42fdd68d828f9a7d0971326dcb76f650cd83028464b897e546dec2508a3233'
ledger=json.loads(ledger_raw)
with tempfile.TemporaryDirectory(prefix='metodobase-r05-author-replay-') as temporary:
    snapshot=Path(temporary)/'snapshot';snapshot.mkdir()
    hashes={}
    for name in sorted({item['file'] for item in ledger['locations']}|{'.gitleaks.toml'}):
        original=(UI/name).read_bytes();hashes[name]=sha(original)
        if original.startswith((b'\xff\xfe\x00\x00',b'\x00\x00\xfe\xff')):
            copied=original.decode('utf-32').encode('utf-8')
        elif original.startswith((b'\xff\xfe',b'\xfe\xff')):
            copied=original.decode('utf-16').encode('utf-8')
        elif original.startswith(b'\xef\xbb\xbf'):
            copied=original.decode('utf-8-sig').encode('utf-8')
        else: copied=original
        destination=snapshot/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(copied)
    destination=snapshot/_REVIEW_DATA_PATH;destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/_REVIEW_DATA_PATH,destination)
    reviewed=load_reviewed_locations(snapshot,hashes,'8.30.1')
    classified=0
    for item in ledger['locations']:
        result=reviewed.classify({'StartLine':item['start_line'],'EndLine':item['end_line'],'RuleID':item['rule_id']},item['file'])
        assert result is not None,(item['file'],item['start_line'],item['rule_id'])
        assert result['physical_line_sha256']==item['physical_line_sha256']
        classified+=1
    result={'kind':'runtime replay of independently reviewed locations, not a new scanner execution',
        'ledger_digest':sha(ledger_raw),'classified_occurrences':classified,'files':len(reviewed.files),
        'pins':sum(len(record['lines']) for record in reviewed.files.values()),
        'encoding':'exact observed original bytes; private snapshot transcodes only known BOM text',
        'source_mutations':0}
    (OUT/'runtime-replay.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))
tool=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-gitleaks-8.30.1/gitleaks.exe')
assert sha(tool.read_bytes())=='17157e2ee8b76fc8b1d8bee607a250e34b8a8023c8bc81822d4b5ee4d78fcb7c'
command=[sys.executable,'scripts/scan_secrets.py','--gitleaks',str(tool),'--report',str(OUT/'current-tree-scan.json')]
with (OUT/'current-tree-scan.stdout').open('wb') as out,(OUT/'current-tree-scan.stderr').open('wb') as err:
    run=subprocess.run(command,cwd=ROOT,stdout=out,stderr=err,check=False)
(OUT/'current-tree-scan-exit.json').write_text(json.dumps({'exit':run.returncode})+'\n',encoding='utf-8')
report=json.loads((OUT/'current-tree-scan.json').read_bytes())
summary={key:report[key] for key in ['version','binary_sha256','exit_code','effective_exit_code','source_stable',
    'raw_finding_count','classified_finding_count','remaining_finding_count']}
summary['files']=len(report['files'])
summary['report_digest']=sha((OUT/'current-tree-scan.json').read_bytes())
(OUT/'current-tree-scan-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
