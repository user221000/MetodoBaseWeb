import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT=Path('F:/mb-r05-review-classifier-20261019')
OUT=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r05-reviewed-author-20261019')
NAMES=['scripts/scan_secrets.py','scripts/reviewed_scan_locations.py',
    'scripts/data/reviewed_scan_locations_v1.zip','tests/test_secret_scan_reviewed_locations.py']
sha=lambda b:hashlib.sha256(b).hexdigest()
def observe():
    return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
        'source_digests':{name:sha((ROOT/name).read_bytes()) for name in NAMES},
        'packages':sorted((d.metadata['Name'],d.version) for d in importlib.metadata.distributions()),
        'python':sys.version,'platform':platform.platform(),'venv_launcher_digest':sha(Path(sys.executable).read_bytes()),
        'base_executable_digest':sha(Path(sys._base_executable).read_bytes())}
before=observe()
assert before['head']=='f7b12a71a89de2e35b0035ccef147a673ad50d29'
(OUT/'frozen-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
def run(name,command,cwd=ROOT):
    for suffix in ['stdout','stderr']:
        assert not (OUT/(name+'.'+suffix)).exists()
    with (OUT/(name+'.stdout')).open('xb') as out,(OUT/(name+'.stderr')).open('xb') as err:
        result=subprocess.run(command,cwd=cwd,stdout=out,stderr=err,check=False)
    return result.returncode
pip_before=run('frozen-pip-before',[sys.executable,'-m','pip','check'])
test_exit=run('frozen-focal',[sys.executable,'-m','pytest','tests/test_secret_scan_reviewed_locations.py',
    'tests/test_secret_scan_fragment_pins.py','tests/test_secret_scan_safety.py','-q','--no-cov',
    '--junitxml='+str(OUT/'frozen-focal.xml')])
lint_exit=run('frozen-ruff',['C:/Users/Consu/AppData/Local/Temp/metodobase-qa-20261018/Scripts/python.exe',
    '-m','ruff','check','scripts/reviewed_scan_locations.py','scripts/scan_secrets.py','tests/test_secret_scan_reviewed_locations.py'])
pip_after=run('frozen-pip-after',[sys.executable,'-m','pip','check'])
after=observe()
(OUT/'frozen-after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
summary={'head':before['head'],'test_exit':test_exit,'ruff_exit':lint_exit,'pip_before':pip_before,'pip_after':pip_after,
    'source_package_python_exact':before==after,'packages':len(before['packages']),
    'scope':'110 focused scanner boundary tests on frozen successor; no new full scanner PASS claim'}
assert before==after and (test_exit,lint_exit,pip_before,pip_after)==(0,0,0,0)
(OUT/'frozen-focal-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
