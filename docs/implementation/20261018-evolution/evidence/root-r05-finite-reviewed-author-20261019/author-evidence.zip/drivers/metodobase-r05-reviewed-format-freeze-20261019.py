import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('F:/mb-r05-review-classifier-20261019')
OUT=Path('C:/Users/Consu/AppData/Local/Temp/metodobase-r05-reviewed-author-20261019')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args, check=True):
    return subprocess.run(['git',*args],cwd=ROOT,check=check,capture_output=True)
assert git('rev-parse','HEAD').stdout.strip()==b'17c9b836776d8ebe51b619ab2b552fafab51f4de'
probe=git('show','--format=','--check','HEAD',check=False)
(OUT/'first-commit-whitespace-check.stdout').write_bytes(probe.stdout)
(OUT/'first-commit-whitespace-check.stderr').write_bytes(probe.stderr)
assert probe.returncode!=0
changed=[]
for name in ['scripts/reviewed_scan_locations.py','tests/test_secret_scan_reviewed_locations.py']:
    path=ROOT/name
    before=path.read_bytes()
    after=before.rstrip(b'\n')+b'\n'
    assert before==after+b'\n'
    path.write_bytes(after)
    changed.append({'path':name,'before_digest':sha(before),'after_digest':sha(after),'only_change':'one blank EOF line removed'})
git('-c','core.autocrlf=false','add',*[row['path'] for row in changed])
check=git('diff','--cached','--check',check=False)
(OUT/'frozen-whitespace-check.stdout').write_bytes(check.stdout)
(OUT/'frozen-whitespace-check.stderr').write_bytes(check.stderr)
assert check.returncode==0
commit=git('commit','-m','Trim two final blank lines in reviewed scan classifier')
(OUT/'format-commit.stdout').write_bytes(commit.stdout)
head=git('rev-parse','HEAD').stdout.decode().strip()
assert not git('status','--porcelain=v1','-uno').stdout.strip()
summary={'predecessor':'17c9b836776d8ebe51b619ab2b552fafab51f4de','head':head,'delta':changed,
    'erratum':'The first PowerShell sequence committed after its whitespace check reported two blank EOF lines. That failure is retained, corrected here with a sequential checked gate before commit.',
    'scan_scope':'The completed full-tree report has exact predecessor bytes and remains blocking. It is not a PASS for this successor.'}
(OUT/'format-freeze.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
