import json,sys
from pathlib import Path
p,kind,n,screens=sys.argv[1:]
n=int(n);screens=int(screens)
Path(p).write_text(json.dumps({'checks':[{'name':str(i)} if kind=='named' else str(i) for i in range(n)],'pageErrors':[],'screens':[str(i) for i in range(screens)]}))
