"""Bounded RAW author evidence and explicit scope for reminder UI27."""
from pathlib import Path,PurePosixPath
import ast,hashlib,io,json,os,re,subprocess,tarfile,zipfile
ROOT=Path('F:/mb-followup-actions-ui-20261019');TEMP=Path(os.environ['TEMP']);DOC=ROOT/'docs/implementation/20261018-evolution'
SHA=lambda raw:hashlib.sha256(raw).hexdigest();ENC=lambda value:(json.dumps(value,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
def git(*args):return subprocess.check_output(['git','-c','core.autocrlf=false',*args],cwd=ROOT)
HEAD='13969fd580d6c381effd636e4bf69dbe4aafb2a7';assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain','-uno').strip()
gate_dir=TEMP/'metodobase-ui27-final-gate-20261020';gate=json.loads((gate_dir/'gate.json').read_bytes());assert gate['source_quiet']and gate['HTTP_passed']==20 and gate['Node_executions']==91
draft=json.loads((DOC/'NOTIFICACIONES_R27_UI_DRAFT.json').read_bytes());paths=list(draft['source_sha256'])+['tests/e2e/notifications36_nav.cjs'];assert len(paths)==16
payload={}
for path in paths:
 raw=(ROOT/path).read_bytes();assert raw==git('show',HEAD+':'+path);payload['source/'+path]=raw
for path in ['web/static/js/gym-branding.js','web/static/js/usuario-privacidad.js','web/templates/configuracion.html','web/templates/usuario_perfil.html']:
 assert(ROOT/path).read_bytes()==git('show','c822c06d1459a4cc34a4582b80b5db2528f9da8a:'+path)
assert(ROOT/'web/middleware/tenant.py').read_bytes()==git('show','27bf2d4dd80e6f323383be0cf7fe40ef85c5603b:web/middleware/tenant.py')
for path in gate_dir.iterdir():
 if path.is_file():payload['final-gate/'+path.name]=path.read_bytes()
for name in ['metodobase-ui27-final-gate-20261020.py','metodobase-ui27-final-seal-20261020.py','metodobase-ui27-http-framing-before-authorization-purge-20261020.py','metodobase-ui27-http-framing-red-20261020.stdout','metodobase-ui27-http-framing-red-20261020.stderr','metodobase-ui27-http-framing-after-purge-20261020.stdout','metodobase-ui27-http-framing-after-purge-20261020.stderr','metodobase-ui27-ruff-before-20261020.stdout','metodobase-ui27-ruff-before-20261020.stderr']:
 p=TEMP/name;assert p.is_file(),name;payload['preserved/'+name]=p.read_bytes()
for path in ['tests/test_notifications36_ui.py','web/routes/pages.py']:
 payload['style-preimages/'+path]=git('show','091d983472fcc87206d10345a5da9b0f0ffb1e9a:'+path)
for name in ['NOTIFICACIONES_R27_CONTRATO36.md','NOTIFICACIONES_R27_RUNBOOK.md']:
 payload['backend-contract/'+name]=(DOC/name).read_bytes()
wire=DOC/'evidence/backend-notifications36-author-20261019'
for name in ['wire-v1.json','wire-v1-addendum1.json','wire-v1-addendum2.json']:payload['backend-contract/'+name]=(wire/name).read_bytes()
assert SHA(payload['backend-contract/wire-v1.json'])=='4e3e55f764d74da17cc08946c32ac956ec9b2a4143126f327c1b55110e365f27'
index={name:{'sha256':SHA(raw),'bytes':len(raw)}for name,raw in payload.items()};payload['index.json']=ENC(index)
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED)as archive:
 for name,raw in payload.items():archive.writestr(name,raw)
with zipfile.ZipFile(buffer)as archive:
 assert len(archive.namelist())==len(payload)and all(archive.read(name)==raw for name,raw in payload.items())
scan_node=next(node for node in ast.parse((TEMP/'metodobase-checkpoint119-prepare.py').read_text(encoding='utf-8-sig')).body if isinstance(node,ast.FunctionDef)and node.name=='scan')
exec(compile(ast.Module(body=[scan_node],type_ignores=[]),'scanner119','exec'))
scan(buffer.getvalue(),'proofs.raw.zip')
folder=DOC/'evidence/frontend-notifications36-author-20261020';assert not folder.exists();folder.mkdir()
(folder/'.gitattributes').write_bytes(b'* -text\n');(folder/'proofs.raw.zip').write_bytes(buffer.getvalue())
metadata={'scope':'Reminder preferences/status UI27, web service only; author acceptance is VM/minimal DOM and real ASGI/SQLite, independent/native acceptance pending.',
 'source_commit':HEAD,'backend_base':'b27f967a5a9e8bba8cc4abf9d80a52110e13b08f','preserved_WIP':'ac7e996c9b646a1342ec20f50c46f21cfeff517b','composition':'091d983472fcc87206d10345a5da9b0f0ffb1e9a',
 'imported_DOM_fix':'c822c06d1459a4cc34a4582b80b5db2528f9da8a','imported_ROOT_QA26':'27bf2d4dd80e6f323383be0cf7fe40ef85c5603b','schema37_imported':False,
 'source_sha256':{p:SHA((ROOT/p).read_bytes())for p in paths},'product_paths':[p for p in paths if p.startswith('web/')],'test_paths':[p for p in paths if p.startswith('tests/')],
 'contracts_sha256':{name:SHA(raw)for name,raw in payload.items()if name.startswith('backend-contract/')},
 'proofs':{'path':folder.relative_to(ROOT).as_posix()+'/proofs.raw.zip','sha256':SHA(buffer.getvalue()),'bytes':len(buffer.getvalue()),'members':len(payload),'all_members_full_RAW_readback_equal':True,'scanner119_recursive_passed':True},
 'final_gate':{key:gate[key]for key in['source_quiet','source_count','distributions','Node_commands','Node_executions','HTTP_passed','HTTP_cases','API_full_RAW_inverse_equals_b27','Ruff','syntax_files','pip_check','seconds']},
 'behavior':{'delivery_enabled':False,'default':'Two purposes OFF, version0 virtual; GET never writes or observes billing/provider facts.','authority':'Canonical own gym OWNER or canonical individual. API remains authoritative; navigation never grants rights.','writes':'Explicit confirmation, CAS/version and one UUID per captured intent. Body/key survive uncertain503 for voluntary same-intent retry only.','ACK':'No ACK/replay is accepted as current snapshot; explicit manual read required. Failed read retains uncertain intent.','facts':'Unknown never means debt; no client-date inference; no contact auto-send; provider acceptance is not delivery.','session':'Existing RAM access/epoch handles, no credential/PII Storage. Session boundary/pagehide clears private projections, dates, confirmations and pending intent; late results discarded.','outbox':'Manual20 item keyset pages, exact observed version cancel; uncertain never offers resend.','metrics':'Explicit <=62 civil dates, observed declarations only, no renewal/email causality.'},
 'SSR':{'paths':['/recordatorios','/recordatorios/','/mis-recordatorios','/mis-recordatorios/'],'statuses':'200 GET,307 double-slash exact same-resource Location,405 HEAD; adjacent suffix/extra404 outside matcher.','headers':'No-store/no-referrer/nosniff and first-party CSP on own200/307/405. Existing API/exclusion privacy aliases retained; adjacent404 strict-origin-when-cross-origin.','public_exclusion':'Existing minimal purpose-only page preserved, no Api/bootstrap/Storage; credentials omit.'},
 'preserved_failures':{'initial_HTTP':'8PASS2FAIL, inherited fixture-manager Bearer before public setup; prior logs and preimage retained. Focused header-purge1RED to1PASS, without backend repair.','QA26':'Original separate ee7b1f31c72b25654fb8f91788b4da03cdf90b4b candidate remains preserved; current two-factory canary passes with ROOT tenant fix.','Ruff':'Prior3 style errors, fixed imports only; function/route/assertion AST retained.'},
 'limits':['No Chrome/native reflow320/390/768/1440, keyboard/axe or delivery-provider acceptance.','No PostgreSQL37 or schema37 claims; source is composed current36.','Independent QA/SEC review pending for this UI.','Authenticated UI requires a successful eligible context read before projecting management forms. Existing own withdrawal/list backend policy and public purpose-only exclusion are unchanged; expanded former-role management UI is not claimed.','DOM fix/native minimal diagnostic belongs to its separate author/QA seals, not to this UI gate.'],
 'integration':{'product_commits':['ac7e996c9b646a1342ec20f50c46f21cfeff517b',HEAD],'source_export':'Archive source/ entries contain all16 final paths; import ROOT tenant and four DOM sources separately/exactly. No need to transplant unrelated ROOT history.','historical_draft':'NOTIFICACIONES_R27_UI_DRAFT.json is preserved as historical pre-freeze metadata; this contract supersedes its pending list.'}}
target=DOC/'NOTIFICACIONES_R27_UI_IMPLEMENTACION.json';target.write_bytes(ENC(metadata));scan(target.read_bytes(),target.name)
receipt={'contract':target.relative_to(ROOT).as_posix(),'contract_sha256':SHA(target.read_bytes()),'proofs_sha256':SHA(buffer.getvalue()),'source_commit':HEAD,'files':len(paths),'Node_executions':91,'HTTP_passed':20,'schema':36,'native_accepted':False}
(folder/'manifest.json').write_bytes(ENC(receipt))
for p in [folder/'.gitattributes',folder/'proofs.raw.zip',folder/'manifest.json',target]:
 git('add','--',p.relative_to(ROOT).as_posix());assert git('show',':'+p.relative_to(ROOT).as_posix())==p.read_bytes()
git('commit','-m','docs(web): seal reminder UI36 contract and local author evidence')
print(json.dumps({'commit':git('rev-parse','HEAD').decode().strip(),**receipt}))
