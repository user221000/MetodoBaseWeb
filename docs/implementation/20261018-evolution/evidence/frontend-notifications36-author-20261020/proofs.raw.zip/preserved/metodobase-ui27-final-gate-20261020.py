"""Versioned-source reminder UI author gate; local doubles and real ASGI only."""
from pathlib import Path
import hashlib,importlib.metadata,json,os,subprocess,time,xml.etree.ElementTree as ET
ROOT=Path('F:/mb-followup-actions-ui-20261019');OUT=Path(os.environ['TEMP'])/'metodobase-ui27-final-gate-20261020'
SHA=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git','-c','core.autocrlf=false',*args],cwd=ROOT)
HEAD=git('rev-parse','HEAD').decode().strip();assert HEAD.startswith('13969fd5')
assert not git('status','--porcelain','-uno').strip() and not OUT.exists();OUT.mkdir()
def photo():return{p:SHA((ROOT/p).read_bytes())for p in git('ls-files').decode().splitlines()if not p.startswith('docs/')and(ROOT/p).is_file()}
def packages():return sorted((d.metadata['Name'],d.version)for d in importlib.metadata.distributions())
before,dist=photo(),packages();started=time.monotonic();reports=[]
env=os.environ.copy();env['NODE_OPTIONS']='--require='+str(ROOT/'tests/e2e/browser_offline31.cjs').replace('\\','/')
def run(label,command,timeout=40):
 result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=timeout)
 (OUT/(label+'.stdout.raw')).write_bytes(result.stdout);(OUT/(label+'.stderr.raw')).write_bytes(result.stderr)
 assert result.returncode==0,(label,result.stdout[-1500:],result.stderr[-500:])
 return result
for label,file,total in [('state','notifications36_state.cjs',19),('dom','notifications36_dom.cjs',8),('nav','notifications36_nav.cjs',9),('session','browser_session31.cjs',55)]:
 command=['node','tests/e2e/'+file];report=json.loads(run(label,command).stdout)
 assert report['passed']==report['total']==total,(label,report)
 reports.append({'label':label,'command':command,'passed':total,'total':total,'case_names':[row['case']for row in report['results' if 'results'in report else'rows']]})
python='C:/Users/Consu/AppData/Local/Temp/metodobase-google33-author-aamidzkr/venv/Scripts/python.exe'
command=[python,'-m','pytest','-q','tests/test_notifications36_ui.py','tests/test_notifications36_headers.py','tests/test_registration_bearer_ui27_canary.py','--disable-warnings','--tb=short','--junitxml',str(OUT/'http.xml')]
run('http',command,120)
cases=ET.parse(OUT/'http.xml').findall('.//testcase');assert len(cases)==20 and not any(c.find(name)is not None for c in cases for name in['failure','error','skipped'])
run('pip',[python,'-m','pip','check'])
ruff='C:/Users/Consu/AppData/Local/Temp/metodobase-qa-20261018/Scripts/python.exe'
run('ruff',[ruff,'-m','ruff','check','tests/test_notifications36_ui.py','web/routes/pages.py','web/notification_paths.py'])
syntax=['web/static/js/api.js','web/static/js/notifications36.js','web/static/js/notification-nav36.js','tests/e2e/notifications36_state.cjs','tests/e2e/notifications36_dom.cjs','tests/e2e/notifications36_nav.cjs','tests/e2e/notifications36_http_worker.cjs']
for index,path in enumerate(syntax):run('syntax-'+str(index),['node','--check',path])
api=(ROOT/'web/static/js/api.js').read_bytes();start=api.index(b'  // Own notification36 operations');end=api.index(b'  const billing = {',start)
assert(api[:start]+api[end:]).replace(b'notifications36, ',b'',1)==git('show','b27f967a5a9e8bba8cc4abf9d80a52110e13b08f:web/static/js/api.js')
assert photo()==before and packages()==dist and git('rev-parse','HEAD').decode().strip()==HEAD
report={'head':HEAD,'source_quiet':True,'sources':before,'source_count':len(before),'packages':dist,'distributions':len(dist),'Node_commands':reports,'Node_executions':sum(row['passed']for row in reports),'HTTP_cases':[c.attrib['classname']+'::'+c.attrib['name']for c in cases],'HTTP_passed':len(cases),'API_full_RAW_inverse_equals_b27':True,'Ruff':0,'syntax_files':syntax,'pip_check':True,'seconds':round(time.monotonic()-started,3),'scope':'Actual Api/controller in VM/minimal DOM plus both factories real ASGI/SQLite browser auth/MFA/preferences; no Chrome, axe, native reflow/keyboard, delivery provider or PostgreSQL claim.'}
(OUT/'gate.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf8')
print(json.dumps({key:report[key]for key in['head','source_quiet','source_count','distributions','Node_executions','HTTP_passed','API_full_RAW_inverse_equals_b27','Ruff','pip_check','seconds','scope']}))
